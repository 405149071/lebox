define("game.js", function(require, module, exports, process) {
 "use strict";

(function () {
    require("libs/weapp-adapter/index");
    var a = require("libs/xmldom/dom-parser");
    window.DOMParser = a.DOMParser, require("libs/wx-downloader.js"), require("src/settings");
    var b = window._CCSettings;
    require("main"), require(b.debug ? "cocos2d-js.js" : "cocos2d-js-min.js"), require("./libs/weapp-adapter/engine/index.js"), wxDownloader.REMOTE_SERVER_ROOT = "", wxDownloader.SUBCONTEXT_ROOT = "";
    var c = cc.loader.md5Pipe || cc.loader.assetLoader;
    cc.loader.insertPipeAfter(c, wxDownloader), cc.sys.browserType === cc.sys.BROWSER_TYPE_WECHAT_GAME_SUB ? require("./libs/sub-context-adapter") : cc.macro.CLEANUP_IMAGE_CACHE = !0, window.boot();
})(); 
})