define("main.js", function(require, module, exports, process) {
 "use strict";

(function () {
    !1, window.boot = function () {
        var a = window._CCSettings;
        if (window._CCSettings = void 0, !a.debug) {
            var b = a.uuids,
                c = a.rawAssets,
                d = a.assetTypes,
                e = a.rawAssets = {};
            for (var f in c) {
                var g = c[f],
                    h = e[f] = {};
                for (var k in g) {
                    var l = g[k],
                        m = l[1];
                    "number" == typeof m && (l[1] = d[m]), h[b[k] || k] = l;
                }
            }
            for (var n, o = a.scenes, p = 0; p < o.length; ++p) {
                n = o[p], "number" == typeof n.uuid && (n.uuid = b[n.uuid]);
            }var i = a.packedAssets;
            for (var q in i) {
                for (var r = i[q], s = 0; s < r.length; ++s) {
                    "number" == typeof r[s] && (r[s] = b[r[s]]);
                }
            }
        }
        var j = a.jsList,
            t = a.debug ? "src/project.dev.js" : "src/project.js";
        j ? (j = j.map(function (a) {
            return "src/" + a;
        }), j.push(t)) : j = [t], cc.sys.isNative && cc.sys.isMobile && (j = j.concat(["src/anysdk/jsb_anysdk.js", "src/anysdk/jsb_anysdk_constants.js"]));
        var u = {
            id: "GameCanvas",
            scenes: a.scenes,
            debugMode: a.debug ? cc.debug.DebugMode.INFO : cc.debug.DebugMode.ERROR,
            showFPS: a.debug,
            frameRate: 60,
            jsList: j,
            groupList: a.groupList,
            collisionMatrix: a.collisionMatrix
        };
        cc.game.run(u, function () {
            cc.loader.downloader._subpackages = a.subpackages, cc.view.enableRetina(!0), cc.view.resizeWithBrowserSize(!0), !1, cc.AssetLibrary.init({
                libraryPath: "res/import",
                rawAssetsBase: "res/raw-",
                rawAssets: a.rawAssets,
                packedAssets: a.packedAssets,
                md5AssetsMap: a.md5AssetsMap
            });
            var b = a.launchScene;
            cc.director.loadScene(b, null, function () {
                if (cc.sys.isBrowser) {
                    var a = document.getElementById("GameCanvas");
                    a.style.visibility = "";
                    var c = document.getElementById("GameDiv");
                    c && (c.style.backgroundImage = "");
                }
                cc.loader.onProgress = null, console.log("Success to load scene: " + b);
            });
        });
    };
    window.jsb && (require("src/settings.js"), require("src/cocos2d-jsb.js"), require("jsb-adapter/engine/index.js"), window.boot());
})(); 
})