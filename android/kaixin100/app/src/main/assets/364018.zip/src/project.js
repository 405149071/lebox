define("src/project.js", function(require, module, exports, process) {
 "use strict";

(function () {
    var l = Math.sin,
        a = Math.cos,
        p = Math.pow,
        m = Math.floor;
    window.__require = function p(d, e, t) {
        function o(r, a) {
            if (!e[r]) {
                if (!d[r]) {
                    var i = r.split("/");
                    if (i = i[i.length - 1], !d[i]) {
                        var c = "function" == typeof __require && __require;
                        if (!a && c) return c(i, !0);
                        if (n) return n(i, !0);
                        throw new Error("Cannot find module '" + r + "'");
                    }
                }
                var s = e[r] = {
                    exports: {}
                };
                d[r][0].call(s.exports, function (t) {
                    return o(d[r][1][t] || t);
                }, s, s.exports, p, d, e, t);
            }
            return e[r].exports;
        }
        for (var n = "function" == typeof __require && __require, l = 0; l < t.length; l++) {
            o(t[l]);
        }return o;
    }({
        1: [function (o, e) {
            var b = function () {
                "use strict";

                function z(o, e) {
                    return void 0 === o ? z[0] : void 0 === e ? V(o) : 10 == +e ? V(o) : x(o, e);
                }
                function K(o, e) {
                    this.value = o, this.sign = e, this.isSmall = !1;
                }
                function c(t) {
                    this.value = t, this.sign = 0 > t, this.isSmall = !0;
                }
                function s(t) {
                    return -o < t && t < o;
                }
                function l(t) {
                    return 1e7 > t ? [t] : 1e14 > t ? [t % 1e7, m(t / 1e7)] : [t % 1e7, m(t / 1e7) % 1e7, m(t / 1e14)];
                }
                function Z(t) {
                    $(t);
                    var e = t.length;
                    return 4 > e && 0 > L(t, ee) ? 0 === e ? 0 : 1 === e ? t[0] : 2 === e ? t[0] + t[1] * j : t[0] + (t[1] + t[2] * j) * j : t;
                }
                function $(o) {
                    for (var e = o.length; 0 === o[--e];) {}
                    o.length = e + 1;
                }
                function d(n) {
                    for (var e = Array(n), t = -1; ++t < n;) {
                        e[t] = 0;
                    }return e;
                }
                function f(t) {
                    return 0 < t ? m(t) : W(t);
                }
                function n(t, e) {
                    var o,
                        n,
                        i = t.length,
                        r = e.length,
                        a = Array(i),
                        l = 0,
                        p = j;
                    for (n = 0; n < r; n++) {
                        l = (o = t[n] + e[n] + l) >= p ? 1 : 0, a[n] = o - l * p;
                    }for (; n < i;) {
                        l = (o = t[n] + l) === p ? 1 : 0, a[n++] = o - l * p;
                    }return 0 < l && a.push(l), a;
                }
                function _(o, e) {
                    return o.length >= e.length ? n(o, e) : n(e, o);
                }
                function a(t, e) {
                    var o,
                        n,
                        i = t.length,
                        r = Array(i),
                        a = j;
                    for (n = 0; n < i; n++) {
                        o = t[n] - a + e, e = m(o / a), r[n] = o - e * a, e += 1;
                    }for (; 0 < e;) {
                        r[n++] = e % a, e = m(e / a);
                    }return r;
                }
                function g(t, e) {
                    var o,
                        n,
                        i = t.length,
                        r = e.length,
                        a = Array(i),
                        l = 0,
                        p = j;
                    for (o = 0; o < r; o++) {
                        0 > (n = t[o] - l - e[o]) ? (n += p, l = 1) : l = 0, a[o] = n;
                    }for (o = r; o < i; o++) {
                        if (!(0 > (n = t[o] - l))) {
                            a[o++] = n;
                            break;
                        }
                        n += p, a[o] = n;
                    }
                    for (; o < i; o++) {
                        a[o] = t[o];
                    }return $(a), a;
                }
                function u(t, e, s) {
                    var n,
                        i,
                        r = t.length,
                        a = Array(r),
                        d = -e,
                        u = j;
                    for (n = 0; n < r; n++) {
                        i = t[n] + d, d = m(i / u), i %= u, a[n] = 0 > i ? i + u : i;
                    }return "number" == typeof (a = Z(a)) ? (s && (a = -a), new c(a)) : new K(a, s);
                }
                function y(t, e) {
                    var o,
                        n,
                        i,
                        r,
                        a = t.length,
                        l = e.length,
                        c = d(a + l),
                        s = j;
                    for (i = 0; i < a; ++i) {
                        r = t[i];
                        for (var u = 0; u < l; ++u) {
                            o = r * e[u] + c[i + u], n = m(o / s), c[i + u] = o - n * s, c[i + u + 1] += n;
                        }
                    }
                    return $(c), c;
                }
                function S(t, e) {
                    var o,
                        n,
                        i = t.length,
                        r = Array(i),
                        a = j,
                        l = 0;
                    for (n = 0; n < i; n++) {
                        o = t[n] * e + l, l = m(o / a), r[n] = o - l * a;
                    }for (; 0 < l;) {
                        r[n++] = l % a, l = m(l / a);
                    }return r;
                }
                function h(n, e) {
                    for (var t = []; 0 < e--;) {
                        t.push(0);
                    }return t.concat(n);
                }
                function B(t, e, o) {
                    return new K(t < j ? S(e, t) : y(e, l(t)), o);
                }
                function C(t) {
                    var e,
                        o,
                        n,
                        i,
                        r = t.length,
                        a = d(r + r),
                        l = j;
                    for (n = 0; n < r; n++) {
                        o = 0 - (i = t[n]) * i;
                        for (var p = n; p < r; p++) {
                            e = 2 * (i * t[p]) + a[n + p] + o, o = m(e / l), a[n + p] = e - o * l;
                        }a[n + r] = o;
                    }
                    return $(a), a;
                }
                function v(t, e) {
                    var o,
                        n,
                        i,
                        r,
                        a = t.length,
                        l = d(a);
                    for (i = 0, o = a - 1; 0 <= o; --o) {
                        i = (r = i * j + t[o]) - (n = f(r / e)) * e, l[o] = 0 | n;
                    }return [l, 0 | i];
                }
                function I(t, e) {
                    var o,
                        n,
                        s = V(e),
                        r = t.value,
                        a = s.value;
                    if (0 === a) throw new Error("Cannot divide by zero");
                    if (t.isSmall) return s.isSmall ? [new c(f(r / a)), new c(r % a)] : [z[0], t];
                    if (s.isSmall) {
                        if (1 === a) return [t, z[0]];
                        if (-1 == a) return [t.negate(), z[0]];
                        var p = Y(a);
                        if (p < j) {
                            n = Z((o = v(r, p))[0]);
                            var u = o[1];
                            return t.sign && (u = -u), "number" == typeof n ? (t.sign !== s.sign && (n = -n), [new c(n), new c(u)]) : [new K(n, t.sign !== s.sign), new c(u)];
                        }
                        a = l(p);
                    }
                    var b = L(r, a);
                    if (-1 === b) return [z[0], t];
                    if (0 === b) return [z[t.sign === s.sign ? 1 : -1], z[0]];
                    n = (o = 200 >= r.length + a.length ? function (t, e) {
                        var o,
                            n,
                            i,
                            r,
                            a,
                            l,
                            c,
                            s = t.length,
                            u = e.length,
                            p = j,
                            f = d(e.length),
                            b = e[u - 1],
                            _ = W(p / (2 * b)),
                            h = S(t, _),
                            g = S(e, _);
                        for (h.length <= s && h.push(0), g.push(0), b = g[u - 1], n = s - u; 0 <= n; n--) {
                            for (o = p - 1, h[n + u] !== b && (o = m((h[n + u] * p + h[n + u - 1]) / b)), i = 0, r = 0, l = g.length, a = 0; a < l; a++) {
                                i += o * g[a], c = m(i / p), r += h[n + a] - (i - c * p), i = c, 0 > r ? (h[n + a] = r + p, r = -1) : (h[n + a] = r, r = 0);
                            }for (; 0 !== r;) {
                                for (o -= 1, i = 0, a = 0; a < l; a++) {
                                    0 > (i += h[n + a] - p + g[a]) ? (h[n + a] = i + p, i = 0) : (h[n + a] = i, i = 1);
                                }r += i;
                            }
                            f[n] = o;
                        }
                        return h = v(h, _)[0], [Z(f), Z(h)];
                    }(r, a) : function (t, e) {
                        for (var o, n, i, r, a, l = t.length, d = e.length, s = [], c = [], p = j; l;) {
                            if (c.unshift(t[--l]), $(c), 0 > L(c, e)) s.push(0);else {
                                i = c[(n = c.length) - 1] * p + c[n - 2], r = e[d - 1] * p + e[d - 2], n > d && (i = (i + 1) * p), o = W(i / r);
                                do {
                                    if (0 >= L(a = S(e, o), c)) break;
                                    o--;
                                } while (o);
                                s.push(o), c = g(c, a);
                            }
                        }return s.reverse(), [Z(s), Z(c)];
                    }(r, a))[0];
                    var y = t.sign !== s.sign,
                        _ = o[1],
                        h = t.sign;
                    return "number" == typeof n ? (y && (n = -n), n = new c(n)) : n = new K(n, y), "number" == typeof _ ? (h && (_ = -_), _ = new c(_)) : _ = new K(_, h), [n, _];
                }
                function L(n, e) {
                    if (n.length !== e.length) return n.length > e.length ? 1 : -1;
                    for (var t = n.length - 1; 0 <= t; t--) {
                        if (n[t] !== e[t]) return n[t] > e[t] ? 1 : -1;
                    }return 0;
                }
                function P(o) {
                    var e = o.abs();
                    return !e.isUnit() && (!!(e.equals(2) || e.equals(3) || e.equals(5)) || !(e.isEven() || e.isDivisibleBy(3) || e.isDivisibleBy(5)) && (!!e.lesser(25) || void 0));
                }
                function E(t) {
                    return ("number" == typeof t || "string" == typeof t) && +Y(t) <= j || t instanceof K && 1 >= t.value.length;
                }
                function N(n, e, t) {
                    e = V(e);
                    for (var o = n.isNegative(), i = e.isNegative(), r = o ? n.not() : n, a = i ? e.not() : e, l = 0, c = 0, s = null, u = null, p = []; !r.isZero() || !a.isZero();) {
                        l = (s = I(r, M))[1].toJSNumber(), o && (l = M - 1 - l), c = (u = I(a, M))[1].toJSNumber(), i && (c = M - 1 - c), r = s[0], a = u[0], p.push(t(l, c));
                    }for (var d = 0 === t(o ? 1 : 0, i ? 1 : 0) ? b(0) : b(-1), f = p.length - 1; 0 <= f; f -= 1) {
                        d = d.multiply(M).add(b(p[f]));
                    }return d;
                }
                function w(t) {
                    var e = t.value,
                        l = "number" == typeof e ? e | A : e[0] + e[1] * j | G;
                    return l & -l;
                }
                function F(o, e) {
                    return o = V(o), e = V(e), o.greater(e) ? o : e;
                }
                function T(o, e) {
                    return o = V(o), e = V(e), o.lesser(e) ? o : e;
                }
                function k(l, e) {
                    if (l = V(l).abs(), e = V(e).abs(), l.equals(e)) return l;
                    if (l.isZero()) return e;
                    if (e.isZero()) return l;
                    for (var t, o, n = z[1]; l.isEven() && e.isEven();) {
                        t = Math.min(w(l), w(e)), l = l.divide(t), e = e.divide(t), n = n.multiply(t);
                    }for (; l.isEven();) {
                        l = l.divide(w(l));
                    }do {
                        for (; e.isEven();) {
                            e = e.divide(w(e));
                        }l.greater(e) && (o = e, e = l, l = o), e = e.subtract(l);
                    } while (!e.isZero());
                    return n.isUnit() ? l : l.multiply(n);
                }
                function O(l, e, t) {
                    var o,
                        n = z[0],
                        a = z[1];
                    for (o = l.length - 1; 0 <= o; o--) {
                        n = n.add(l[o].times(a)), a = a.times(e);
                    }return t ? n.negate() : n;
                }
                function H(t) {
                    return 35 >= t ? "0123456789abcdefghijklmnopqrstuvwxyz".charAt(t) : "<" + t + ">";
                }
                function D(n, s) {
                    if ((s = b(s)).isZero()) {
                        if (n.isZero()) return {
                            value: [0],
                            isNegative: !1
                        };
                        throw new Error("Cannot convert nonzero numbers to base 0.");
                    }
                    if (s.equals(-1)) {
                        if (n.isZero()) return {
                            value: [0],
                            isNegative: !1
                        };
                        if (n.isNegative()) return {
                            value: [].concat.apply([], Array.apply(null, Array(-n)).map(Array.prototype.valueOf, [1, 0])),
                            isNegative: !1
                        };
                        var t = Array.apply(null, Array(+n - 1)).map(Array.prototype.valueOf, [0, 1]);
                        return t.unshift([1]), {
                            value: [].concat.apply([], t),
                            isNegative: !1
                        };
                    }
                    var o = !1;
                    if (n.isNegative() && s.isPositive() && (o = !0, n = n.abs()), s.equals(1)) return n.isZero() ? {
                        value: [0],
                        isNegative: !1
                    } : {
                        value: Array.apply(null, Array(+n)).map(Number.prototype.valueOf, 1),
                        isNegative: o
                    };
                    for (var p, r = [], a = n; a.isNegative() || 0 <= a.compareAbs(s);) {
                        a = (p = a.divmod(s)).quotient;
                        var l = p.remainder;
                        l.isNegative() && (l = s.minus(l).abs(), a = a.next()), r.push(l.toJSNumber());
                    }
                    return r.push(a.toJSNumber()), {
                        value: r.reverse(),
                        isNegative: o
                    };
                }
                function X(n, e) {
                    var t = D(n, e);
                    return (t.isNegative ? "-" : "") + t.value.map(H).join("");
                }
                function q(o) {
                    if (s(+o)) {
                        var u = +o;
                        if (u === f(u)) return new c(u);
                        throw new Error("Invalid integer: " + o);
                    }
                    var t = "-" === o[0];
                    t && (o = o.slice(1));
                    var n = o.split(/e/i);
                    if (2 < n.length) throw new Error("Invalid integer: " + n.join("e"));
                    if (2 === n.length) {
                        var i = n[1];
                        if ("+" === i[0] && (i = i.slice(1)), (i = +i) !== f(i) || !s(i)) throw new Error("Invalid integer: " + i + " is not a valid exponent.");
                        var b = n[0],
                            a = b.indexOf(".");
                        if (0 <= a && (i -= b.length - a - 1, b = b.slice(0, a) + b.slice(a + 1)), 0 > i) throw new Error("Cannot include negative exponent part for integers");
                        o = b += Array(i + 1).join("0");
                    }
                    if (!/^([0-9][0-9]*)$/.test(o)) throw new Error("Invalid integer: " + o);
                    for (var l = [], p = o.length, d = Q, g = p - d; 0 < p;) {
                        l.push(+o.slice(g, p)), 0 > (g -= d) && (g = 0), p -= d;
                    }return $(l), new K(l, t);
                }
                function V(t) {
                    return "number" == typeof t ? function (t) {
                        if (s(t)) {
                            if (t !== f(t)) throw new Error(t + " is not an integer.");
                            return new c(t);
                        }
                        return q(t.toString());
                    }(t) : "string" == typeof t ? q(t) : t;
                }
                var Y = Math.abs,
                    W = Math.ceil,
                    j = 1e7,
                    Q = 7,
                    o = 9007199254740992,
                    ee = l(o);
                K.prototype = Object.create(z.prototype), c.prototype = Object.create(z.prototype), K.prototype.add = function (l) {
                    var e = V(l);
                    if (this.sign !== e.sign) return this.subtract(e.negate());
                    var t = this.value,
                        o = e.value;
                    return e.isSmall ? new K(a(t, Y(o)), this.sign) : new K(_(t, o), this.sign);
                }, K.prototype.plus = K.prototype.add, c.prototype.add = function (r) {
                    var e = V(r),
                        t = this.value;
                    if (0 > t !== e.sign) return this.subtract(e.negate());
                    var o = e.value;
                    if (e.isSmall) {
                        if (s(t + o)) return new c(t + o);
                        o = l(Y(o));
                    }
                    return new K(a(o, Y(t)), 0 > t);
                }, c.prototype.plus = c.prototype.add, K.prototype.subtract = function (l) {
                    var e = V(l);
                    if (this.sign !== e.sign) return this.add(e.negate());
                    var t = this.value,
                        o = e.value;
                    return e.isSmall ? u(t, Y(o), this.sign) : function (l, e, t) {
                        var a;
                        return 0 <= L(l, e) ? a = g(l, e) : (a = g(e, l), t = !t), "number" == typeof (a = Z(a)) ? (t && (a = -a), new c(a)) : new K(a, t);
                    }(t, o, this.sign);
                }, K.prototype.minus = K.prototype.subtract, c.prototype.subtract = function (l) {
                    var e = V(l),
                        t = this.value;
                    if (0 > t !== e.sign) return this.add(e.negate());
                    var o = e.value;
                    return e.isSmall ? new c(t - o) : u(o, Y(t), 0 <= t);
                }, c.prototype.minus = c.prototype.subtract, K.prototype.negate = function () {
                    return new K(this.value, !this.sign);
                }, c.prototype.negate = function () {
                    var o = this.sign,
                        n = new c(-this.value);
                    return n.sign = !o, n;
                }, K.prototype.abs = function () {
                    return new K(this.value, !1);
                }, c.prototype.abs = function () {
                    return new c(Y(this.value));
                }, K.prototype.multiply = function (t) {
                    var e,
                        o = V(t),
                        n = this.value,
                        i = o.value,
                        r = this.sign !== o.sign;
                    if (o.isSmall) {
                        if (0 === i) return z[0];
                        if (1 === i) return this;
                        if (-1 === i) return this.negate();
                        if ((e = Y(i)) < j) return new K(S(n, e), r);
                        i = l(e);
                    }
                    return function (o, e) {
                        return 0 < -.012 * o - .012 * e + 15e-6 * o * e;
                    }(n.length, i.length) ? new K(function p(e, t) {
                        var o = Math.max(e.length, t.length);
                        if (30 >= o) return y(e, t);
                        o = W(o / 2);
                        var n = e.slice(o),
                            i = e.slice(0, o),
                            r = t.slice(o),
                            a = t.slice(0, o),
                            l = p(i, a),
                            d = p(n, r),
                            s = _(_(l, h(g(g(p(_(i, n), _(a, r)), l), d), o)), h(d, 2 * o));
                        return $(s), s;
                    }(n, i), r) : new K(y(n, i), r);
                }, K.prototype.times = K.prototype.multiply, c.prototype._multiplyBySmall = function (t) {
                    return s(t.value * this.value) ? new c(t.value * this.value) : B(Y(t.value), l(Y(this.value)), this.sign !== t.sign);
                }, K.prototype._multiplyBySmall = function (t) {
                    return 0 === t.value ? z[0] : 1 === t.value ? this : -1 === t.value ? this.negate() : B(Y(t.value), this.value, this.sign !== t.sign);
                }, c.prototype.multiply = function (t) {
                    return V(t)._multiplyBySmall(this);
                }, c.prototype.times = c.prototype.multiply, K.prototype.square = function () {
                    return new K(C(this.value), !1);
                }, c.prototype.square = function () {
                    var t = this.value * this.value;
                    return s(t) ? new c(t) : new K(C(l(Y(this.value))), !1);
                }, K.prototype.divmod = function (o) {
                    var e = I(this, o);
                    return {
                        quotient: e[0],
                        remainder: e[1]
                    };
                }, c.prototype.divmod = K.prototype.divmod, K.prototype.divide = function (t) {
                    return I(this, t)[0];
                }, c.prototype.over = c.prototype.divide = K.prototype.over = K.prototype.divide, K.prototype.mod = function (t) {
                    return I(this, t)[1];
                }, c.prototype.remainder = c.prototype.mod = K.prototype.remainder = K.prototype.mod, K.prototype.pow = function (l) {
                    var e,
                        t,
                        o,
                        n = V(l),
                        i = this.value,
                        r = n.value;
                    if (0 === r) return z[1];
                    if (0 === i) return z[0];
                    if (1 === i) return z[1];
                    if (-1 === i) return n.isEven() ? z[1] : z[-1];
                    if (n.sign) return z[0];
                    if (!n.isSmall) throw new Error("The exponent " + n.toString() + " is too large.");
                    if (this.isSmall && s(e = p(i, r))) return new c(f(e));
                    for (t = this, o = z[1]; !0 & r && (o = o.times(t), --r), 0 !== r;) {
                        r /= 2, t = t.square();
                    }return o;
                }, c.prototype.pow = K.prototype.pow, K.prototype.modPow = function (l, e) {
                    if (l = V(l), (e = V(e)).isZero()) throw new Error("Cannot take modPow with modulus 0");
                    for (var t = z[1], o = this.mod(e); l.isPositive();) {
                        if (o.isZero()) return z[0];
                        l.isOdd() && (t = t.multiply(o).mod(e)), l = l.divide(2), o = o.square().mod(e);
                    }
                    return t;
                }, c.prototype.modPow = K.prototype.modPow, K.prototype.compareAbs = function (l) {
                    var e = V(l),
                        t = this.value,
                        o = e.value;
                    return e.isSmall ? 1 : L(t, o);
                }, c.prototype.compareAbs = function (l) {
                    var e = V(l),
                        t = Y(this.value),
                        o = e.value;
                    return e.isSmall ? t === (o = Y(o)) ? 0 : t > o ? 1 : -1 : -1;
                }, K.prototype.compare = function (l) {
                    if (l === 1 / 0) return -1;
                    if (l === -1 / 0) return 1;
                    var e = V(l),
                        t = this.value,
                        o = e.value;
                    return this.sign === e.sign ? e.isSmall ? this.sign ? -1 : 1 : L(t, o) * (this.sign ? -1 : 1) : e.sign ? 1 : -1;
                }, K.prototype.compareTo = K.prototype.compare, c.prototype.compare = function (l) {
                    if (l === 1 / 0) return -1;
                    if (l === -1 / 0) return 1;
                    var e = V(l),
                        t = this.value,
                        o = e.value;
                    return e.isSmall ? t == o ? 0 : t > o ? 1 : -1 : 0 > t === e.sign ? 0 > t ? 1 : -1 : 0 > t ? -1 : 1;
                }, c.prototype.compareTo = c.prototype.compare, K.prototype.equals = function (t) {
                    return 0 === this.compare(t);
                }, c.prototype.eq = c.prototype.equals = K.prototype.eq = K.prototype.equals, K.prototype.notEquals = function (t) {
                    return 0 !== this.compare(t);
                }, c.prototype.neq = c.prototype.notEquals = K.prototype.neq = K.prototype.notEquals, K.prototype.greater = function (t) {
                    return 0 < this.compare(t);
                }, c.prototype.gt = c.prototype.greater = K.prototype.gt = K.prototype.greater, K.prototype.lesser = function (t) {
                    return 0 > this.compare(t);
                }, c.prototype.lt = c.prototype.lesser = K.prototype.lt = K.prototype.lesser, K.prototype.greaterOrEquals = function (t) {
                    return 0 <= this.compare(t);
                }, c.prototype.geq = c.prototype.greaterOrEquals = K.prototype.geq = K.prototype.greaterOrEquals, K.prototype.lesserOrEquals = function (t) {
                    return 0 >= this.compare(t);
                }, c.prototype.leq = c.prototype.lesserOrEquals = K.prototype.leq = K.prototype.lesserOrEquals, K.prototype.isEven = function () {
                    return 0 == (1 & this.value[0]);
                }, c.prototype.isEven = function () {
                    return 0 == (1 & this.value);
                }, K.prototype.isOdd = function () {
                    return 1 == (1 & this.value[0]);
                }, c.prototype.isOdd = function () {
                    return 1 == (1 & this.value);
                }, K.prototype.isPositive = function () {
                    return !this.sign;
                }, c.prototype.isPositive = function () {
                    return 0 < this.value;
                }, K.prototype.isNegative = function () {
                    return this.sign;
                }, c.prototype.isNegative = function () {
                    return 0 > this.value;
                }, K.prototype.isUnit = function () {
                    return !1;
                }, c.prototype.isUnit = function () {
                    return 1 === Y(this.value);
                }, K.prototype.isZero = function () {
                    return !1;
                }, c.prototype.isZero = function () {
                    return 0 === this.value;
                }, K.prototype.isDivisibleBy = function (n) {
                    var e = V(n),
                        t = e.value;
                    return 0 !== t && (1 === t || (2 === t ? this.isEven() : this.mod(e).equals(z[0])));
                }, c.prototype.isDivisibleBy = K.prototype.isDivisibleBy, K.prototype.isPrime = function () {
                    var n = P(this);
                    if (void 0 !== n) return n;
                    for (var e, t, o, l, r = this.abs(), a = r.prev(), i = [2, 3, 5, 7, 11, 13, 17, 19], s = a; s.isEven();) {
                        s = s.divide(2);
                    }for (o = 0; o < i.length; o++) {
                        if (!(l = b(i[o]).modPow(s, r)).equals(z[1]) && !l.equals(a)) {
                            for (t = !0, e = s; t && e.lesser(a); e = e.multiply(2)) {
                                (l = l.square().mod(r)).equals(a) && (t = !1);
                            }if (t) return !1;
                        }
                    }return !0;
                }, c.prototype.isPrime = K.prototype.isPrime, K.prototype.isProbablePrime = function (n) {
                    var e = P(this);
                    if (void 0 !== e) return e;
                    for (var t = this.abs(), o = void 0 === n ? 5 : n, l = 0; l < o; l++) {
                        if (!b.randBetween(2, t.minus(2)).modPow(t.prev(), t).isUnit()) return !1;
                    }return !0;
                }, c.prototype.isProbablePrime = K.prototype.isProbablePrime, K.prototype.modInv = function (n) {
                    for (var e, t, o, i = b.zero, r = b.one, a = V(n), l = this.abs(); !l.equals(b.zero);) {
                        e = a.divide(l), t = i, o = a, i = r, a = l, r = t.subtract(e.multiply(r)), l = o.subtract(e.multiply(l));
                    }if (!a.equals(1)) throw new Error(this.toString() + " and " + n.toString() + " are not co-prime");
                    return -1 === i.compare(0) && (i = i.add(n)), this.isNegative() ? i.negate() : i;
                }, c.prototype.modInv = K.prototype.modInv, K.prototype.next = function () {
                    var t = this.value;
                    return this.sign ? u(t, 1, this.sign) : new K(a(t, 1), this.sign);
                }, c.prototype.next = function () {
                    var t = this.value;
                    return t + 1 < o ? new c(t + 1) : new K(ee, !1);
                }, K.prototype.prev = function () {
                    var t = this.value;
                    return this.sign ? new K(a(t, 1), !0) : u(t, 1, this.sign);
                }, c.prototype.prev = function () {
                    var t = this.value;
                    return t - 1 > -o ? new c(t - 1) : new K(ee, !0);
                };
                for (var r = [1]; 2 * r[r.length - 1] <= j;) {
                    r.push(2 * r[r.length - 1]);
                }var R = r.length,
                    M = r[R - 1];
                K.prototype.shiftLeft = function (o) {
                    if (!E(o)) throw new Error(o + "" + " is too large for shifting.");
                    if (0 > (o = +o)) return this.shiftRight(-o);
                    var n = this;
                    if (n.isZero()) return n;
                    for (; o >= R;) {
                        n = n.multiply(M), o -= R - 1;
                    }return n.multiply(r[o]);
                }, c.prototype.shiftLeft = K.prototype.shiftLeft, K.prototype.shiftRight = function (n) {
                    var l;
                    if (!E(n)) throw new Error(n + "" + " is too large for shifting.");
                    if (0 > (n = +n)) return this.shiftLeft(-n);
                    for (var t = this; n >= R;) {
                        if (t.isZero() || t.isNegative() && t.isUnit()) return t;
                        t = (l = I(t, M))[1].isNegative() ? l[0].prev() : l[0], n -= R - 1;
                    }
                    return (l = I(t, r[n]))[1].isNegative() ? l[0].prev() : l[0];
                }, c.prototype.shiftRight = K.prototype.shiftRight, K.prototype.not = function () {
                    return this.negate().prev();
                }, c.prototype.not = K.prototype.not, K.prototype.and = function (t) {
                    return N(this, t, function (o, e) {
                        return o & e;
                    });
                }, c.prototype.and = K.prototype.and, K.prototype.or = function (t) {
                    return N(this, t, function (o, e) {
                        return o | e;
                    });
                }, c.prototype.or = K.prototype.or, K.prototype.xor = function (t) {
                    return N(this, t, function (o, e) {
                        return o ^ e;
                    });
                }, c.prototype.xor = K.prototype.xor;
                var A = 1073741824,
                    G = (j & -j) * (j & -j) | A;
                K.prototype.bitLength = function () {
                    var t = this;
                    return 0 > t.compareTo(b(0)) && (t = t.negate().subtract(b(1))), 0 === t.compareTo(b(0)) ? b(0) : b(function n(e, t) {
                        if (0 >= t.compareTo(e)) {
                            var o = n(e, t.square(t)),
                                i = o.p,
                                s = o.e,
                                a = i.multiply(t);
                            return 0 >= a.compareTo(e) ? {
                                p: a,
                                e: 2 * s + 1
                            } : {
                                p: i,
                                e: 2 * s
                            };
                        }
                        return {
                            p: b(1),
                            e: 0
                        };
                    }(t, b(2)).e).add(b(1));
                }, c.prototype.bitLength = K.prototype.bitLength;
                var x = function x(a, e) {
                    for (var t = a.length, o = Y(e), n = 0; n < t; n++) {
                        if ("-" !== (s = a[n].toLowerCase()) && /[a-z0-9]/.test(s)) {
                            if (/[0-9]/.test(s) && +s >= o) {
                                if ("1" === s && 1 === o) continue;
                                throw new Error(s + " is not a valid digit in base " + e + ".");
                            }
                            if (s.charCodeAt(0) - 87 >= o) throw new Error(s + " is not a valid digit in base " + e + ".");
                        }
                    }if (2 <= e && 36 >= e && t <= 36.7368005696771 / Math.log(e)) {
                        var i = parseInt(a, e);
                        if (isNaN(i)) throw new Error(s + " is not a valid digit in base " + e + ".");
                        return new c(parseInt(a, e));
                    }
                    e = V(e);
                    var r = [],
                        l = "-" === a[0];
                    for (n = l ? 1 : 0; n < a.length; n++) {
                        var s,
                            b = (s = a[n].toLowerCase()).charCodeAt(0);
                        if (48 <= b && 57 >= b) r.push(V(s));else if (97 <= b && 122 >= b) r.push(V(s.charCodeAt(0) - 87));else {
                            if ("<" !== s) throw new Error(s + " is not a valid character");
                            var p = n;
                            do {
                                n++;
                            } while (">" !== a[n]);
                            r.push(V(a.slice(p + 1, n)));
                        }
                    }
                    return O(r, e, l);
                };
                K.prototype.toArray = function (t) {
                    return D(this, t);
                }, c.prototype.toArray = function (t) {
                    return D(this, t);
                }, K.prototype.toString = function (l) {
                    if (void 0 === l && (l = 10), 10 !== l) return X(this, l);
                    for (var e, t = this.value, o = t.length, n = t[--o] + ""; 0 <= --o;) {
                        e = t[o] + "", n += "0000000".slice(e.length) + e;
                    }return (this.sign ? "-" : "") + n;
                }, c.prototype.toString = function (t) {
                    return void 0 === t && (t = 10), 10 == t ? this.value + "" : X(this, t);
                }, K.prototype.toJSON = c.prototype.toJSON = function () {
                    return this.toString();
                }, K.prototype.valueOf = function () {
                    return parseInt(this.toString(), 10);
                }, K.prototype.toJSNumber = K.prototype.valueOf, c.prototype.valueOf = function () {
                    return this.value;
                }, c.prototype.toJSNumber = c.prototype.valueOf;
                for (var e = 0; 1e3 > e; e++) {
                    z[e] = new c(e), 0 < e && (z[-e] = new c(-e));
                }return z.one = z[1], z.zero = z[0], z.minusOne = z[-1], z.max = F, z.min = T, z.gcd = k, z.lcm = function (o, e) {
                    return o = V(o).abs(), e = V(e).abs(), o.divide(k(o, e)).multiply(e);
                }, z.isInstance = function (t) {
                    return t instanceof K || t instanceof c;
                }, z.randBetween = function (t, e) {
                    var o = T(t = V(t), e = V(e)),
                        n = F(t, e).subtract(o).add(1);
                    if (n.isSmall) return o.add(m(Math.random() * n));
                    for (var i = [], s = !0, a = n.value.length - 1; 0 <= a; a--) {
                        var l = s ? n.value[a] : j,
                            d = f(Math.random() * l);
                        i.unshift(d), d < l && (s = !1);
                    }
                    return i = Z(i), o.add("number" == typeof i ? new c(i) : new K(i, !1));
                }, z.fromArray = function (n, e, t) {
                    return O(n.map(V), V(e || 10), t);
                }, z;
            }();
            void 0 !== e && e.hasOwnProperty("exports") && (e.exports = b), "function" == typeof define && define.amd && define("big-integer", [], function () {
                return b;
            });
        }, {}],
        BallEnum: [function (l, e, t) {
            "use strict";

            var o;
            cc._RF.push(e, "fd995/g3jJLGooDqcMvG4LP", "BallEnum"), Object.defineProperty(t, "__esModule", {
                value: !0
            }), function (t) {
                t[t.B1 = 0] = "B1", t[t.B2 = 1] = "B2", t[t.B3 = 2] = "B3", t[t.B4 = 3] = "B4", t[t.B5 = 4] = "B5", t[t.B6 = 5] = "B6", t[t.B7 = 6] = "B7", t[t.B8 = 7] = "B8", t[t.B9 = 8] = "B9", t[t.B10 = 9] = "B10", t[t.B11 = 10] = "B11", t[t.B12 = 11] = "B12", t[t.B13 = 12] = "B13", t[t.B14 = 13] = "B14", t[t.B15 = 14] = "B15", t[t.B16 = 15] = "B16", t[t.B17 = 16] = "B17", t[t.B18 = 17] = "B18", t[t.B19 = 18] = "B19", t[t.B20 = 19] = "B20", t[t.B21 = 20] = "B21", t[t.B22 = 21] = "B22", t[t.B23 = 22] = "B23", t[t.B24 = 23] = "B24", t[t.B25 = 24] = "B25", t[t.B26 = 25] = "B26", t[t.B27 = 26] = "B27", t[t.B28 = 27] = "B28", t[t.B29 = 28] = "B29", t[t.B30 = 29] = "B30", t[t.B31 = 30] = "B31", t[t.B32 = 31] = "B32", t[t.B33 = 32] = "B33", t[t.B34 = 33] = "B34", t[t.B35 = 34] = "B35", t[t.B36 = 35] = "B36", t[t.B37 = 36] = "B37", t[t.B38 = 37] = "B38", t[t.B39 = 38] = "B39", t[t.B40 = 39] = "B40";
            }(o || (o = {})), t.BallEnum = o, cc._RF.pop();
        }, {}],
        BuyBall: [function (l, e, t) {
            "use strict";

            cc._RF.push(e, "66e9aXbOx1BoJLKz8C7hm1w", "BuyBall"), Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var o = function () {
                function t() {
                    this.b0 = -1, this.b1 = -1, this.b2 = -1, this.b3 = -1, this.b4 = -1, this.b5 = -1, this.b6 = -1, this.b7 = -1, this.b8 = -1, this.b9 = -1, this.b10 = -1, this.b11 = -1, this.b12 = -1, this.b13 = -1, this.b14 = -1, this.b15 = -1, this.b16 = -1, this.b17 = -1, this.b18 = -1, this.b19 = -1, this.b20 = -1, this.b21 = -1, this.b22 = -1, this.b23 = -1, this.b24 = -1, this.b25 = -1, this.b26 = -1, this.b27 = -1, this.b28 = -1, this.b29 = -1, this.b30 = -1, this.b31 = -1, this.b32 = -1, this.b33 = -1, this.b34 = -1, this.b35 = -1, this.b36 = -1, this.b37 = -1, this.b38 = -1, this.b39 = -1;
                }
                return t.Instance = new t(), t;
            }();
            t.BuyBall = o, t.default = o, cc._RF.pop();
        }, {}],
        BuySB: [function (l, e, t) {
            "use strict";

            cc._RF.push(e, "c8f6buhdRREVpKRZZTD6Tpo", "BuySB"), Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var o = function () {
                function t() {
                    this.s0 = 0, this.s1 = 0, this.s2 = 0, this.s3 = 0, this.s4 = 0, this.s5 = 0;
                }
                return t.Instance = new t(), t;
            }();
            t.BuySB = o, t.default = o, cc._RF.pop();
        }, {}],
        CommonHelpers: [function (l, e, t) {
            "use strict";

            cc._RF.push(e, "24554LobcFP+qy+LjobdMVZ", "CommonHelpers"), Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var d = l("../config/Const"),
                u = l("../config/Global"),
                b = l("big-integer"),
                o = function () {
                function t() {}
                return t.getBallAttack = function (n) {
                    var e = "_" + n,
                        t = "0";
                    if (0 < u.default.Instance.game.buySB.s0) {
                        var o = b(d.default.f2[e]).multiply(12).divmod(10);
                        t = o.quotient.add(o.remainder).toString();
                    } else t = d.default.f2[e];
                    return t;
                }, t.getSbAttack = function (n) {
                    var e = d.default.SB_NAME["_" + n],
                        t = p(2, e.x),
                        o = this.changeNum(t),
                        a = "0";
                    if (0 < u.default.Instance.game.buySB.s0) {
                        var l = b(o).multiply(12).divmod(10);
                        a = l.quotient.add(l.remainder).toString();
                    } else a = o;
                    return a;
                }, t.getBallPrice = function (n, e) {
                    var t = u.default.Instance.priceCche["b" + n];
                    if (null != t && 0 < e && t.time == e) return 0 < u.default.Instance.game.buySB.s1 ? t.priceP80 : t.price;
                    var o = 10 * p(1.2, e);
                    0 < u.default.Instance.game.buySB.s1 && (o *= .8);
                    var a = this.changeNum(o),
                        l = b(a),
                        r = b(d.default.f4["_" + n]).multiply(l);
                    return 0 < u.default.Instance.game.buySB.s1 ? u.default.Instance.priceCche["b" + n].priceP80 = r.toString() : u.default.Instance.priceCche["b" + n].price = r.toString(), u.default.Instance.priceCche["b" + n].time = e, r;
                }, t.getSBPrice = function (n) {
                    var e = d.default.SB_NAME["_" + n],
                        t = 10 * p(4, e.x);
                    return this.changeNum(t);
                }, t.getBallSpeed = function (o) {
                    var n = +o;
                    return 0 === n && 1, d.default.speed + d.default.speedRate * n;
                }, t.getSBallSpeed = function (o) {
                    var n = +o;
                    return 0 === n && 1, d.default.speed + d.default.speedRate * n;
                }, t.getEmenBall = function (n) {
                    var l = this,
                        t = 100 * p(1.5, n),
                        e = this.changeNum(t),
                        o = {
                        allScore: b(e).toString(),
                        items: []
                    };
                    return d.default.ebp.forEach(function (n) {
                        o.items.push(l.changeNum(t * n.value));
                    }), o;
                }, t.getEmenBallByNum = function (r, e, t) {
                    for (var o = 100 * p(1.5, t), n = this.changeNum(o), i = b(n).minus(b(e)), a = {
                        allScore: i.toString(),
                        items: []
                    }, l = 0; l < r; l++) {
                        a.items.push(this.changeNum(1 * i.toJSNumber() / r));
                    }return a;
                }, t.getOfflinePrice = function (l, e) {
                    var t = 60 * (p(1.5, l) * e) / 10,
                        o = this.changeNum(t);
                    return b(o).toString();
                }, t.changeNum = function (t) {
                    return t.toString().includes("e") ? t.toString() : (+t).toString().split(".")[0];
                }, t.getShowScoreByScore = function (o) {
                    var e = b(o);
                    return e.lesser("1000") ? o : e.lesser("1000000") ? this.getVal(e.toJSNumber() / 1e3) + "K" : e.lesser("1000000000") ? this.getVal(e.toJSNumber() / 1e6) + "m" : e.lesser("1000000000000") ? this.getVal(e.toJSNumber() / 1e9) + "b" : e.lesser("1000000000000000") ? this.getVal(e.toJSNumber() / 1e12) + "t" : e.lesser("1000000000000000000") ? this.getVal(e.toJSNumber() / 1e15) + "q" : e.lesser("1000000000000000000000") ? this.getVal(e.toJSNumber() / 1e18) + "Q" : e.lesser("1000000000000000000000000") ? this.getVal(e.toJSNumber() / 1e21) + "s" : e.lesser("1000000000000000000000000000") ? this.getVal(e.toJSNumber() / 1e24) + "S" : void 0;
                }, t.getVal = function (t) {
                    return 10 > t ? t.toFixed(2) : 100 > t ? t.toFixed(1) : t.toString().substr(0, 3);
                }, t.isBallExist = function (l) {
                    for (var e = u.default.Instance.game.b_ball, t = !1, o = 0; o < e.length; o++) {
                        e[o] == l && (t = !0);
                    }return t;
                }, t.isBallOnceBought = function (t) {
                    return 0 <= u.default.Instance.game.buyBall["b" + t];
                }, t.isSBallExist = function (t) {
                    return 0 < u.default.Instance.game.buySB["s" + t];
                }, t.canBuyBall = function (l) {
                    var e = !1;
                    if (!u.default.Instance.game.canBuyBall(l)) return e;
                    var t = u.default.Instance.game.buyBall["b" + l],
                        o = this.getBallPrice(l, t),
                        n = u.default.Instance.game.money;
                    return b(n).lesser(o) || (e = !0), e;
                }, t.isBallRepeat = function () {
                    for (var o = u.default.Instance.game.b_ball, e = 0; e < o.length && e != o.length - 1; e++) {
                        if (o[e] == o[e + 1]) return !0;
                    }return !1;
                }, t.isballFirstShow = function (t) {
                    return -1 == u.default.Instance.game.firstShow["b" + t];
                }, t.isBallShow = function (t) {
                    return -1 == u.default.Instance.game.buyBall["b" + t];
                }, t.getRepeatBall = function () {
                    for (var o = u.default.Instance.game.b_ball, e = 0; e < o.length && e != o.length - 1; e++) {
                        if (o[e] == o[e + 1]) return e;
                    }
                }, t.getPigBoxReward = function (n, e) {
                    e = void 0 == e || null == e ? 1 : e;
                    var t = 6 * p(1.5, n) * e;
                    return this.changeNum(t);
                }, t.getRankLevel = function () {
                    var n = u.default.Instance.game.rLevel,
                        e = u.default.Instance.game.curLevel,
                        t = null;
                    return void 0 != n && null != n && void 0 != e && null != e && (t = n + "转" + e), t;
                }, t.getRankLevelBy = function (n, e) {
                    var t = null;
                    return void 0 != n && null != n && void 0 != e && null != e && (t = n + "转" + e), t;
                }, t;
            }();
            t.CommonHelpers = o, t.default = o, cc._RF.pop();
        }, {
            "../config/Const": "Const",
            "../config/Global": "Global",
            "big-integer": 1
        }],
        Const: [function (l, e, t) {
            "use strict";

            cc._RF.push(e, "2c3e40jhupDx4k/IyfKIbkJ", "Const"), Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var o = function () {
                function t() {}
                return t.GAME_NAME = "SUPER_BALL", t.GAME_VERISON = "0.0.1", t.f4 = {
                    _0: "4",
                    _1: "16",
                    _2: "64",
                    _3: "256",
                    _4: "1024",
                    _5: "4096",
                    _6: "16384",
                    _7: "65536",
                    _8: "262144",
                    _9: "1048576",
                    _10: "4194304",
                    _11: "16777216",
                    _12: "67108864",
                    _13: "268435456",
                    _14: "1073741824",
                    _15: "4294967296",
                    _16: "17179869184",
                    _17: "68719476736",
                    _18: "274877906944",
                    _19: "1099511627776",
                    _20: "4398046511104",
                    _21: "17592186044416",
                    _22: "70368744177664",
                    _23: "281474976710656",
                    _24: "1125899906842624",
                    _25: "4503599627370496",
                    _26: "18014398509481984",
                    _27: "72057594037927936",
                    _28: "288230376151711744",
                    _29: "1152921504606846976",
                    _30: "4611686018427387904",
                    _31: "18446744073709551616",
                    _32: "73786976294838206464",
                    _33: "295147905179352825856",
                    _34: "1180591620717411303424",
                    _35: "4722366482869645213696",
                    _36: "18889465931478580854784",
                    _37: "75557863725914323419136",
                    _38: "302231454903657293676544",
                    _39: "1208925819614629174706176"
                }, t.f2 = {
                    _0: "2",
                    _1: "4",
                    _2: "8",
                    _3: "16",
                    _4: "32",
                    _5: "64",
                    _6: "128",
                    _7: "256",
                    _8: "512",
                    _9: "1024",
                    _10: "2048",
                    _11: "4096",
                    _12: "8192",
                    _13: "16384",
                    _14: "32768",
                    _15: "65536",
                    _16: "131072",
                    _17: "262144",
                    _18: "524288",
                    _19: "1048576",
                    _20: "2097152",
                    _21: "4194304",
                    _22: "8388608",
                    _23: "16777216",
                    _24: "33554432",
                    _25: "67108864",
                    _26: "134217728",
                    _27: "268435456",
                    _28: "536870912",
                    _29: "1073741824",
                    _30: "2147483648",
                    _31: "4294967296",
                    _32: "8589934592",
                    _33: "17179869184",
                    _34: "34359738368",
                    _35: "68719476736",
                    _36: "137438953472",
                    _37: "274877906944",
                    _38: "549755813888",
                    _39: "1099511627776"
                }, t.BALL_NAME = {
                    _0: "白球",
                    _1: "网球",
                    _2: "篮球",
                    _3: "足球",
                    _4: "棒球",
                    _5: "桌球",
                    _6: "橄榄球",
                    _7: "橙子",
                    _8: "西瓜",
                    _9: "鸡蛋",
                    _10: "甜甜圈",
                    _11: "披萨",
                    _12: "唱片",
                    _13: "太极",
                    _14: "笑脸",
                    _15: "齿轮",
                    _16: "吃豆人",
                    _17: "花瓣",
                    _18: "车轮",
                    _19: "神奇宝贝",
                    _20: "机器猫",
                    _21: "狼人杀",
                    _22: "太阳",
                    _23: "月球",
                    _24: "地球",
                    _25: "火星",
                    _26: "木星",
                    _27: "海王星",
                    _28: "核武器",
                    _29: "原子",
                    _30: "德国",
                    _31: "加拿大",
                    _32: "法国",
                    _33: "巴西",
                    _34: "阿根廷",
                    _35: "西班牙",
                    _36: "俄罗斯",
                    _37: "英国",
                    _38: "美国",
                    _39: "中国"
                }, t.SB_NAME = {
                    _0: {
                        name: "火焰球",
                        buyLevel: 20,
                        x: 8,
                        desc: "所有攻击x1.2"
                    },
                    _1: {
                        name: "冰霜球",
                        buyLevel: 40,
                        x: 15,
                        desc: "价格-20%"
                    },
                    _2: {
                        name: "毒球",
                        buyLevel: 60,
                        x: 21,
                        desc: "绿球受伤+50%"
                    },
                    _3: {
                        name: "电球",
                        buyLevel: 80,
                        x: 26,
                        desc: "所有速度x1.2"
                    },
                    _4: {
                        name: "紫焰球",
                        buyLevel: 120,
                        x: 30,
                        desc: "2%全屏攻击"
                    },
                    _5: {
                        name: "黑暗之球",
                        buyLevel: 160,
                        x: 33,
                        desc: "红球不断受伤"
                    }
                }, t.speedRate = .5, t.speed = 75, t.ebp = [{
                    value: 80 / 1500
                }, {
                    value: 83 / 1500
                }, {
                    value: 85 / 1500
                }, {
                    value: .058
                }, {
                    value: .08
                }, {
                    value: .08
                }, {
                    value: 115 / 1500
                }, {
                    value: .078
                }, {
                    value: 110 / 1500
                }, {
                    value: 103 / 1500
                }, {
                    value: 80 / 1500
                }, {
                    value: .06
                }, {
                    value: 95 / 1500
                }, {
                    value: 110 / 1500
                }, {
                    value: .07
                }], t.CAN_BUY_BALL_NUM = 10, t.GAME_LOGIN = "GAME_LOGIN", t.CUR_GAME = "curGame", t.CUR_COLLECTION_MONEY = "curCollectionMoney", t.CUR_BALL_NUM = "curBallNum", t.CUR_SCORE = "curScore", t.BUY_BALL_CONFIG = {
                    b0: 0,
                    b1: 0,
                    b2: 0,
                    b3: 0,
                    b4: 0,
                    b5: 0,
                    b6: 0,
                    b7: 0,
                    b8: 0,
                    b9: 0,
                    b10: 0,
                    b11: 0,
                    b12: 0,
                    b13: 0,
                    b14: 0,
                    b15: 0,
                    b16: 0,
                    b17: 0,
                    b18: 0,
                    b19: 0,
                    b20: 0,
                    b21: 0,
                    b22: 0,
                    b23: 0,
                    b24: 0,
                    b25: 0,
                    b26: 0,
                    b27: 0,
                    b28: 0,
                    b29: 0,
                    b30: 0,
                    b31: 0,
                    b32: 0,
                    b33: 0,
                    b34: 0,
                    b35: 0,
                    b36: 0,
                    b37: 0,
                    b38: 0,
                    b39: 0
                }, t.BUY_S_BALL_CONFIG = {
                    s0: 0,
                    s1: 0,
                    s2: 0,
                    s3: 0,
                    s4: 0,
                    s5: 0,
                    s6: 0
                }, t.SHARE_1 = "这款弹球游戏你一定没试过", t.SHARE_2 = "这款弹球游戏你一定没试过", t.SHARE_3 = "这款弹球游戏你一定没试过", t.GAIN_SPEED_X2 = 7200, t.GAIN_MONEY_X2 = 14400, t.AOE_RATE = .5, t.OFF_LINE_GAIN_DURATION = 30, t;
            }();
            t.Const = o, t.default = o, cc._RF.pop();
        }, {}],
        EventConst: [function (l, e, t) {
            "use strict";

            cc._RF.push(e, "39d78NEFh1KNJ6pg0fK/Ym6", "EventConst"), Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var o = function () {
                function t() {}
                return t.RF_LABEL_MONEY = 0, t.RF_LABEL_CUR_LEVEL = 1, t.RF_PREFAB_CUR_COLLECTION = 2, t.RF_PREFAB_PROCESS_LINE = 3, t.RF_VAL_COLLECTION_MONEY = 5, t.RS_VAL_COLLECTION_MONEY = 6, t.CV_GAME_CHECK = 7, t.RF_SPRITE_EXP_LINE = 8, t.ADD_CREATE_BALL = 9, t.RF_CUR_GAME_MONEY = 10, t.RF_PREFAB_BALL_ITEM = 11, t.RF_BALL_COUNT_LABEL = 12, t.MINUS_CUR_ENEM_BALL_NUM = 13, t.GET_OFFLINE_MONEY = 14, t.GAIN_SPEED_CB = 15, t.GAIN_MONEY_CB = 16, t.GAIN_CB = 17, t.BALL_SPEED_X2 = 18, t.BALL_MONEY_X2 = 19, t.CLICK_GIFT_BOX_CB = 20, t.BOX_REWARD_CB = 21, t.RF_PREFAB_SB_ITEM = 22, t.SHOW_BUY_SB_COMFIRM = 23, t.RF_SUPER_BALL = 24, t.DO_AOE = 25, t.PLAY_BOOM_PLIST = 26, t.UP_LEVEL = 27, t.GAME_INIT = 28, t.REBIRTH = 29, t.COMMON_REFRESH = 30, t.RF_LEVEL = 31, t.OPEN_RANK = 32, t.PREFAB_BALL_ITEM_INIT_AGAIN = 33, t.WX_LOGIN_CB = 1001, t.BUY_BALL_CB = 1002, t.ADD_MONEY_CB = 1003, t.UP_LEVEL_CB = 1004, t.BUY_SUPER_BALL_CB = 1005, t;
            }();
            t.EventConst = o, t.default = o, cc._RF.pop();
        }, {}],
        FetchService: [function (l, e, t) {
            "use strict";

            cc._RF.push(e, "2df6cw508RI8KwOey3raJbH", "FetchService"), Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var o = function () {
                return function () {};
            }();
            t.default = o, cc._RF.pop();
        }, {}],
        Game: [function (S, e, t) {
            "use strict";

            cc._RF.push(e, "fca68X4ERtBRoeN7m9eOoj9", "Game"), Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var o = cc._decorator,
                n = o.ccclass,
                i = o.property,
                r = S("big-integer"),
                a = S("../utils/CommonHelpers"),
                l = S("../config/Global"),
                c = S("../utils/event_listener"),
                s = S("../utils/EventConst"),
                u = S("../utils/HttpRequestHelpers"),
                p = S("../config/Const"),
                d = S("../../res/prefabs/collection/prefab_money_collection"),
                f = S("../utils/LocalStorageUtils"),
                h = S("../../res/prefabs/hintPannel/Pannel"),
                b = S("../../res/prefabs/hintPannel/hintPannel"),
                _ = S("../../res/prefabs/hintBallPannel/hintBall"),
                B = S("../../res/prefabs/prefab_offline_reward/prefab_offline_reward"),
                g = function (o) {
                function e() {
                    var e = null !== o && o.apply(this, arguments) || this;
                    return e.scoreLabel = null, e.curLevelLabel = null, e.curMoneyLabel = null, e.ballCountLabel = null, e.gameLayer = null, e.pigRefreshTime = 300, e.moneyCollection = null, e.hintPannell = null, e.hintBallPannell = null, e.prefabOfflineRewardPannel = null, e.b_ball = [], e._curLevel = 0, e._curMoney = r("0"), e._curCollection = r("0"), e._curCollectionMoney = r("0"), e._curCollectionMoneyCopy = "0", e._curEnemBallNum = 0, e._curLevelAllScore = r("0"), e.nodePollHelper = null, e.check = !1, e.comBine = !0, e.reBirthFlag = !1, e.curBallArray = [], e.ballMoneyx2 = !1, e.fisrt = !0, e;
                }
                return __extends(e, o), e.prototype.onLoad = function () {
                    this.nodePollHelper = this.node.getComponent("NodePollHelper"), cc.game.setFrameRate(20), this.oldDateInit(), this.gameInit(), this.eventBind(), this.schedule(this.myCheck, 5), this.systemTime = new Date(), l.$.isWechat() && (l.$.mwx.bindEvent(), this.scheduleOnce(function () {
                        l.$.mwx.offLineF();
                    }, 2), wx.showShareMenu({
                        withShareTicket: !0,
                        success: function success() {}
                    }), wx.onShareAppMessage(function () {
                        return {
                            title: p.default.SHARE_1,
                            imageUrl: "https://detective.p8games.com/shareImg?id=11",
                            success: function success() {
                                cc.log("onShareAppMessage s");
                            },
                            fail: function fail() {
                                cc.log("onShareAppMessage f");
                            }
                        };
                    }));
                }, e.prototype.update = function () {
                    if (this.fisrt && (this.fisrt = !1), this.check && null == this.gameLayer.getChildByName("enemyBall") && (this.upLevel(this.curLevel + 1), c.default.Instance.dispatchEvent(s.default.COMMON_REFRESH, null)), this.check && this.comBine && a.default.isBallRepeat()) {
                        var p = this,
                            e = a.default.getRepeatBall();
                        if (void 0 != e) {
                            var d = l.Global.Instance.game.b_ball[e],
                                t = l.Global.Instance.game.b_ball.slice(0, e),
                                n = l.Global.Instance.game.b_ball.slice(e + 2, l.Global.Instance.game.b_ball.length);
                            l.Global.Instance.game.b_ball = t.concat(n), this.findBallByBallNum(d).forEach(function (e) {
                                p.nodePollHelper.delBall(e);
                            });
                            var i = this.nodePollHelper.getMerge();
                            i.parent = this.node, i.getComponent("merageBall").initCur(d + ""), i.getComponent("merageBall").doAction(), this.scheduleOnce(function () {
                                var e = +d + 1 + "",
                                    t = a.default.isBallShow(e),
                                    n = a.default.isballFirstShow(e);
                                t && (l.Global.Instance.game.buyBall["b" + e] = 0, n && (l.Global.Instance.game.firstShow["b" + e] = 0, p.showHintBallPannel(e)), c.default.Instance.dispatchEvent(s.default.PREFAB_BALL_ITEM_INIT_AGAIN, e)), l.Global.Instance.game.pushBBall(e);
                                var i = p.nodePollHelper.getBall();
                                i.getComponent("ball").initBall(e), i.getComponent("ball").setSpeed(), i.parent = p.gameLayer, p.curBallArray.push(i), p.check = !0, p.comBine = !0, c.default.Instance.dispatchEvent(s.default.RF_PREFAB_BALL_ITEM, null), c.default.Instance.dispatchEvent(s.default.RF_BALL_COUNT_LABEL, null);
                            }, 1), this.comBine = !1;
                        }
                        c.default.Instance.dispatchEvent(s.default.COMMON_REFRESH, null);
                    }
                    this.check, this.reBirthFlag && (this.superBallInit(), c.default.Instance.dispatchEvent(s.default.COMMON_REFRESH, null), this.reBirthFlag = !1), this.check && (c.default.Instance.dispatchEvent(s.default.COMMON_REFRESH, null), this.check = !1);
                }, e.prototype.myCheck = function () {
                    f.default.setItem("phonepadgames_ballball_storage", l.Global.Instance.game), f.default.setCurGame();
                    var t = (new Date().getTime() - l.Global.Instance.gainSpeedX2) / 1e3;
                    t > p.default.GAIN_SPEED_X2 - 1 && c.default.Instance.dispatchEvent(s.default.BALL_SPEED_X2, !1), (t = (new Date().getTime() - l.Global.Instance.gainMoneyX2) / 1e3) > p.default.GAIN_MONEY_X2 - 1 && c.default.Instance.dispatchEvent(s.default.BALL_MONEY_X2, !1), new Date().getTime(), this.systemTime.getTime();
                }, e.prototype.gameInit = function () {
                    cc.director.getPhysicsManager().enabled = !0, cc.director.getCollisionManager().enabled = !0, this.ballInit(), this.emenBallInit(), this.superBallInit(), this.rfBallCount(), c.default.Instance.dispatchEvent(s.default.COMMON_REFRESH, null);
                }, e.prototype.ballInit = function () {
                    var o = this;
                    0 != o.b_ball.length && o.b_ball.forEach(function (e) {
                        var t = o.nodePollHelper.getBall();
                        t.getComponent("ball").initBall(e), t.getComponent("ball").setSpeed(), t.parent = o.gameLayer, o.curBallArray.push(t);
                    });
                }, e.prototype.findBallByBallNum = function (o) {
                    return this.gameLayer.children.filter(function (e) {
                        return "ball" == e.name && e.getComponent("ball").num == o;
                    }).slice(0, 2);
                }, e.prototype.emenBallInit = function () {
                    if (this.curLevel = l.Global.Instance.game.curLevel, "0" == l.Global.Instance.game.curScore) {
                        var p = a.default.getEmenBall(this.curLevel),
                            e = this.getEMBallPosition(null);
                        this.curEnemBallNum = e.length;
                        for (var t, n = 0; n < e.length; n++) {
                            t = p.items.pop(), (o = this.nodePollHelper.getEB()).getComponent("enemBall").initEnemBall(t, this.curLevel, p.allScore.toString()), o.parent = this.gameLayer, o.setPosition(e[n].treeX - 290, e[n].treeY - 260);
                        }this.scoreLabel.string = a.default.getShowScoreByScore(p.allScore.toString()), this.curLevelAllScore = r(p.allScore);
                    } else {
                        for (p = a.default.getEmenBallByNum(l.Global.Instance.game.curLBallNum, l.Global.Instance.game.curScore, l.Global.Instance.game.curLevel), e = this.getEMBallPosition(l.Global.Instance.game.curLBallNum), this.curEnemBallNum = e.length, n = 0; n < e.length; n++) {
                            var o;
                            t = p.items.pop(), (o = this.nodePollHelper.getEB()).getComponent("enemBall").initEnemBall(t, this.curLevel, p.allScore.toString()), o.parent = this.gameLayer, o.setPosition(e[n].treeX - 290, e[n].treeY - 260);
                        }
                        this.scoreLabel.string = a.default.getShowScoreByScore(p.allScore.toString()), this.curLevelAllScore = r(l.Global.Instance.game.curLevelAllScore);
                    }
                    c.default.Instance.dispatchEvent(s.default.CV_GAME_CHECK, null);
                }, e.prototype.superBallInit = function () {
                    for (var a = this.gameLayer.children.filter(function (t) {
                        return "sb" == t.name;
                    }), e = 0; e < a.length; e++) {
                        this.nodePollHelper.delBall(a[e]);
                    }if (void 0 != l.Global.Instance.game.buySB) for (var t = Object.keys(l.Global.Instance.game.buySB), o = 0; o < t.length; o++) {
                        if (0 < l.Global.Instance.game.buySB[t[o]]) {
                            var n = this.nodePollHelper.getSBall();
                            n.getComponent("ball").initSB(t[o].split("s")[1]), n.getComponent("ball").setSpeed(), n.parent = this.gameLayer;
                        }
                    }
                }, e.prototype.getEMBallPosition = function (p) {
                    for (var e = [], t = null == p ? 15 : p, o = 0, n = 0; t > o;) {
                        for (var i, s = m(490 * Math.random()) + 40, d = m(420 * Math.random()) + 40, u = !1, l = 0; l < e.length; l++) {
                            i = e[l], 115 > Math.sqrt((i.treeX - s) * (i.treeX - s) + (i.treeY - d) * (i.treeY - d)) && (u = !0);
                        }5e3 == ++n && (n = 0, e = [], o = 0, 0), u || (o++, e.push({
                            treeX: s,
                            treeY: d
                        }));
                    }
                    return e;
                }, e.prototype.oldDateInit = function () {
                    cc.log("oldDateInit");
                    var t = u.default.oldDateInit();
                    this.curMoney = r(t.money), this.b_ball = t.b_ball, this.curLevel = t.curLevel, this.curCollection = r(l.Global.Instance.game.curScore), this.curCollectionMoney = r(t.curCollectionMoney), this.curCollectionMoneyCopy = t.curCollectionMoney;
                }, e.prototype.showHintPannel = function (n, e) {
                    var t = this.hintPannell.getComponent(b.default);
                    t.title = n, t.content = e, this.hintPannell.show();
                }, e.prototype.showHintBallPannel = function (t) {
                    this.hintBallPannell.getComponent(_.default).num = t, this.hintBallPannell.show();
                }, e.prototype.upLevel = function (t) {
                    console.log("upLevel", t), this.curLevel = t, u.default.upLevel(t);
                }, e.prototype.eventBind = function () {
                    console.log("eventBind"), c.default.Instance.addFunc(s.default.RF_VAL_COLLECTION_MONEY, this.rfCurCollectionMoney.bind(this)), c.default.Instance.addFunc(s.default.RS_VAL_COLLECTION_MONEY, this.rsCurCollectionMoney.bind(this)), c.default.Instance.addFunc(s.default.RF_BALL_COUNT_LABEL, this.rfBallCount.bind(this)), c.default.Instance.addFunc(s.default.CV_GAME_CHECK, this.openCheck.bind(this)), c.default.Instance.addFunc(s.default.ADD_CREATE_BALL, this.createBall.bind(this)), c.default.Instance.addFunc(s.default.RF_CUR_GAME_MONEY, this.rfCurMoney.bind(this)), c.default.Instance.addFunc(s.default.ADD_MONEY_CB, this.addMoneyCb.bind(this)), c.default.Instance.addFunc(s.default.UP_LEVEL, this.upLevel.bind(this)), c.default.Instance.addFunc(s.default.UP_LEVEL_CB, this.upLevelCb.bind(this)), c.default.Instance.addFunc(s.default.MINUS_CUR_ENEM_BALL_NUM, this.curEnemBallNumMinus.bind(this)), c.default.Instance.addFunc(s.default.GET_OFFLINE_MONEY, this.getOffLineMoney.bind(this)), c.default.Instance.addFunc(s.default.BALL_MONEY_X2, this.ballMoneyX2CB.bind(this)), c.default.Instance.addFunc(s.default.CLICK_GIFT_BOX_CB, this.gitBoxClickedCB.bind(this)), c.default.Instance.addFunc(s.default.BOX_REWARD_CB, this.boxRewardCB.bind(this)), c.default.Instance.addFunc(s.default.SHOW_BUY_SB_COMFIRM, this.showBuySbConfirm.bind(this)), c.default.Instance.addFunc(s.default.RF_SUPER_BALL, this.rfSuperBall.bind(this)), c.default.Instance.addFunc(s.default.PLAY_BOOM_PLIST, this.playBoomplist.bind(this)), c.default.Instance.addFunc(s.default.REBIRTH, this.rebirth.bind(this)), c.default.Instance.addFunc(s.default.COMMON_REFRESH, this.commonRefresh.bind(this)), c.default.Instance.addFunc(s.default.OPEN_RANK, this.openRank.bind(this));
                }, e.prototype.getCollectionByAttack = function (o) {
                    var e = o;
                    return this.ballMoneyx2 && (e = r(o).multiply(2).toString()), e;
                }, e.prototype.rfCurCollectionMoney = function (t) {
                    this.curCollectionMoney = this.curCollectionMoney.add(this.getCollectionByAttack(t)), this.curCollection = this.curCollection.add(t), this.curCollectionMoneyCopy.substr(0, 3) != this.curCollectionMoney.toString().substr(0, 3) && (this.curCollectionMoneyCopy = this.curCollectionMoney.toString(), c.default.Instance.dispatchEvent(s.default.RF_SPRITE_EXP_LINE, this.curCollection.toJSNumber() / this.curLevelAllScore.toJSNumber()));
                }, e.prototype.rsCurCollectionMoney = function (o) {
                    var e = o;
                    "0" == o && u.default.addMoney(this.curCollectionMoney), "upLevelCb" == o && (u.default.addMoney(this.curCollectionMoney), this.curCollection = r("0"), l.Global.Instance.game.curScore = "0", this.emenBallInit(), e = "0"), this.curCollectionMoney = r(e), this.curCollectionMoneyCopy = a.default.getShowScoreByScore(this.curCollectionMoney.toString()), c.default.Instance.dispatchEvent(s.default.RF_PREFAB_BALL_ITEM, null), c.default.Instance.dispatchEvent(s.default.RF_PREFAB_SB_ITEM, null);
                }, e.prototype.openCheck = function () {
                    this.check = !0, console.log("openCheck");
                }, e.prototype.createBall = function (o) {
                    console.log("createBall"), this.nodePollHelper = this.getComponent("NodePollHelper");
                    var e = this.nodePollHelper.getBall();
                    e.getComponent("ball").initBall(o), e.getComponent("ball").setSpeed(), e.parent = this.gameLayer, this.curBallArray.push(e), this.check = !0, c.default.Instance.dispatchEvent(s.default.RF_PREFAB_BALL_ITEM, null), c.default.Instance.dispatchEvent(s.default.RF_BALL_COUNT_LABEL, null);
                }, e.prototype.rfCurMoney = function () {
                    this.curMoney = r(l.Global.Instance.game.money), c.default.Instance.dispatchEvent(s.default.RF_PREFAB_SB_ITEM, null);
                }, e.prototype.rfBallCount = function () {
                    this.ballCountLabel.string = l.Global.Instance.game.b_ball.length + "/10";
                }, e.prototype.demoSave = function () {
                    cc.director.loadScene("Home");
                }, e.prototype.addMoneyCb = function () {
                    c.default.Instance.dispatchEvent(s.default.RF_CUR_GAME_MONEY, null);
                }, e.prototype.upLevelCb = function () {
                    c.default.Instance.dispatchEvent(s.default.RS_VAL_COLLECTION_MONEY, "upLevelCb"), c.default.Instance.dispatchEvent(s.default.RF_PREFAB_SB_ITEM, null);
                }, e.prototype.curEnemBallNumMinus = function () {
                    --this.curEnemBallNum;
                }, e.prototype.getOffLineMoney = function (o) {
                    if (null != this.node && void 0 != this.node) {
                        var e = a.default.getOfflinePrice(l.Global.Instance.game.curLevel, o);
                        this.prefabOfflineRewardPannel.getComponent(B.default).curMoney = e, this.prefabOfflineRewardPannel.show();
                    }
                }, e.prototype.ballMoneyX2CB = function (t) {
                    this.ballMoneyx2 = t;
                }, e.prototype.gitBoxClickedCB = function (o) {
                    var e = this.nodePollHelper.getBoxReward();
                    e.getComponent("box_reward").initBoxReward(o), e.parent = this.node;
                }, e.prototype.boxRewardCB = function (t) {
                    u.default.addMoney(t + "");
                }, e.prototype.showBuySbConfirm = function (o) {
                    cc.log("Game:showBuySbConfirm");
                    var e = this.nodePollHelper.getBuySBall();
                    e.parent = this.node, e.getComponent("prefab_buy_super_ball").initCur(o);
                }, e.prototype.rfSuperBall = function () {
                    u.default.rfSuperBall();
                }, e.prototype.playBoomplist = function (n) {
                    try {
                        var e = this.nodePollHelper.getPlist();
                        if (e.position = n.pos, e.parent = this.node, null != e) {
                            var t = this;
                            e.getComponent("plist").playOnece(n.type), this.scheduleOnce(function () {
                                t.nodePollHelper.delPlist(e);
                            }, 1);
                        }
                    } catch (t) {
                        console.log("Game:" + t);
                    }
                }, e.prototype.rebirth = function () {
                    for (var n = this.gameLayer.children.filter(function (t) {
                        return "enemyBall" == t.name;
                    }), e = 0; e < n.length; e++) {
                        this.nodePollHelper.delEB(n[e]);
                    }var t = this.gameLayer.children.filter(function (t) {
                        return "ball" == t.name;
                    });
                    for (e = 0; e < t.length; e++) {
                        this.nodePollHelper.delBall(t[e]);
                    }this.curCollection = r("0"), this.curCollectionMoney = r("0"), this.curCollectionMoneyCopy = "0", this.reBirthFlag = !0, c.default.Instance.dispatchEvent(s.default.UP_LEVEL, 1), c.default.Instance.removeFuncAll(s.default.RF_PREFAB_BALL_ITEM), c.default.Instance.removeFuncAll(s.default.BUY_BALL_CB), c.default.Instance.dispatchEvent(s.default.PREFAB_BALL_ITEM_INIT_AGAIN, null);
                }, e.prototype.commonRefresh = function () {
                    c.default.Instance.dispatchEvent(s.default.RF_BALL_COUNT_LABEL, null), c.default.Instance.dispatchEvent(s.default.RF_SPRITE_EXP_LINE, this.curCollection.toJSNumber() / this.curLevelAllScore.toJSNumber());
                }, e.prototype.openRank = function () {
                    if (cc.sys.platform === cc.sys.WECHAT_GAME) {
                        var t = this.node.getChildByName("rank");
                        t.active = !0, t.getComponent("rank").nodePool = this.nodePollHelper, t.getComponent("rank").doInitRank();
                    }
                }, Object.defineProperty(e.prototype, "curMoney", {
                    get: function get() {
                        return this._curMoney;
                    },
                    set: function set(t) {
                        this._curMoney = t, this.curMoneyLabel.string = a.default.getShowScoreByScore(this.curMoney.toString());
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "curCollection", {
                    get: function get() {
                        return this._curCollection;
                    },
                    set: function set(t) {
                        this._curCollection = t, l.Global.Instance.game.curScore = this.curCollection.toString();
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "curCollectionMoney", {
                    get: function get() {
                        return this._curCollectionMoney;
                    },
                    set: function set(t) {
                        this._curCollectionMoney = t, l.Global.Instance.game.curCollectionMoney = this.curCollectionMoney.toString(), this.moneyCollection.rfCollectionMoney(a.default.getShowScoreByScore(this.curCollectionMoney.toString()));
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "curCollectionMoneyCopy", {
                    get: function get() {
                        return this._curCollectionMoneyCopy;
                    },
                    set: function set(t) {
                        this._curCollectionMoneyCopy = t, this.moneyCollection.rfCollectionMoney(a.default.getShowScoreByScore(this.curCollectionMoney.toString()));
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "curLevel", {
                    get: function get() {
                        return this._curLevel;
                    },
                    set: function set(t) {
                        this._curLevel = t, l.Global.Instance.game.curLevel = t, this.curLevelLabel.string = this.curLevel + "级";
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "curEnemBallNum", {
                    get: function get() {
                        return this._curEnemBallNum;
                    },
                    set: function set(t) {
                        this._curEnemBallNum = t, l.Global.Instance.game.curLBallNum = this.curEnemBallNum;
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "curLevelAllScore", {
                    get: function get() {
                        return this._curLevelAllScore;
                    },
                    set: function set(t) {
                        this._curLevelAllScore = t, l.Global.Instance.game.curLevelAllScore = t.toString();
                    },
                    enumerable: !0,
                    configurable: !0
                }), __decorate([i(cc.Label)], e.prototype, "scoreLabel", void 0), __decorate([i(cc.Label)], e.prototype, "curLevelLabel", void 0), __decorate([i(cc.Label)], e.prototype, "curMoneyLabel", void 0), __decorate([i(cc.Label)], e.prototype, "ballCountLabel", void 0), __decorate([i(cc.Node)], e.prototype, "gameLayer", void 0), __decorate([i], e.prototype, "pigRefreshTime", void 0), __decorate([i(d.default)], e.prototype, "moneyCollection", void 0), __decorate([i(h.default)], e.prototype, "hintPannell", void 0), __decorate([i(h.default)], e.prototype, "hintBallPannell", void 0), __decorate([i(h.default)], e.prototype, "prefabOfflineRewardPannel", void 0), e = __decorate([n], e);
            }(cc.Component);
            t.default = g, cc._RF.pop();
        }, {
            "../../res/prefabs/collection/prefab_money_collection": "prefab_money_collection",
            "../../res/prefabs/hintBallPannel/hintBall": "hintBall",
            "../../res/prefabs/hintPannel/Pannel": "Pannel",
            "../../res/prefabs/hintPannel/hintPannel": "hintPannel",
            "../../res/prefabs/prefab_offline_reward/prefab_offline_reward": "prefab_offline_reward",
            "../config/Const": "Const",
            "../config/Global": "Global",
            "../utils/CommonHelpers": "CommonHelpers",
            "../utils/EventConst": "EventConst",
            "../utils/HttpRequestHelpers": "HttpRequestHelpers",
            "../utils/LocalStorageUtils": "LocalStorageUtils",
            "../utils/event_listener": "event_listener",
            "big-integer": 1
        }],
        Global: [function (b, e, t) {
            "use strict";

            cc._RF.push(e, "25ec7LjSHpKzaRN+q7Sb3Cy", "Global"), Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var o = b("../vo/BuyBall"),
                n = b("../vo/BuySB"),
                i = b("./Const"),
                r = b("../utils/PriceCache"),
                a = b("../wx/WXCommonData"),
                l = b("../utils/LocalStorageUtils"),
                c = b("../utils/event_listener"),
                s = b("../utils/EventConst"),
                u = function () {
                function t() {
                    this.b_ball = ["0"], this.s_ball = [], this.curLevel = 1, this.money = "100", this.buyBall = o.BuyBall.Instance, this.firstShow = null, this.buySB = n.default.Instance, this.curCollectionMoney = "100", this.curLBallNum = 0, this.curScore = "0", this.offline_coin = "0", this.rLevel = 0, this.curLevelAllScore = "", cc.log("GameData");
                }
                return t.prototype.pushBBall = function (t) {
                    this.b_ball.push(t), this.b_ball = this.b_ball.sort(this.sortNumber);
                }, t.prototype.sortNumber = function (o, e) {
                    return o - e;
                }, t.prototype.setAll = function (p, e, t, o, n, i, r, a, l, d) {
                    this.b_ball = p, this.b_ball = this.b_ball.sort(this.sortNumber), this.curLevel = e, this.money = t, void 0 == o && null == o && "" == o || (this.curCollectionMoney = o), this.buyBall = n, this.firstShow = d, this.buySB = i, this.curScore = r, this.curLBallNum = a, this.curLevelAllScore = l;
                }, t.prototype.setAllByObj = function (t) {
                    this.setAll(t.b_ball, t.curLevel, t.money, t.curCollectionMoney, d.copy(t.buyBall), d.copy(t.buySB), t.curScore, t.curLBallNum, t.curLevelAllScore, d.copy(t.firstShow));
                }, t.prototype.setBuySb = function (l) {
                    if (void 0 != l && null != l) for (var e, n = Object.keys(l), t = 0; t < n.length; t++) {
                        e = n[t], this.buySB[e] = l[e];
                    }
                }, t.prototype.canBuyBall = function (t) {
                    return this.b_ball.length < i.default.CAN_BUY_BALL_NUM || -1 != this.b_ball.indexOf(t);
                }, t.prototype.canBuyBallOnlyWithBallNum = function () {
                    return this.b_ball.length < i.default.CAN_BUY_BALL_NUM + 1;
                }, t.prototype.gameInit = function () {
                    console.log(p.gameMB.buyBall), this.b_ball = [], this.buyBall = p.gameMB.buyBall, this.curLevel = 1, this.curCollectionMoney = "0", this.rLevel++;
                }, t.Instance = new t(), t;
            }();
            t.GameData = u;
            var p,
                d,
                f = function () {
                function t() {
                    this.game = u.Instance, this.gainSpeedX2 = 0, this.gainMoneyX2 = 0, this.offLineSwitch = !0, this.priceCche = r.default.Instance;
                }
                return t.Instance = new t(), t;
            }();
            t.Global = f, t.default = f, function (l) {
                function e(e) {
                    console.log("afterLogin", e), l.shareSwitch = void 0 != e.data.can_relive || 1 == e.data.can_relive;
                }
                l.account = null, l.shareSwitch = !1, l.gameMB = {
                    b_ball: [],
                    curLevel: 1,
                    money: "100",
                    curCollection: "0",
                    curCollectionMoney: "0",
                    buyBall: {
                        b0: 0,
                        b1: 0,
                        b2: -1,
                        b3: -1,
                        b4: -1,
                        b5: -1,
                        b6: -1,
                        b7: -1,
                        b8: -1,
                        b9: -1,
                        b10: -1,
                        b11: -1,
                        b12: -1,
                        b13: -1,
                        b14: -1,
                        b15: -1,
                        b16: -1,
                        b17: -1,
                        b18: -1,
                        b19: -1,
                        b20: -1,
                        b21: -1,
                        b22: -1,
                        b23: -1,
                        b24: -1,
                        b25: -1,
                        b26: -1,
                        b27: -1,
                        b28: -1,
                        b29: -1,
                        b30: -1,
                        b31: -1,
                        b32: -1,
                        b33: -1,
                        b34: -1,
                        b35: -1,
                        b36: -1,
                        b37: -1,
                        b38: -1,
                        b39: -1
                    },
                    firstShow: {
                        b0: 0,
                        b1: 0,
                        b2: -1,
                        b3: -1,
                        b4: -1,
                        b5: -1,
                        b6: -1,
                        b7: -1,
                        b8: -1,
                        b9: -1,
                        b10: -1,
                        b11: -1,
                        b12: -1,
                        b13: -1,
                        b14: -1,
                        b15: -1,
                        b16: -1,
                        b17: -1,
                        b18: -1,
                        b19: -1,
                        b20: -1,
                        b21: -1,
                        b22: -1,
                        b23: -1,
                        b24: -1,
                        b25: -1,
                        b26: -1,
                        b27: -1,
                        b28: -1,
                        b29: -1,
                        b30: -1,
                        b31: -1,
                        b32: -1,
                        b33: -1,
                        b34: -1,
                        b35: -1,
                        b36: -1,
                        b37: -1,
                        b38: -1,
                        b39: -1
                    },
                    buySB: {
                        s0: 0,
                        s1: 0,
                        s2: 0,
                        s3: 0,
                        s4: 0,
                        s5: 0,
                        s6: 0
                    }
                }, l.isLogin = function () {
                    return void 0 != l.account;
                }, l.afterLogin = e, l.requestGameLogin = function () {
                    return new Promise(function (t, o) {
                        wx.login({
                            success: function success() {
                                wx.request({
                                    url: "https://detective.p8games.com/infinateBall/login",
                                    data: {
                                        code: a.default.Instance.wx_code,
                                        encryptedData: a.default.Instance.encryptedData,
                                        iv: a.default.Instance.encryptedData,
                                        ver: i.default.GAME_VERISON
                                    },
                                    success: function success(o) {
                                        return l.account = o.data, e(o), t(o);
                                    },
                                    fail: function fail() {
                                        return o();
                                    }
                                });
                            }
                        });
                    }).then(function () {}).catch(function () {}), new Promise(function (t) {
                        return cc.sys.platform == cc.sys.WECHAT_GAME ? void wx.request({
                            url: "https://detective.p8games.com/infinateBall/login",
                            data: {
                                code: a.default.Instance.wx_code,
                                encryptedData: a.default.Instance.encryptedData,
                                iv: a.default.Instance.encryptedData,
                                ver: i.default.GAME_VERISON
                            },
                            success: function success(o) {
                                return l.account = o.data, e(o), t(o.data);
                            }
                        }) : t(null);
                    });
                };
            }(p = t.http || (t.http = {})), function (n) {
                n.isWechat = function () {
                    return cc.sys.platform === cc.sys.WECHAT_GAME;
                }, n.copy = function (n) {
                    var e = {};
                    for (var t in n) {
                        e[t] = n[t];
                    }return e;
                }, n.nowTimeStamp = function () {
                    return new Date().getTime();
                }, n.nowTime = function () {
                    return new Date().getTime() / 1e3;
                }, n.getDateByTimeStamp = function (t) {
                    return new Date(t);
                }, n.getDateByTime = function (t) {
                    return new Date(1e3 * t);
                }, function (e) {
                    function d(t) {
                        wx.showToast({
                            title: t,
                            icon: "none",
                            duration: 2e3
                        });
                    }
                    function t() {
                        console.log("offLineF");
                        var e = l.default.getOffLine();
                        if (null == e) l.default.initGetOffLine();else {
                            var t = (n.nowTime() - e.off_line_time) / 60;
                            t > i.default.OFF_LINE_GAIN_DURATION && 1440 > t ? c.default.Instance.dispatchEvent(s.default.GET_OFFLINE_MONEY, t) : t > i.default.OFF_LINE_GAIN_DURATION && c.default.Instance.dispatchEvent(s.default.GET_OFFLINE_MONEY, t);
                        }
                    }
                    e.isShareToQun = function (t) {
                        return void 0 != t.shareTickets;
                    }, e.showToastWithTitle = d, e.checkShare = function (o, u, t) {
                        var n = void 0 == f.Instance.account.dayTimes ? 1 : f.Instance.account.dayTimes;
                        console.log(n), wx.getShareInfo({
                            shareTicket: o.shareTickets[0],
                            success: function success() {
                                wx.request({
                                    url: "https://detective.p8games.com/queryOpenGID",
                                    data: {
                                        session_key: p.account.session_key,
                                        iv: a.default.Instance.iv,
                                        encryptedData: a.default.Instance.encryptedData
                                    },
                                    success: function success(o) {
                                        console.log("queryOpenGID:", o);
                                        var i = o.data.openGId;
                                        wx.getStorage({
                                            key: i + u,
                                            success: function success(o) {
                                                console.log("getStorage:"), console.log(o);
                                                var e = o.data,
                                                    a = e.relive.time,
                                                    l = e.relive.times,
                                                    r = function (l) {
                                                    var e = new Date(l),
                                                        t = new Date(),
                                                        o = e.getFullYear() == t.getFullYear() && e.getMonth() == t.getMonth() && e.getDate() == t.getDate();
                                                    return console.log("isSameDate:" + o), o;
                                                }(a);
                                                r && n <= l ? d("分享失败:单群每天只有" + n + "次分享机会") : r ? (t(), wx.setStorage({
                                                    key: i + u,
                                                    data: {
                                                        relive: {
                                                            time: new Date().getTime(),
                                                            times: l + 1
                                                        }
                                                    }
                                                })) : (t(), wx.setStorage({
                                                    key: i + u,
                                                    data: {
                                                        relive: {
                                                            time: new Date().getTime(),
                                                            times: 1
                                                        }
                                                    }
                                                }));
                                            },
                                            fail: function fail() {
                                                t(), wx.setStorage({
                                                    key: i + u,
                                                    data: {
                                                        relive: {
                                                            time: new Date().getTime(),
                                                            times: 1
                                                        }
                                                    }
                                                });
                                            }
                                        });
                                    }
                                });
                            }
                        });
                    }, e.moreGame = function (o) {
                        var e = void 0 == o || null == o ? ["https://detectivecdn.p8games.com/moreGame1.jpg"] : o;
                        wx.previewImage({
                            urls: e
                        });
                    }, e.bindEvent = function () {
                        wx.onHide(function () {}), wx.onShow(function () {
                            t();
                        });
                    }, e.offLineF = t;
                }(n.mwx || (n.mwx = {}));
            }(d = t.$ || (t.$ = {})), cc._RF.pop();
        }, {
            "../utils/EventConst": "EventConst",
            "../utils/LocalStorageUtils": "LocalStorageUtils",
            "../utils/PriceCache": "PriceCache",
            "../utils/event_listener": "event_listener",
            "../vo/BuyBall": "BuyBall",
            "../vo/BuySB": "BuySB",
            "../wx/WXCommonData": "WXCommonData",
            "./Const": "Const"
        }],
        Home: [function (b, e, t) {
            "use strict";

            cc._RF.push(e, "07e3apK4XdOW7Ht5zDrq8px", "Home"), Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var o = cc._decorator,
                n = o.ccclass,
                i = o.property,
                r = b("../utils/HttpRequestHelpers"),
                a = b("../utils/event_listener"),
                l = b("../utils/EventConst"),
                c = b("../config/Global"),
                s = b("../config/Const"),
                u = b("../WXButton"),
                p = b("../wx/WXCommonData"),
                d = function (o) {
                function e() {
                    var e = null !== o && o.apply(this, arguments) || this;
                    return e.btnMoreGame = null, e.btStartGame = null, e.btnShareNode = null, e.btRank = null, e.lbLogin = null, e.levelNode = null, e.levelLabel = null, e.btnLogin = null, e.rankNode = null, e;
                }
                return __extends(e, o), e.prototype.onLoad = function () {
                    this.btnBind(), a.default.Instance.addFunc(l.default.WX_LOGIN_CB, this.wxLoginSuccess.bind(this)), a.default.Instance.addFunc(l.default.RF_LEVEL, this.rfLevel.bind(this));
                }, e.prototype.start = function () {
                    var n = this;
                    if (cc.sys.platform === cc.sys.WECHAT_GAME) if (c.http.isLogin()) {
                        var e = this.lbLogin;
                        e.string = "点击屏幕登陆游戏...", e.node.opacity = 255, e.node.runAction(cc.repeatForever(cc.blink(1.2, 1))), wx.login({
                            success: function success(t) {
                                console.log("wx:login", t), p.default.Instance.wx_account = t, n.btnLogin.node.on("click", function (t) {
                                    p.default.Instance.userinfoRes = t, e.string = "登录中...", e.node.stopAllActions(), e.node.runAction(cc.repeatForever(cc.blink(1.2, 1))), c.http.requestGameLogin().then(function () {
                                        n.btnLogin.getComponent(u.default).setInteractable(!1), e.string = "登录成功", e.node.stopAllActions(), e.scheduleOnce(function () {
                                            e.node.opacity = 0;
                                        }, 1);
                                    }).catch(function () {});
                                }, this);
                            }
                        });
                    } else n.btnLogin.getComponent(u.default).setInteractable(!1), a.default.Instance.dispatchEvent(l.default.RF_LEVEL, null);
                    c.$.isWechat() && wx.showShareMenu({
                        withShareTicket: !0,
                        success: function success() {}
                    });
                }, e.prototype.btnBind = function () {
                    var t = this;
                    this.btnMoreGame.on(cc.Node.EventType.TOUCH_END, function () {
                        r.default.moreGame();
                    }), this.btStartGame.on(cc.Node.EventType.TOUCH_END, function () {
                        cc.director.loadScene("Game"), a.default.Instance.removeAll();
                    }), this.btnShareNode.on(cc.Node.EventType.TOUCH_END, function () {
                        c.Global.Instance.offLineSwitch = !0, c.$.isWechat() && wx.shareAppMessage({
                            title: s.default.SHARE_1,
                            imageUrl: "https://detective.p8games.com/shareImg?id=11",
                            success: function success() {
                                t.scheduleOnce(function () {
                                    c.Global.Instance.offLineSwitch = !0;
                                }, 1);
                            },
                            fail: function fail() {
                                t.scheduleOnce(function () {
                                    c.Global.Instance.offLineSwitch = !0;
                                }, 1);
                            }
                        });
                    }), this.btRank.on(cc.Node.EventType.TOUCH_END, function () {
                        cc.log("btnRank");
                        var e = t.rankNode;
                        e.active = !0, e.getComponent("rank").nodePool = t.getComponent("NodePollHelper"), e.getComponent("rank").doInitRank();
                    });
                }, e.prototype.wxLoginSuccess = function () {
                    r.default.bindEvent();
                }, e.prototype.rfLevel = function () {
                    var o = c.Global.Instance.game.rLevel,
                        e = c.Global.Instance.game.curLevel;
                    if (void 0 != o && null != o && void 0 != e && null != e) {
                        this.levelNode.opacity = 255;
                        this.levelLabel.string = o + "转" + e;
                    }
                }, __decorate([i(cc.Node)], e.prototype, "btnMoreGame", void 0), __decorate([i(cc.Node)], e.prototype, "btStartGame", void 0), __decorate([i(cc.Node)], e.prototype, "btnShareNode", void 0), __decorate([i(cc.Node)], e.prototype, "btRank", void 0), __decorate([i(cc.Label)], e.prototype, "lbLogin", void 0), __decorate([i(cc.Node)], e.prototype, "levelNode", void 0), __decorate([i(cc.Label)], e.prototype, "levelLabel", void 0), __decorate([i(u.default)], e.prototype, "btnLogin", void 0), __decorate([i(cc.Node)], e.prototype, "rankNode", void 0), e = __decorate([n], e);
            }(cc.Component);
            t.default = d, cc._RF.pop();
        }, {
            "../WXButton": "WXButton",
            "../config/Const": "Const",
            "../config/Global": "Global",
            "../utils/EventConst": "EventConst",
            "../utils/HttpRequestHelpers": "HttpRequestHelpers",
            "../utils/event_listener": "event_listener",
            "../wx/WXCommonData": "WXCommonData"
        }],
        HttpHelper: [function (o, e) {
            "use strict";

            function t(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            function l() {
                console.log("HttpHelper:gameLogin"), console.log(i.Global.Instance.data);
                var a = i.Global.Instance.data.coin1,
                    e = i.Global.Instance.data.coin2,
                    t = i.Global.Instance.data.coin3.toString() + e.toString() + a.toString(),
                    B = [],
                    C = r.default.BUY_S_BALL_CONFIG,
                    I = r.default.BUY_BALL_CONFIG;
                if (S(i.Global.Instance.data.b_ball)) for (var L = Object.keys(i.Global.Instance.data.b_ball), p = 0; p < L.length; p++) {
                    0 != i.Global.Instance.data.b_ball[L[p]] && B.push(L[p].split("b")[1]);
                }if (S(i.Global.Instance.data.b_offline_coin)) {
                    var d = i.Global.Instance.data.b_offline_coin[1],
                        f = d[0].toString() + d[1].toString() + d[2].toString();
                    i.Global.Instance.game.offline_coin = f;
                }
                if (S(i.Global.Instance.data.b_buy)) for (var h = Object.keys(i.Global.Instance.data.b_buy), b = 0; b < h.length; b++) {
                    I[h[b]] = i.Global.Instance.data.b_buy[h[b]];
                }if (S(i.Global.Instance.data.b_super)) for (var _ = Object.keys(i.Global.Instance.data.b_super), m = 0; m < _.length; m++) {
                    C[_[m]] = i.Global.Instance.data.b_super[_[m]];
                }S(i.Global.Instance.data.rLevel) && (i.Global.Instance.game.rLevel = i.Global.Instance.data.rLevel);
                var g = i.Global.Instance.data.level;
                wx.getStorage({
                    key: r.default.GAME_NAME + ":" + r.default.CUR_GAME,
                    success: function success(o) {
                        console.log("getStorage:"), console.log(o);
                        var e = o.data;
                        i.Global.Instance.game.curCollectionMoney = e.curCollectionMoney, i.Global.Instance.game.curLBallNum = e.curLBallNum, i.Global.Instance.game.curLScore = e.curLScore, i.Global.Instance.game.curScore = e.curScore, i.Global.Instance.gainSpeedX2 = void 0 == e.gainSpeedX2 || null == e.gainSpeedX2 ? 0 : e.gainSpeedX2, i.Global.Instance.gainMoneyX2 = void 0 == e.gainMoneyX2 || null == e.gainMoneyX2 ? 0 : e.gainMoneyX2, console.log(i.Global.Instance.game), u.default.Instance.dispatchEvent(n.default.WX_LOGIN_CB, o);
                    },
                    fail: function fail() {
                        wx.setStorage({
                            key: r.default.GAME_NAME + ":" + r.default.CUR_GAME,
                            data: {
                                curCollectionMoney: "0",
                                curLBallNum: 0,
                                curLScore: "0",
                                curScore: "0"
                            },
                            success: function success() {
                                u.default.Instance.dispatchEvent(n.default.WX_LOGIN_CB, P);
                            }
                        });
                    }
                });
                var P = {
                    b_ball: B,
                    curLevel: g,
                    money: t,
                    curCollectionMoney: "",
                    buyBall: I,
                    buySball: C
                };
                console.log(P), i.Global.Instance.game.setAllByObj(P), u.default.Instance.dispatchEvent(n.default.RF_LEVEL, null);
            }
            function S(t) {
                return void 0 != t && null != t;
            }
            cc._RF.push(e, "51c7esd7GdMf6EHj+kay5o0", "HttpHelper");
            var u = t(o("./event_listener")),
                n = t(o("./EventConst")),
                i = o("../config/Global"),
                r = t(o("../config/Const"));
            t(o("./CommonHelpers"));
            var p = o("big-integer");
            e.exports = {
                isLogin: function isLogin() {
                    return void 0 != window.account;
                },
                login: function login() {
                    wx.request({
                        url: "https://detective.p8games.com/infinateBall/login",
                        data: {
                            code: window.wx_code,
                            encryptedData: window.wx_accout.encryptedData,
                            iv: window.wx_accout.iv
                        },
                        success: function success(t) {
                            afterLogin(t), window.account = t.data, console.log("# ok"), console.log(t), i.Global.Instance.data = t.data.data, l();
                        }
                    });
                },
                gameLogin: l,
                moreGame: function moreGame() {
                    wx.previewImage({
                        urls: ["https://detectivecdn.p8games.com/moreGame1.jpg"]
                    });
                },
                buyBall: function buyBall(r) {
                    wx.request({
                        url: "https://detective.p8games.com/infinateBall/buyBall",
                        data: {
                            session: window.account.session,
                            id: parseInt(r)
                        },
                        success: function success(e) {
                            console.log("buyBa ll"), console.log(e);
                            var t = e.data,
                                o = t.coin1,
                                a = t.coin2,
                                l = t.coin3.toString() + a.toString() + o.toString();
                            i.Global.Instance.game.money = p(l), i.Global.Instance.game.buyBall = function (l) {
                                var e = i.Global.Instance.game.buyBall;
                                if (S(l)) for (var t = Object.keys(l), o = 0; o < t.length; o++) {
                                    e[t[o]] = l[t[o]];
                                }return e;
                            }(t.b_buy), u.default.Instance.dispatchEvent(n.default.BUY_BALL_CB, r);
                        }
                    });
                },
                addMoney: function addMoney(o) {
                    var e = function (n) {
                        var e = [],
                            t = p(n);
                        return t.lesser("1000000000") ? e = [t.toJSNumber(), 0, 0] : !t.lesser("1000000000") && t.lesser("1000000000000000000") ? e = [n.substr(n.length - 9, 10), n.substr(0, n.length - 9), 0] : t.lesser("1000000000000000000") || (e = [n.substr(n.length - 9, 9), n.substr(n.length - 18, 9), n.substr(0, n.length - 18)]), e;
                    }(o);
                    wx.request({
                        url: "https://detective.p8games.com/infinateBall/fetchCoin",
                        data: {
                            session: window.account.session,
                            coin1: parseInt(e[0]),
                            coin2: parseInt(e[1]),
                            coin3: parseInt(e[2])
                        },
                        success: function success(r) {
                            console.log("addMoney"), console.log(r);
                            var e = r.data,
                                t = e.coin1,
                                o = e.coin2,
                                a = e.coin3.toString() + o.toString() + t.toString();
                            i.Global.Instance.game.money = p(a), u.default.Instance.dispatchEvent(n.default.ADD_MONEY_CB, null);
                        }
                    });
                },
                upLevel: function upLevel() {
                    wx.request({
                        url: "https://detective.p8games.com/infinateBall/levelup",
                        data: {
                            session: window.account.session
                        },
                        success: function success(t) {
                            console.log("upLevel"), console.log(t), i.Global.Instance.game.curLevel = t.data.level, u.default.Instance.dispatchEvent(n.default.UP_LEVEL_CB, null);
                        }
                    });
                },
                bindEvent: function bindEvent() {
                    wx.onHide(function () {
                        console.log("onHide CB");
                    }), wx.onShow(function () {
                        console.log("onShow CB"), setTimeout(function () {
                            console.log("sleep 1sec");
                        }, 1e3);
                    });
                },
                showShareMenu: function showShareMenu(t) {
                    cc.sys.platform === cc.sys.WECHAT_GAME && wx.showShareMenu(t);
                },
                shareAppMessage: function shareAppMessage(t) {
                    cc.sys.platform === cc.sys.WECHAT_GAME && wx.shareAppMessage(t);
                },
                isShareToQun: function isShareToQun(t) {
                    return void 0 != t.shareTickets;
                },
                showToast: function showToast(t) {
                    wx.showToast(t);
                },
                checkShare: function checkShare(l, s, t) {
                    var o = void 0 == i.Global.Instance.account.dayTimes ? 1 : i.Global.Instance.account.dayTimes;
                    console.log(o), wx.getShareInfo({
                        shareTicket: l.shareTickets[0],
                        success: function success(n) {
                            wx.request({
                                url: "https://detective.p8games.com/queryOpenGID",
                                data: {
                                    session_key: window.session_key,
                                    iv: n.iv,
                                    encryptedData: n.encryptedData
                                },
                                success: function success(n) {
                                    console.log("queryOpenGID:"), console.log(n);
                                    var p = n.data.openGId;
                                    wx.getStorage({
                                        key: p + s,
                                        success: function success(n) {
                                            console.log("getStorage:"), console.log(n);
                                            var e = n.data,
                                                r = e.relive.time,
                                                a = e.relive.times,
                                                l = function (l) {
                                                var e = new Date(l),
                                                    t = new Date(),
                                                    o = e.getFullYear() == t.getFullYear() && e.getMonth() == t.getMonth() && e.getDate() == t.getDate();
                                                return console.log("isSameDate:" + o), o;
                                            }(r);
                                            l && o <= a ? function (t) {
                                                wx.showToast({
                                                    title: t,
                                                    icon: "none",
                                                    duration: 2e3,
                                                    success: function success() {}
                                                });
                                            }("分享失败:单群每天只有" + o + "次分享机会") : l ? (t(), wx.setStorage({
                                                key: p + s,
                                                data: {
                                                    relive: {
                                                        time: new Date().getTime(),
                                                        times: a + 1
                                                    }
                                                }
                                            })) : (t(), wx.setStorage({
                                                key: p + s,
                                                data: {
                                                    relive: {
                                                        time: new Date().getTime(),
                                                        times: 1
                                                    }
                                                }
                                            }));
                                        },
                                        fail: function fail() {
                                            t(), wx.setStorage({
                                                key: p + s,
                                                data: {
                                                    relive: {
                                                        time: new Date().getTime(),
                                                        times: 1
                                                    }
                                                }
                                            });
                                        }
                                    });
                                }
                            });
                        }
                    });
                },
                buySuperBall: function buySuperBall(r) {
                    wx.request({
                        url: "https://detective.p8games.com/infinateBall/rebirth",
                        data: {
                            session: window.account.session,
                            id: parseInt(r)
                        },
                        success: function success(e) {
                            console.log("buySuperBall"), console.log(e);
                            var t = e.data,
                                o = t.coin1,
                                a = t.coin2,
                                l = t.coin3.toString() + a.toString() + o.toString();
                            i.Global.Instance.game.money = p(l), i.Global.Instance.game.rLevel = t.rLevel, i.Global.Instance.game.setBuySb(t.b_super), u.default.Instance.dispatchEvent(n.default.BUY_SUPER_BALL_CB, r);
                        }
                    });
                }
            }, cc._RF.pop();
        }, {
            "../config/Const": "Const",
            "../config/Global": "Global",
            "./CommonHelpers": "CommonHelpers",
            "./EventConst": "EventConst",
            "./event_listener": "event_listener",
            "big-integer": 1
        }],
        HttpRequestHelpers: [function (d, e, t) {
            "use strict";

            cc._RF.push(e, "e4203ayxuFGF5y/eoiUMQMT", "HttpRequestHelpers"), Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var b = d("../config/Global"),
                o = d("big-integer"),
                n = d("./event_listener"),
                r = d("./EventConst"),
                a = d("./CommonHelpers"),
                l = d("../config/Const"),
                i = d("./LocalStorageUtils"),
                s = d("./HttpHelper"),
                c = function () {
                function t() {}
                return t.oldDateInit = function () {
                    var n = i.default.getItem("phonepadgames_ballball_storage"),
                        e = i.default.getCurGame();
                    if (console.log(n), null == n) {
                        var t = b.http.gameMB;
                        return b.Global.Instance.game.setAllByObj(t), t;
                    }
                    return console.log("gameData:"), console.log(n), b.Global.Instance.game.setAllByObj(n), console.log(b.Global.Instance.game), b.Global.Instance.gainMoneyX2 = e.gainMoneyX2, b.Global.Instance.gainSpeedX2 = e.gainSpeedX2, n;
                }, t.login = function () {
                    if (cc.sys.platform === cc.sys.WECHAT_GAME) return b.Global.Instance.game;
                    var t = {
                        b_ball: [],
                        curLevel: 1,
                        money: "40",
                        curCollectionMoney: "0",
                        buyBall: {
                            b0: 0,
                            b1: 0,
                            b2: -1,
                            b3: -1,
                            b4: -1,
                            b5: -1,
                            b6: -1,
                            b7: -1,
                            b8: -1,
                            b9: -1,
                            b10: -1,
                            b11: -1,
                            b12: -1,
                            b13: -1,
                            b14: -1,
                            b15: -1,
                            b16: -1,
                            b17: -1,
                            b18: -1,
                            b19: -1,
                            b20: -1,
                            b21: -1,
                            b22: -1,
                            b23: -1,
                            b24: -1,
                            b25: -1,
                            b26: -1,
                            b27: -1,
                            b28: -1,
                            b29: -1,
                            b30: -1,
                            b31: -1,
                            b32: -1,
                            b33: -1,
                            b34: -1,
                            b35: -1,
                            b36: -1,
                            b37: -1,
                            b38: -1,
                            b39: -1
                        },
                        buySball: {
                            s0: 0,
                            s1: 0,
                            s2: 0,
                            s3: 0,
                            s4: 0,
                            s5: 0,
                            s6: 0
                        }
                    };
                    return b.Global.Instance.game.setAllByObj(t), t;
                }, t.addMoney = function (t) {
                    "0" == t || (b.Global.Instance.game.money = o(t).add(b.Global.Instance.game.money).toString(), n.default.Instance.dispatchEvent(r.default.ADD_MONEY_CB, null));
                }, t.buyBall = function (l) {
                    var e = a.default.getBallPrice(l, b.Global.Instance.game.buyBall["b" + l]);
                    b.Global.Instance.game.money = o(b.Global.Instance.game.money).minus(e).toString(), b.Global.Instance.game.buyBall["b" + l] += 1, n.default.Instance.dispatchEvent(r.default.BUY_BALL_CB, l), cc.sys.platform, cc.sys.WECHAT_GAME;
                }, t.buySB = function (l) {
                    var e = a.default.getSBPrice(l);
                    b.Global.Instance.game.money = o(b.Global.Instance.game.money).minus(e).toString(), b.Global.Instance.game.buySB["s" + l] += 1, ++b.Global.Instance.game.rLevel, n.default.Instance.dispatchEvent(r.default.BUY_SUPER_BALL_CB, l);
                }, t.rfSuperBall = function () {
                    b.Global.Instance.game.gameInit(), n.default.Instance.dispatchEvent(r.default.REBIRTH, null);
                }, t.moreGame = function () {
                    console.log("moreGame"), cc.sys.platform === cc.sys.WECHAT_GAME && b.$.mwx.moreGame();
                }, t.upLevel = function () {
                    n.default.Instance.dispatchEvent(r.default.UP_LEVEL_CB, null);
                }, t.bindEvent = function () {
                    s.bindEvent();
                }, t.gainSpeedShare = function () {
                    cc.sys.platform === cc.sys.WECHAT_GAME ? (b.Global.Instance.offLineSwitch = !1, s.shareAppMessage({
                        title: l.default.SHARE_1,
                        imageUrl: "https://detective.p8games.com/shareImg?id=11",
                        success: function success(t) {
                            b.Global.Instance.offLineSwitch = !0, s.isShareToQun(t) ? s.checkShare(t, ":gain_speed", function () {
                                n.default.Instance.dispatchEvent(r.default.GAIN_SPEED_CB, null), n.default.Instance.dispatchEvent(r.default.BALL_SPEED_X2, !0);
                            }) : s.showToast({
                                title: "分享失败请分享到群",
                                icon: "none",
                                duration: 2e3,
                                success: function success() {}
                            });
                        },
                        fail: function fail() {
                            b.Global.Instance.offLineSwitch = !0;
                        }
                    })) : (n.default.Instance.dispatchEvent(r.default.GAIN_SPEED_CB, null), n.default.Instance.dispatchEvent(r.default.BALL_SPEED_X2, !0));
                }, t.gainMoneyShare = function () {
                    cc.sys.platform === cc.sys.WECHAT_GAME ? (b.Global.Instance.offLineSwitch = !1, s.shareAppMessage({
                        title: l.default.SHARE_1,
                        imageUrl: "https://detective.p8games.com/shareImg?id=11",
                        success: function success(t) {
                            s.isShareToQun(t) ? s.checkShare(t, ":gain_money", function () {
                                n.default.Instance.dispatchEvent(r.default.GAIN_MONEY_CB, null), n.default.Instance.dispatchEvent(r.default.BALL_MONEY_X2, !0);
                            }) : s.showToast({
                                title: "分享失败请分享到群",
                                icon: "none",
                                duration: 2e3,
                                success: function success() {}
                            }), b.Global.Instance.offLineSwitch = !0;
                        },
                        fail: function fail() {
                            b.Global.Instance.offLineSwitch = !0;
                        }
                    })) : (n.default.Instance.dispatchEvent(r.default.GAIN_MONEY_CB, null), n.default.Instance.dispatchEvent(r.default.BALL_MONEY_X2, !0));
                }, t.HTTP_PREFIX = "HTTP_TEST", t.ALL_MONEY = "ALL_MONEY", t.game = {
                    b_ball: [],
                    curLevel: 1
                }, t;
            }();
            t.HttpRequestHelpers = c, t.default = c, cc._RF.pop();
        }, {
            "../config/Const": "Const",
            "../config/Global": "Global",
            "./CommonHelpers": "CommonHelpers",
            "./EventConst": "EventConst",
            "./HttpHelper": "HttpHelper",
            "./LocalStorageUtils": "LocalStorageUtils",
            "./event_listener": "event_listener",
            "big-integer": 1
        }],
        LocalStorageUtils: [function (l, e, t) {
            "use strict";

            cc._RF.push(e, "c24c1/Tr9NHrrldV5RgPd8e", "LocalStorageUtils"), Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var o = l("../config/Const"),
                n = l("../config/Global"),
                i = cc._decorator,
                r = (i.ccclass, i.property, function () {
                function l() {}
                return l.setItem = function (e, t) {
                    cc.sys.localStorage.setItem(l.PREFIX + e, JSON.stringify(t));
                }, l.getItem = function (e) {
                    var t = cc.sys.localStorage.getItem(l.PREFIX + e);
                    return "" == t ? null : JSON.parse(t);
                }, l.removeItem = function (e) {
                    cc.sys.localStorage.removeItem(l.PREFIX + e);
                }, l.setCurGame = function () {
                    l.setItem(l.PREFIX + ":" + o.default.CUR_GAME, {
                        gainSpeedX2: n.default.Instance.gainSpeedX2,
                        gainMoneyX2: n.default.Instance.gainMoneyX2
                    });
                }, l.getCurGame = function () {
                    return l.getItem(l.PREFIX + ":" + o.default.CUR_GAME);
                }, l.setOffLine = function () {
                    l.setItem(l.PREFIX + ":off_line", {
                        off_line_time: n.$.nowTime()
                    });
                }, l.getOffLine = function () {
                    return l.getItem(l.PREFIX + ":off_line");
                }, l.initGetOffLine = function () {
                    l.setItem(l.PREFIX + ":off_line", {
                        off_line_time: n.$.nowTime()
                    });
                }, l.PREFIX = "INFINATE_BALL:", l;
            }());
            t.default = r, cc._RF.pop();
        }, {
            "../config/Const": "Const",
            "../config/Global": "Global"
        }],
        NodePollHelper: [function (p, e, t) {
            "use strict";

            cc._RF.push(e, "f2018as1ERBAI/54fTYS/a0", "NodePollHelper"), Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var o = p("../config/Global"),
                n = p("./event_listener"),
                i = p("./EventConst"),
                r = cc._decorator,
                a = r.ccclass,
                l = r.property,
                d = function (r) {
                function e() {
                    var e = null !== r && r.apply(this, arguments) || this;
                    return e.bollPrefab = null, e.ebPrefab = null, e.ballRewardPrefab = null, e.gitfBoxPrefab = null, e.boxRewardPrefab = null, e.buySBallPrefab = null, e.plistPrefab = null, e.mergePrefab = null, e.rankPrefab = null, e.myScorePrefab = null, e.ballPoolSize = 15, e.ballNodePoll = new cc.NodePool(), e.ebPoolSize = 17, e.ebNodePoll = new cc.NodePool(), e.ballRewardSize = 2, e.ballRewardPoll = new cc.NodePool(), e.offlineRewardSize = 2, e.offlineRewardPool = new cc.NodePool(), e.gitfBoxSize = 2, e.gitfBoxPool = new cc.NodePool(), e.boxRewardSize = 2, e.boxRewardPool = new cc.NodePool(), e.buySBallSize = 2, e.buySBallPool = new cc.NodePool(), e.plistSize = 15, e.plistPool = new cc.NodePool(), e.mergeSize = 1, e.mergePool = new cc.NodePool(), e.rankSize = 0, e.rankPool = new cc.NodePool(), e.myScoreSize = 30, e.myScorePool = new cc.NodePool(), e;
                }
                return __extends(e, r), e.prototype.onLoad = function () {
                    null != o.default.Instance.ballPool && void 0 != o.default.Instance.ballPool ? this.ballNodePoll = o.default.Instance.ballPool : (this.ballPrefabsInit(), o.default.Instance.ballPool = this.ballNodePoll), null != o.default.Instance.enemBallPool && void 0 != o.default.Instance.enemBallPool ? this.ebNodePoll = o.default.Instance.enemBallPool : (this.enemBallPrefabsInit(), o.default.Instance.enemBallPool = this.ebNodePoll), null != o.default.Instance.ballRewardPool && void 0 != o.default.Instance.ballRewardPool ? this.ballRewardPoll = o.default.Instance.ballRewardPool : (this.ballRewardInit(), o.default.Instance.ballRewardPool = this.ballRewardPoll), null != o.default.Instance.gitfBoxPool && void 0 != o.default.Instance.gitfBoxPool ? this.gitfBoxPool = o.default.Instance.gitfBoxPool : (this.gitfBoxPoolInit(), o.default.Instance.gitfBoxPool = this.gitfBoxPool), null != o.default.Instance.boxRewardPool && void 0 != o.default.Instance.boxRewardPool ? this.boxRewardPool = o.default.Instance.boxRewardPool : (this.boxRewardPoolInit(), o.default.Instance.boxRewardPool = this.boxRewardPool), null != o.default.Instance.buySBallPool && void 0 != o.default.Instance.buySBallPool ? this.buySBallPool = o.default.Instance.buySBallPool : (this.buySBallPoolInit(), o.default.Instance.buySBallPool = this.buySBallPool), null != o.default.Instance.plistPool && void 0 != o.default.Instance.plistPool ? this.plistPool = o.default.Instance.plistPool : (this.plistPoolInit(), o.default.Instance.plistPool = this.plistPool), null != o.default.Instance.mergePool && void 0 != o.default.Instance.mergePool ? this.mergePool = o.default.Instance.mergePool : (this.mergePoolInit(), o.default.Instance.mergePool = this.mergePool), null != o.default.Instance.rankPool && void 0 != o.default.Instance.rankPool ? this.rankPool = o.default.Instance.rankPool : (this.rankPoolInit(), o.default.Instance.rankPool = this.rankPool), null != o.default.Instance.myScorePool && void 0 != o.default.Instance.myScorePool ? this.myScorePool = o.default.Instance.myScorePool : (this.myScorePoolInit(), o.default.Instance.myScorePool = this.myScorePool);
                }, e.prototype.update = function () {}, e.prototype.start = function () {}, e.prototype.ballPrefabsInit = function () {
                    cc.log("ballPrefabsInit");
                    for (var o = this.ballPoolSize, e = 0; e < o; e++) {
                        this.ballNodePoll.put(cc.instantiate(this.bollPrefab));
                    }
                }, e.prototype.getBall = function () {
                    var t = null;
                    return 0 < this.ballNodePoll.size() ? (t = this.ballNodePoll.get()).getComponent("ball").nodePool = this : (t = cc.instantiate(this.bollPrefab)).getComponent("ball").nodePool = this, t.name = "ball", t;
                }, e.prototype.getSBall = function () {
                    var t = null;
                    return 0 < this.ballNodePoll.size() ? (t = this.ballNodePoll.get()).getComponent("ball").nodePool = this : (t = cc.instantiate(this.bollPrefab)).getComponent("ball").nodePool = this, t.name = "sb", t;
                }, e.prototype.delBall = function (t) {
                    this.ballNodePoll.put(t);
                }, e.prototype.clearAllBall = function () {
                    this.ballNodePoll.clear();
                }, e.prototype.enemBallPrefabsInit = function () {
                    cc.log("enemBallPrefabsInit");
                    for (var n, o = this.ebPoolSize, e = 0; e <= o; e++) {
                        n = cc.instantiate(this.ebPrefab), this.ebNodePoll.put(n);
                    }
                }, e.prototype.getEB = function () {
                    var t = null;
                    return 0 < this.ebNodePoll.size() ? (t = this.ebNodePoll.get()).getComponent("enemBall").nodePoll = this : (t = cc.instantiate(this.ebPrefab)).getComponent("enemBall").nodePoll = this, t.name = "enemyBall", t;
                }, e.prototype.delEB = function (t) {
                    this.ebNodePoll.put(t), n.default.Instance.dispatchEvent(i.default.MINUS_CUR_ENEM_BALL_NUM, null);
                }, e.prototype.clearAllEB = function () {
                    this.ebNodePoll.clear();
                }, e.prototype.ballRewardInit = function () {
                    cc.log("ballRewardInit");
                    for (var o = this.ballRewardSize, e = 0; e < o; e++) {
                        this.ballRewardPoll.put(cc.instantiate(this.ballRewardPrefab));
                    }
                }, e.prototype.getBallReward = function () {
                    var t = null;
                    return 0 < this.ballRewardPoll.size() ? (t = this.ballRewardPoll.get()).getComponent("ball_reward").nodePoll = this : (t = cc.instantiate(this.ballRewardPrefab)).getComponent("ball_reward").nodePoll = this, t;
                }, e.prototype.delBallReward = function (t) {
                    this.ballRewardPoll.put(t);
                }, e.prototype.clearAllBallReward = function () {
                    this.ballRewardPoll.clear();
                }, e.prototype.delOfflineReward = function (t) {
                    this.offlineRewardPool.put(t);
                }, e.prototype.clearAllOfflineReward = function () {
                    this.offlineRewardPool.clear();
                }, e.prototype.gitfBoxPoolInit = function () {
                    cc.log("gitfBoxPoolInit");
                    for (var o = this.gitfBoxSize, e = 0; e < o; e++) {
                        this.gitfBoxPool.put(cc.instantiate(this.gitfBoxPrefab));
                    }
                }, e.prototype.getGiftBox = function () {
                    var t = null;
                    return 0 < this.gitfBoxPool.size() ? (t = this.gitfBoxPool.get()).getComponent("prefab_gift_box").nodePoll = this : (t = cc.instantiate(this.gitfBoxPrefab)).getComponent("prefab_gift_box").nodePoll = this, t;
                }, e.prototype.delGitfBox = function (t) {
                    cc.log("delGitfBox"), this.gitfBoxPool.put(t);
                }, e.prototype.boxRewardPoolInit = function () {
                    cc.log("boxRewardPoolInit");
                    for (var o = this.boxRewardSize, e = 0; e < o; e++) {
                        this.boxRewardPool.put(cc.instantiate(this.boxRewardPrefab));
                    }
                }, e.prototype.getBoxReward = function () {
                    var t = null;
                    return 0 < this.boxRewardPool.size() ? (t = this.boxRewardPool.get()).getComponent("box_reward").nodePoll = this : (t = cc.instantiate(this.gitfBoxPrefab)).getComponent("box_reward").nodePoll = this, t;
                }, e.prototype.delBoxReward = function (t) {
                    this.boxRewardPool.put(t);
                }, e.prototype.buySBallPoolInit = function () {
                    cc.log("buySBallPoolInit");
                    for (var o = this.buySBallSize, e = 0; e < o; e++) {
                        this.buySBallPool.put(cc.instantiate(this.buySBallPrefab));
                    }
                }, e.prototype.getBuySBall = function () {
                    var t = null;
                    return 0 < this.buySBallPool.size() ? (t = this.buySBallPool.get()).getComponent("prefab_buy_super_ball").nodePool = this : (t = cc.instantiate(this.buySBallPrefab)).getComponent("prefab_buy_super_ball").nodePool = this, t;
                }, e.prototype.delBuySBall = function (t) {
                    this.buySBallPool.put(t);
                }, e.prototype.plistPoolInit = function () {
                    cc.log("plistPoolInit");
                    for (var o = this.plistSize, e = 0; e < o; e++) {
                        this.plistPool.put(cc.instantiate(this.plistPrefab));
                    }
                }, e.prototype.getPlist = function () {
                    var t = null;
                    return 0 < this.plistPool.size() && ((t = this.plistPool.get()).getComponent("plist").nodePool = this), t;
                }, e.prototype.delPlist = function (t) {
                    this.plistPool.put(t);
                }, e.prototype.mergePoolInit = function () {
                    cc.log("mergePoolInit");
                    for (var o = this.mergeSize, e = 0; e < o; e++) {
                        this.mergePool.put(cc.instantiate(this.mergePrefab));
                    }
                }, e.prototype.getMerge = function () {
                    var t = null;
                    return 0 < this.mergePool.size() ? (t = this.mergePool.get()).getComponent("merageBall").nodePool = this : (t = cc.instantiate(this.mergePrefab)).getComponent("merageBall").nodePool = this, t;
                }, e.prototype.delMerge = function (t) {
                    t.destroy();
                }, e.prototype.rankPoolInit = function () {
                    cc.log("rankPoolInit");
                    for (var o = this.rankSize, e = 0; e < o; e++) {
                        this.rankPool.put(cc.instantiate(this.rankPrefab));
                    }
                }, e.prototype.getRank = function () {
                    var t = null;
                    return 0 < this.rankPool.size() ? (t = this.rankPool.get()).getComponent("rank").nodePool = this : (t = cc.instantiate(this.rankPrefab)).getComponent("rank").nodePool = this, t;
                }, e.prototype.delRank = function (t) {
                    this.rankPool.put(t);
                }, e.prototype.myScorePoolInit = function () {
                    cc.log("myScoreInite");
                    for (var o = this.myScoreSize, e = 0; e < o; e++) {
                        this.myScorePool.put(cc.instantiate(this.myScorePrefab));
                    }
                }, e.prototype.getMyScore = function () {
                    var t = null;
                    return 0 < this.myScorePool.size() ? (t = this.myScorePool.get()).getComponent("myScore").nodePool = this : (t = cc.instantiate(this.myScorePrefab)).getComponent("myScore").nodePool = this, t;
                }, e.prototype.delMyScore = function (t) {
                    this.myScorePool.put(t);
                }, e.prototype.demo = function () {}, e.prototype.clearAllNodePool = function () {
                    this.clearAllBall(), this.clearAllEB(), this.clearAllBallReward(), this.clearAllOfflineReward();
                }, __decorate([l(cc.Prefab)], e.prototype, "bollPrefab", void 0), __decorate([l(cc.Prefab)], e.prototype, "ebPrefab", void 0), __decorate([l(cc.Prefab)], e.prototype, "ballRewardPrefab", void 0), __decorate([l(cc.Prefab)], e.prototype, "gitfBoxPrefab", void 0), __decorate([l(cc.Prefab)], e.prototype, "boxRewardPrefab", void 0), __decorate([l(cc.Prefab)], e.prototype, "buySBallPrefab", void 0), __decorate([l(cc.Prefab)], e.prototype, "plistPrefab", void 0), __decorate([l(cc.Prefab)], e.prototype, "mergePrefab", void 0), __decorate([l(cc.Prefab)], e.prototype, "rankPrefab", void 0), __decorate([l(cc.Prefab)], e.prototype, "myScorePrefab", void 0), e = __decorate([a], e);
            }(cc.Component);
            t.default = d, cc._RF.pop();
        }, {
            "../config/Global": "Global",
            "./EventConst": "EventConst",
            "./event_listener": "event_listener"
        }],
        Pannel: [function (l, e, t) {
            "use strict";

            cc._RF.push(e, "c8a7a7U2vlBJ7XogMMmO3Ge", "Pannel"), Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var o = cc._decorator,
                n = o.ccclass,
                i = o.property,
                r = function (o) {
                function e() {
                    var e = null !== o && o.apply(this, arguments) || this;
                    return e.firstActive = !1, e.showScale = !1, e.opacity = 150, e.blocker = null, e.background = null, e.btnClose = null, e;
                }
                return __extends(e, o), e.prototype.onLoad = function () {
                    this.firstActive ? (this.node.opacity = 255, this.blocker.opacity = this.opacity) : this.node.active && (this.node.opacity = 255, this.node.active = !1, this.blocker.opacity = this.opacity), this.btnClose && this.btnClose.node.on("click", this.onBtnClose, this);
                }, e.prototype.show = function () {
                    this.node.active = !0, this.node.emit("show"), this.showScale && (this.background.scale = .6, this.background.runAction(cc.scaleTo(.02, 1)));
                }, e.prototype.hide = function () {
                    this.node.emit("hide"), this.node.active = !1;
                }, e.prototype.onBtnClose = function () {
                    this.hide();
                }, __decorate([i({
                    displayName: "First Acitve "
                })], e.prototype, "firstActive", void 0), __decorate([i({
                    displayName: "Show Scale "
                })], e.prototype, "showScale", void 0), __decorate([i({
                    displayName: "Blocker Opacity"
                })], e.prototype, "opacity", void 0), __decorate([i({
                    type: cc.Node,
                    displayName: "Touch Blocker"
                })], e.prototype, "blocker", void 0), __decorate([i({
                    type: cc.Node,
                    displayName: "Panel Background"
                })], e.prototype, "background", void 0), __decorate([i({
                    type: cc.Button,
                    displayName: "Close Button"
                })], e.prototype, "btnClose", void 0), e = __decorate([n], e);
            }(cc.Component);
            t.Pannel = r, t.default = r, cc._RF.pop();
        }, {}],
        PriceCache: [function (l, e, t) {
            "use strict";

            cc._RF.push(e, "82831fYFItCHqBX7Ud2AeB2", "PriceCache"), Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var o = function () {
                function t() {
                    this.time = 0;
                }
                return Object.defineProperty(t.prototype, "time", {
                    get: function get() {
                        return this._time;
                    },
                    set: function set(t) {
                        this._time = t;
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(t.prototype, "price", {
                    get: function get() {
                        return this._price;
                    },
                    set: function set(t) {
                        this._price = t;
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(t.prototype, "priceP80", {
                    get: function get() {
                        return this._priceP80;
                    },
                    set: function set(t) {
                        this._priceP80 = t;
                    },
                    enumerable: !0,
                    configurable: !0
                }), t;
            }();
            t.Price = o;
            var n = function () {
                function t() {
                    this.b0 = new o(), this.b1 = new o(), this.b2 = new o(), this.b3 = new o(), this.b4 = new o(), this.b5 = new o(), this.b6 = new o(), this.b7 = new o(), this.b8 = new o(), this.b9 = new o(), this.b10 = new o(), this.b11 = new o(), this.b12 = new o(), this.b13 = new o(), this.b14 = new o(), this.b15 = new o(), this.b16 = new o(), this.b17 = new o(), this.b18 = new o(), this.b19 = new o(), this.b20 = new o(), this.b21 = new o(), this.b22 = new o(), this.b23 = new o(), this.b24 = new o(), this.b25 = new o(), this.b26 = new o(), this.b27 = new o(), this.b28 = new o(), this.b29 = new o(), this.b30 = new o(), this.b31 = new o(), this.b32 = new o(), this.b33 = new o(), this.b34 = new o(), this.b35 = new o(), this.b36 = new o(), this.b37 = new o(), this.b38 = new o(), this.b39 = new o();
                }
                return t.Instance = new t(), t;
            }();
            t.PriceCache = n, t.default = n, cc._RF.pop();
        }, {}],
        WXButton: [function (l, e, t) {
            "use strict";

            cc._RF.push(e, "f8b6aQHFXVCyY5N2fkJJsRl", "WXButton"), Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var o = cc._decorator,
                n = o.ccclass,
                i = o.property,
                r = function (o) {
                function e() {
                    var e = null !== o && o.apply(this, arguments) || this;
                    return e._btnWX = null, e._interactable = !0, e;
                }
                return __extends(e, o), e.prototype.onLoad = function () {
                    var s = this,
                        e = this.node.getContentSize(),
                        t = this.node.parent.convertToWorldSpaceAR(this.node.getPosition());
                    if (cc.sys.platform == cc.sys.WECHAT_GAME) {
                        var o = cc.Canvas.instance,
                            n = cc.view.getDesignResolutionSize(),
                            i = cc.view.getFrameSize();
                        if (o.fitHeight) var r = i.height / n.height;else r = i.width / n.width;
                        e.height *= r, e.width *= r, t.x *= r, t.y *= r, t.x, e.width, n.height, t.y, e.height;
                        var a = e.width,
                            p = e.height;
                        this._btnWX = wx.createUserInfoButton({
                            type: "image",
                            image: "",
                            style: {
                                left: 0,
                                top: 0,
                                width: a,
                                height: p
                            }
                        }), this._btnWX.onTap(function (e) {
                            console.log("btnWXClicked"), s.node.emit("click", e);
                        });
                    }
                }, e.prototype.start = function () {
                    this._btnWX && (this._interactable ? this._btnWX.show() : this._btnWX.hide());
                }, e.prototype.onDestroy = function () {
                    this._btnWX && this._btnWX.destroy();
                }, e.prototype.setInteractable = function (t) {
                    this._interactable = t, this._btnWX && (t ? this._btnWX.show() : this._btnWX.hide());
                }, e.prototype.getInteractable = function () {
                    return this._interactable;
                }, __decorate([i], e.prototype, "interactable", void 0), e = __decorate([n], e);
            }(cc.Component);
            t.default = r, cc._RF.pop();
        }, {}],
        WXCommonData: [function (l, e, t) {
            "use strict";

            cc._RF.push(e, "0dee3fxhNNNLLvX4P7PT7xe", "WXCommonData"), Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var o = function () {
                function t() {}
                return Object.defineProperty(t.prototype, "wx_account", {
                    get: function get() {
                        return this._wx_account;
                    },
                    set: function set(t) {
                        this._wx_account = t, this.wx_code = t.coe;
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(t.prototype, "userinfoRes", {
                    get: function get() {
                        return this._userinfoRes;
                    },
                    set: function set(t) {
                        this._userinfoRes = t, this.userInfo = t.userInfo, this.encryptedData = t.encryptedData, this.iv = t.iv;
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(t.prototype, "wx_code", {
                    get: function get() {
                        return this._wx_code;
                    },
                    set: function set(t) {
                        this._wx_code = t;
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(t.prototype, "userInfo", {
                    get: function get() {
                        return this._userInfo;
                    },
                    set: function set(t) {
                        this._userInfo = t;
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(t.prototype, "encryptedData", {
                    get: function get() {
                        return this._encryptedData;
                    },
                    set: function set(t) {
                        this._encryptedData = t;
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(t.prototype, "iv", {
                    get: function get() {
                        return this._iv;
                    },
                    set: function set(t) {
                        this._iv = t;
                    },
                    enumerable: !0,
                    configurable: !0
                }), t.Instance = new t(), t;
            }();
            t.WXCommonData = o, t.default = o, cc._RF.pop();
        }, {}],
        ball_reward: [function (s, e, t) {
            "use strict";

            cc._RF.push(e, "c0a26fEkgdHKb/zv5/APiqq", "ball_reward"), Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var p = s("../../../scripts/utils/CommonHelpers"),
                n = s("../../../scripts/config/Const"),
                o = cc._decorator,
                r = o.ccclass,
                a = o.property,
                l = function (o) {
                function e() {
                    var e = null !== o && o.apply(this, arguments) || this;
                    return e.closeNode = null, e.rewardNode = null, e.itemNameLabel = null, e.attackLabel = null, e.ballSprite = null, e;
                }
                return __extends(e, o), e.prototype.onLoad = function () {
                    this.closeNode.on(cc.Node.EventType.TOUCH_END, function () {}), this.rewardNode.on(cc.Node.EventType.TOUCH_END, function () {});
                }, e.prototype.start = function () {}, e.prototype.initBallReward = function (l) {
                    var a = this,
                        e = n.default.f2["_" + l],
                        t = p.default.getShowScoreByScore(e);
                    this.attackLabel.string = t, cc.loader.loadRes("ball/_" + l, cc.SpriteFrame, function (t, e) {
                        t ? cc.error(t.message || t) : a.ballSprite.spriteFrame = e;
                    });
                }, __decorate([a(cc.Node)], e.prototype, "closeNode", void 0), __decorate([a(cc.Node)], e.prototype, "rewardNode", void 0), __decorate([a(cc.Label)], e.prototype, "itemNameLabel", void 0), __decorate([a(cc.Label)], e.prototype, "attackLabel", void 0), __decorate([a(cc.Sprite)], e.prototype, "ballSprite", void 0), e = __decorate([r], e);
            }(cc.Component);
            t.default = l, cc._RF.pop();
        }, {
            "../../../scripts/config/Const": "Const",
            "../../../scripts/utils/CommonHelpers": "CommonHelpers"
        }],
        ball: [function (b, e, t) {
            "use strict";

            cc._RF.push(e, "ac935cVCUZPe5jBmrJKLRZd", "ball"), Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var f = b("../../../scripts/config/Global"),
                n = b("../../../scripts/utils/CommonHelpers"),
                i = b("../../../scripts/config/Const"),
                r = b("../../../scripts/utils/event_listener"),
                g = b("../../../scripts/utils/EventConst"),
                y = b("big-integer"),
                o = cc._decorator,
                s = o.ccclass,
                c = o.property,
                p = function (o) {
                function e() {
                    var e = null !== o && o.apply(this, arguments) || this;
                    return e.curMotionStreak = null, e.curSp = null, e.speed = 0, e.price = "", e.attack = "", e.attackGreen = "", e.attack1p = "", e.attack2P = "", e.impactWallTimes = 0, e.ballSpeedx2 = !1, e.num = "", e.type = -1, e;
                }
                return __extends(e, o), e.prototype.onLoad = function () {}, e.prototype.start = function () {}, e.prototype.onBeginContact = function (n, e, t) {
                    (t.node.name.includes("wall") ? this.impactWallTimes++ : t.node.name.includes("enemyBall") && (this.impactWallTimes = 0), 8 <= this.impactWallTimes) && (this.impactWallTimes = 0, this.setSpeed());
                }, e.prototype.initBall = function (l) {
                    var a = this;
                    this.curMotionStreak.node.active = !1, this.curSp.node.width = 32, this.curSp.node.height = 32, this.type = 0, cc.loader.loadRes("ball/_" + l, cc.SpriteFrame, function (t, e) {
                        t ? cc.error(t.message || t) : a.curSp.spriteFrame = e;
                    }), this.price = n.CommonHelpers.getBallPrice(l, 1).toString(), this.attack = n.CommonHelpers.getBallAttack(l);
                    var e = y(this.attack).multiply(150).divmod(100);
                    this.attackGreen = e.quotient.add(e.remainder).toString(), this.speed = n.CommonHelpers.getBallSpeed(l), this.num = l, this.ballSpeedx2 = !((new Date().getTime() - f.Global.Instance.gainSpeedX2) / 1e3 > i.Const.GAIN_SPEED_X2 - 1), r.default.Instance.addFunc(g.default.BALL_SPEED_X2, this.ballSpeedX2CB.bind(this));
                }, e.prototype.initSB = function (l) {
                    var a = this;
                    this.curMotionStreak.node.active = !0, cc.loader.loadRes("sb/_" + l, function (t, e) {
                        t ? cc.error(t.message || t) : a.curMotionStreak.texture = e;
                    }), this.curSp.node.width = 50, this.curSp.node.height = 50, this.type = 1, cc.loader.loadRes("sb/_" + l, cc.SpriteFrame, function (t, e) {
                        t ? cc.error(t.message || t) : a.curSp.spriteFrame = e;
                    }), this.price = n.CommonHelpers.getSBPrice(l), this.attack = n.CommonHelpers.getSbAttack(l);
                    var e = y(this.attack).multiply(150).divmod(100);
                    this.attackGreen = e.quotient.add(e.remainder).toString();
                    var t = y(this.attack).multiply(2).divmod(100);
                    this.attack2P = t.quotient.add(t.remainder).toString(), this.attack1p = n.CommonHelpers.changeNum(y(this.attack).toJSNumber() * i.Const.AOE_RATE), this.speed = n.CommonHelpers.getSBallSpeed(l), this.num = l, this.ballSpeedx2 = !((new Date().getTime() - f.Global.Instance.gainSpeedX2) / 1e3 > i.Const.GAIN_SPEED_X2 - 1), r.default.Instance.addFunc(g.default.BALL_SPEED_X2, this.ballSpeedX2CB.bind(this));
                }, e.prototype.getAngle = function () {
                    return m(360 * Math.random() + 1);
                }, e.prototype.setSpeed = function () {
                    var n = this.node.getComponent(cc.RigidBody),
                        e = this.getAngle(),
                        t = 10 * a(.017453293 * e),
                        o = 10 * l(.017453293 * e),
                        i = 3 * this.speed;
                    0 < f.Global.Instance.game.buySB.s3 && (i *= 1.2), this.ballSpeedx2 && (i *= 2), n.linearVelocity = cc.v2(t * i, o * i), n.angularVelocity = 200, n.awake = !0;
                }, e.prototype.ballSpeedX2CB = function (t) {
                    (this.ballSpeedx2 = t) ? (this.ballSpeedx2 = t, this.setSpeed()) : this.ballSpeedx2 = t;
                }, __decorate([c(cc.MotionStreak)], e.prototype, "curMotionStreak", void 0), __decorate([c(cc.Sprite)], e.prototype, "curSp", void 0), e = __decorate([s], e);
            }(cc.Component);
            t.default = p, cc._RF.pop();
        }, {
            "../../../scripts/config/Const": "Const",
            "../../../scripts/config/Global": "Global",
            "../../../scripts/utils/CommonHelpers": "CommonHelpers",
            "../../../scripts/utils/EventConst": "EventConst",
            "../../../scripts/utils/event_listener": "event_listener",
            "big-integer": 1
        }],
        box_reward: [function (b, e, t) {
            "use strict";

            cc._RF.push(e, "b077bzUlxNFwJgmUhp5qETY", "box_reward"), Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var o = b("../../../scripts/config/Global"),
                n = b("../../../scripts/utils/CommonHelpers"),
                i = b("../../../scripts/utils/event_listener"),
                r = b("../../../scripts/utils/EventConst"),
                a = b("../../../scripts/config/Const"),
                l = b("big-integer"),
                c = cc._decorator,
                s = c.ccclass,
                u = c.property,
                p = function (p) {
                function e() {
                    var e = null !== p && p.apply(this, arguments) || this;
                    return e.titleLabel = null, e.moneyLabel = null, e.btnToastlabel = null, e.closeNode = null, e.btnNode = null, e.btnLabel = null, e;
                }
                return __extends(e, p), e.prototype.onLoad = function () {
                    console.log("box_reward:onLoad");
                }, e.prototype.start = function () {
                    console.log("box_reward:start");
                }, e.prototype.initBoxReward = function (t) {
                    0 === t ? this.pigInit() : void 0;
                }, e.prototype.pigInit = function () {
                    var l = this;
                    this.titleLabel.string = "幸运小猪", this.btnToastlabel.string = "分享到群可以获得5倍奖励", this.btnLabel.string = "分 享", o.http.shareSwitch && (this.btnNode.active = !0, this.btnToastlabel.node.active = !0, this.btnNode.on(cc.Node.EventType.TOUCH_END, function () {
                        console.log("btnNode"), o.$.isWechat() && (o.Global.Instance.offLineSwitch = !1, wx.shareAppMessage({
                            title: a.default.SHARE_1,
                            imageUrl: "https://detective.p8games.com/shareImg?id=11",
                            success: function success(e) {
                                l.checkShare(e), l.scheduleOnce(function () {
                                    o.Global.Instance.offLineSwitch = !0;
                                }, 1);
                            },
                            fail: function fail() {
                                l.scheduleOnce(function () {
                                    o.Global.Instance.offLineSwitch = !0;
                                }, 1);
                            }
                        }));
                    })), this.money = n.default.getPigBoxReward(o.Global.Instance.game.curLevel, 1), this.moneyLabel.string = n.default.getShowScoreByScore(this.money), this.closeNode.on(cc.Node.EventType.TOUCH_END, function () {
                        console.log("closeNode"), i.default.Instance.dispatchEvent(r.default.BOX_REWARD_CB, l.money), l.nodePoll.delBoxReward(l.node);
                    });
                }, e.prototype.checkShare = function (n) {
                    var a = this;
                    o.$.mwx.isShareToQun(n) ? o.$.mwx.checkShare(n, ":box_reward", function () {
                        console.log("checkShare:");
                        var t = l(a.money).multiply(5).toString();
                        i.default.Instance.dispatchEvent(r.default.BOX_REWARD_CB, t), a.nodePoll.delBoxReward(a.node);
                    }) : o.$.mwx.showToastWithTitle("分享失败请分享到群");
                }, __decorate([u(cc.Label)], e.prototype, "titleLabel", void 0), __decorate([u(cc.Label)], e.prototype, "moneyLabel", void 0), __decorate([u(cc.Label)], e.prototype, "btnToastlabel", void 0), __decorate([u(cc.Node)], e.prototype, "closeNode", void 0), __decorate([u(cc.Node)], e.prototype, "btnNode", void 0), __decorate([u(cc.Label)], e.prototype, "btnLabel", void 0), e = __decorate([s], e);
            }(cc.Component);
            t.default = p, cc._RF.pop();
        }, {
            "../../../scripts/config/Const": "Const",
            "../../../scripts/config/Global": "Global",
            "../../../scripts/utils/CommonHelpers": "CommonHelpers",
            "../../../scripts/utils/EventConst": "EventConst",
            "../../../scripts/utils/event_listener": "event_listener",
            "big-integer": 1
        }],
        btnRefreshLuckBox: [function (l, e, t) {
            "use strict";

            cc._RF.push(e, "51c1b8NK8FJJ74/8SB2iARP", "btnRefreshLuckBox"), Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var o = cc._decorator,
                n = o.ccclass,
                i = o.property,
                r = function (o) {
                function e() {
                    var e = null !== o && o.apply(this, arguments) || this;
                    return e.curNode = null, e.labelCount = null, e.text = "hello", e.maxNum = 10, e.startNum = 1, e.curNum = 1, e;
                }
                return __extends(e, o), e.prototype.onLoad = function () {
                    this.curNum = 0;
                    var t = this;
                    this.curNode.on(cc.Node.EventType.TOUCH_START, function () {
                        t.curNum++;
                    });
                }, e.prototype.update = function (t) {
                    this.curNum += t, 10 <= this.curNum && (this.curNum = 0), this.labelCount.string = this.curNum.toFixed(0);
                }, __decorate([i(cc.Node)], e.prototype, "curNode", void 0), __decorate([i(cc.Label)], e.prototype, "labelCount", void 0), __decorate([i], e.prototype, "text", void 0), __decorate([i], e.prototype, "maxNum", void 0), __decorate([i], e.prototype, "startNum", void 0), e = __decorate([n], e);
            }(cc.Component);
            t.default = r, cc._RF.pop();
        }, {}],
        config_item: [function (d, e, t) {
            "use strict";

            cc._RF.push(e, "e546dKpVetBUaxeNLzraSmc", "config_item"), Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var o = d("../../../../scripts/config/Const"),
                n = d("../../../../scripts/utils/HttpRequestHelpers"),
                i = d("../../../../scripts/config/Global"),
                r = d("../../../../scripts/utils/event_listener"),
                a = d("../../../../scripts/utils/EventConst"),
                l = cc._decorator,
                c = l.ccclass,
                s = l.property,
                u = function (l) {
                function e() {
                    var e = null !== l && l.apply(this, arguments) || this;
                    return e.labelName = null, e.curSprite = null, e.btnNode = null, e.labelBtn = null, e;
                }
                return __extends(e, l), e.prototype.start = function () {}, e.prototype.initConfigItem = function (t) {
                    "moreGame" === t ? this.initMoreGame() : "rank" === t ? this.initRank() : "share" === t ? this.initShare() : "backToHome" === t ? this.intiBack() : void 0;
                }, e.prototype.initMoreGame = function () {
                    this.labelName.string = "更多游戏";
                    var l = this;
                    cc.loader.loadRes("game/config/moreGame", cc.SpriteFrame, function (e, t) {
                        e ? cc.error(e.message || e) : (l.curSprite.spriteFrame = t, l.curSprite.node.width = 60, l.curSprite.node.height = 60);
                    }), this.btnNode.color = new cc.Color(241, 145, 72, 255), this.labelBtn.string = "查看", this.btnNode.on(cc.Node.EventType.TOUCH_END, function () {
                        n.default.moreGame();
                    });
                }, e.prototype.initRank = function () {
                    this.labelName.string = "排行榜";
                    var n = this;
                    cc.loader.loadRes("game/config/rank", cc.SpriteFrame, function (e, t) {
                        e ? cc.error(e.message || e) : (n.curSprite.spriteFrame = t, n.curSprite.node.width = 60, n.curSprite.node.height = 60);
                    }), this.btnNode.color = new cc.Color(241, 145, 72, 255), this.labelBtn.string = "查看", this.btnNode.on(cc.Node.EventType.TOUCH_END, function () {
                        r.default.Instance.dispatchEvent(a.default.OPEN_RANK, null);
                    });
                }, e.prototype.initShare = function () {
                    this.labelName.string = "分享";
                    var n = this;
                    cc.loader.loadRes("game/config/share", cc.SpriteFrame, function (e, t) {
                        e ? cc.error(e.message || e) : (n.curSprite.spriteFrame = t, n.curSprite.node.width = 60, n.curSprite.node.height = 60);
                    }), this.btnNode.color = new cc.Color(118, 225, 215, 255), this.labelBtn.string = "分享", this.btnNode.on(cc.Node.EventType.TOUCH_END, function () {
                        console.log("share"), i.Global.Instance.offLineSwitch = !1, wx.shareAppMessage({
                            title: o.default.SHARE_1,
                            imageUrl: "https://detective.p8games.com/shareImg?id=11",
                            success: function success() {
                                n.scheduleOnce(function () {
                                    i.Global.Instance.offLineSwitch = !0;
                                }, 1);
                            },
                            fail: function fail() {
                                n.scheduleOnce(function () {
                                    i.Global.Instance.offLineSwitch = !0;
                                }, 1);
                            }
                        });
                    });
                }, e.prototype.intiBack = function () {
                    this.labelName.string = "返回首页";
                    var n = this;
                    cc.loader.loadRes("game/config/back", cc.SpriteFrame, function (e, t) {
                        e ? cc.error(e.message || e) : (n.curSprite.spriteFrame = t, n.curSprite.node.width = 60, n.curSprite.node.height = 60);
                    }), this.btnNode.color = new cc.Color(118, 225, 215, 255), this.labelBtn.string = "返回", this.btnNode.on(cc.Node.EventType.TOUCH_END, function () {
                        cc.director.loadScene("Home"), r.default.Instance.removeAll();
                    });
                }, __decorate([s(cc.Label)], e.prototype, "labelName", void 0), __decorate([s(cc.Sprite)], e.prototype, "curSprite", void 0), __decorate([s(cc.Node)], e.prototype, "btnNode", void 0), __decorate([s(cc.Label)], e.prototype, "labelBtn", void 0), e = __decorate([c], e);
            }(cc.Component);
            t.default = u, cc._RF.pop();
        }, {
            "../../../../scripts/config/Const": "Const",
            "../../../../scripts/config/Global": "Global",
            "../../../../scripts/utils/EventConst": "EventConst",
            "../../../../scripts/utils/HttpRequestHelpers": "HttpRequestHelpers",
            "../../../../scripts/utils/event_listener": "event_listener"
        }],
        demo: [function (s, e, t) {
            "use strict";

            cc._RF.push(e, "aa2aaKYU8VDQqjcMWrN8DvD", "demo"), Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var o = s("../res/prefabs/hintPannel/Pannel"),
                n = s("../res/prefabs/hintPannel/hintPannel"),
                i = cc._decorator,
                r = i.ccclass,
                a = i.property,
                l = function (l) {
                function e() {
                    var e = null !== l && l.apply(this, arguments) || this;
                    return e.hintPannell = null, e;
                }
                return __extends(e, l), e.prototype.onLoad = function () {
                    this.showHintPannel("aaa", "bbb");
                }, e.prototype.showHintPannel = function (l, e) {
                    var t = this.hintPannell.getComponent(n.default);
                    t.title = l, t.content = e;
                }, __decorate([a(o.default)], e.prototype, "hintPannell", void 0), e = __decorate([r], e);
            }(cc.Component);
            t.default = l, cc._RF.pop();
        }, {
            "../res/prefabs/hintPannel/Pannel": "Pannel",
            "../res/prefabs/hintPannel/hintPannel": "hintPannel"
        }],
        enemBall: [function (b, e, t) {
            "use strict";

            cc._RF.push(e, "5a3f0IpSExDebQe71OXDN8l", "enemBall"), Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var f = b("big-integer"),
                n = b("../../../scripts/utils/CommonHelpers"),
                i = b("../../../scripts/utils/event_listener"),
                r = b("../../../scripts/utils/EventConst"),
                a = b("../../../scripts/config/Global"),
                l = b("./ball"),
                o = cc._decorator,
                s = o.ccclass,
                c = o.property,
                p = function (o) {
                function e() {
                    var e = null !== o && o.apply(this, arguments) || this;
                    return e.scoreLabel = null, e.scoreStringCopy = "", e.colorChange = !0, e.ballMoneyx2 = !1, e.redSubFlag = !1, e._isG = !1, e._isR = !1, e;
                }
                return __extends(e, o), e.prototype.onLoad = function () {
                    i.default.Instance.addFunc(r.default.DO_AOE, this.doAoe.bind(this));
                }, e.prototype.update = function () {
                    this.redSubFlag && 0 < a.default.Instance.game.buySB.s5 && this.isR && this.schedule(this.redSub, 1);
                }, e.prototype.redSub = function () {
                    this.redSubFlag = !1, this.allScore1P, this.isR || (this.redSubFlag = !0, this.unschedule(this.redSub));
                }, e.prototype.start = function () {}, e.prototype.onBeginContact = function (c, e, t) {
                    if ("ball" == t.node.name) {
                        var o = t.node.getComponent("ball").attack;
                        if (0 < a.default.Instance.game.buySB.s2 && this.isG) {
                            var s = f(o).multiply(15).divmod(10);
                            o = s.quotient.add(s.remainder).toString();
                        }
                        if (this.curScore.lesserOrEquals(o)) {
                            i.default.Instance.dispatchEvent(r.default.RF_VAL_COLLECTION_MONEY, this.curScore.toString()), i.default.Instance.dispatchEvent(r.default.CV_GAME_CHECK, null);
                            try {
                                var u = this.node.parent.parent.convertToNodeSpace(this.node.position);
                                i.default.Instance.dispatchEvent(r.default.PLAY_BOOM_PLIST, {
                                    pos: u,
                                    type: "boom"
                                });
                            } catch (t) {
                                console.log("enemBall:" + t);
                            }
                            this.curScore = this.curScore.minus(this.curScore), this.nodePoll.delEB(this.node);
                        } else this.doAction(1), i.default.Instance.dispatchEvent(r.default.RF_VAL_COLLECTION_MONEY, o), this.curScore = this.curScore.minus(o);
                        this.scoreStringCopy.substr(0, 3) != this.curScore.toString().substr(0, 3) && (this.scoreStringCopy = this.curScore.toString(), this.scoreLabel.string = n.default.getShowScoreByScore(this.scoreStringCopy), this.setColor());
                    } else if ("sb" == t.node.name) {
                        if (o = t.node.getComponent(l.default).attack, 0 < a.default.Instance.game.buySB.s2 && this.isG && (o = t.node.getComponent(l.default).attackGreen), 0 < a.default.Instance.game.buySB.s4 && "4" == t.node.getComponent(l.default).num) {
                            var b = t.node.getComponent(l.default).attack2P;
                            i.default.Instance.dispatchEvent(r.default.DO_AOE, b);
                        }
                        if (this.curScore.lesserOrEquals(o)) {
                            i.default.Instance.dispatchEvent(r.default.RF_VAL_COLLECTION_MONEY, this.curScore.toString()), i.default.Instance.dispatchEvent(r.default.CV_GAME_CHECK, null);
                            try {
                                u = this.node.parent.parent.convertToNodeSpace(this.node.position), i.default.Instance.dispatchEvent(r.default.PLAY_BOOM_PLIST, {
                                    pos: u,
                                    type: "boom"
                                });
                            } catch (t) {
                                console.log("enemBall:" + t);
                            }
                            this.curScore = this.curScore.minus(this.curScore), this.nodePoll.delEB(this.node);
                        } else this.doAction(1), i.default.Instance.dispatchEvent(r.default.RF_VAL_COLLECTION_MONEY, o), this.curScore = this.curScore.minus(o);
                        this.scoreStringCopy.substr(0, 3) != this.curScore.toString().substr(0, 3) && (this.scoreStringCopy = this.curScore.toString(), this.scoreLabel.string = n.default.getShowScoreByScore(this.scoreStringCopy), this.setColor());
                    }
                }, e.prototype.getAngle = function () {
                    return m(360 * Math.random() + 1);
                }, e.prototype.getCollectionByAttack = function (o) {
                    var e = o;
                    return this.ballMoneyx2 && (e = f(o).multiply(2).toString()), e;
                }, e.prototype.initEnemBall = function (a, e, t) {
                    this.startScore = a, this.curScore = f(a), this.allScore = t;
                    var o,
                        l = f(t).divmod(1e3);
                    if (this.allScore1P = l.quotient.add(l.remainder).toString(), 15 > e) {
                        var p = f(t).divmod(5 + e);
                        o = p.quotient.add(p.remainder);
                    } else {
                        var s = f(t).divmod(20);
                        o = s.quotient.add(s.remainder);
                    }
                    this.colorScore = o, this.divde_1 = f(parseInt(2 * f(o).toJSNumber() / 3 + "")), this.divde_2 = f(parseInt(1 * f(o).toJSNumber() / 3 + "")), this.setColor(), this.scoreLabel.string = n.default.getShowScoreByScore(a), this.scoreStringCopy = a, i.default.Instance.addFunc(r.default.BALL_MONEY_X2, this.ballMoneyX2CB.bind(this)), this.redSubFlag = !0;
                }, e.prototype.setColor = function () {
                    if (this.colorChange) {
                        var n = f(this.curScore),
                            e = this.colorScore,
                            t = {
                            r: 0,
                            g: 0,
                            b: 0
                        };
                        if (!n.lesser(e)) t.r = 255, t.g = 0, t.b = 0;else if (n.lesser(e) && !n.lesser(this.divde_1)) {
                            t.r = 255;
                            var o = f(n).minus(this.divde_1).toJSNumber() / f(this.divde_2).toJSNumber();
                            t.g = 255 - 255 * o, t.b = 0;
                        } else if (n.lesser(this.divde_1) && !n.lesser(this.divde_2)) {
                            var l = f(n).minus(this.divde_2).toJSNumber() / f(this.divde_2).toJSNumber();
                            t.r = 255 * l, t.g = 255, t.b = 0;
                        } else l = f(n).toJSNumber() / f(this.divde_2).toJSNumber(), t.r = 0, t.g = 255, t.b = 255 - 255 * l;
                        t.r > t.g && t.r > t.b && (this.isR = !0, this.isG = !1), t.g > t.r && t.g > t.b && (this.isG = !0, this.isR = !1), this.node.color = new cc.Color(t.r, t.g, t.b);
                    }
                }, e.prototype.doAction = function (l) {
                    var e = this;
                    switch (l) {
                        case 1:
                            e.scoreLabel.node.color = new cc.Color(255, 255, 255);
                            var t = cc.callFunc(function () {
                                e.scoreLabel.node.color = new cc.Color(0, 0, 0);
                            }, this, null),
                                o = cc.sequence(cc.scaleTo(.15, .93), cc.scaleTo(0, 1), t);
                            this.node.runAction(o);
                    }
                }, e.prototype.ballMoneyX2CB = function (t) {
                    this.ballMoneyx2 = t;
                }, e.prototype.doAoe = function (t) {
                    console.log("aoe"), this.curScore != f("0") && (this.curScore.lesserOrEquals(t) ? (i.default.Instance.dispatchEvent(r.default.RF_VAL_COLLECTION_MONEY, this.curScore.toString()), i.default.Instance.dispatchEvent(r.default.CV_GAME_CHECK, null), this.nodePoll.delEB(this.node), this.curScore = this.curScore.minus(this.curScore)) : (this.doAction(1), i.default.Instance.dispatchEvent(r.default.RF_VAL_COLLECTION_MONEY, t), this.curScore = this.curScore.minus(t)), this.scoreStringCopy.substr(0, 3) != this.curScore.toString().substr(0, 3) && (this.scoreStringCopy = this.curScore.toString(), this.scoreLabel.string = n.default.getShowScoreByScore(this.scoreStringCopy), this.setColor()));
                }, Object.defineProperty(e.prototype, "isG", {
                    get: function get() {
                        return this._isG;
                    },
                    set: function set(t) {
                        this._isG = t;
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "isR", {
                    get: function get() {
                        return this._isR;
                    },
                    set: function set(t) {
                        this._isR = t;
                    },
                    enumerable: !0,
                    configurable: !0
                }), __decorate([c(cc.Label)], e.prototype, "scoreLabel", void 0), e = __decorate([s], e);
            }(cc.Component);
            t.default = p, cc._RF.pop();
        }, {
            "../../../scripts/config/Global": "Global",
            "../../../scripts/utils/CommonHelpers": "CommonHelpers",
            "../../../scripts/utils/EventConst": "EventConst",
            "../../../scripts/utils/event_listener": "event_listener",
            "./ball": "ball",
            "big-integer": 1
        }],
        event_listener: [function (l, e, t) {
            "use strict";

            cc._RF.push(e, "6f4e0TNAJtAH6b3Kahp00eE", "event_listener"), Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var o = cc._decorator,
                n = o.ccclass,
                a = (o.property, function () {
                function o() {
                    this._funcs = {}, console.debug("EventListener Construct");
                }
                var e;
                return e = o, o.prototype.addFunc = function (o, e) {
                    null == this._funcs[o] && (this._funcs[o] = []), this._funcs[o].push(e);
                }, o.prototype.removeFunc = function (n, e) {
                    if (null != this._funcs[n]) {
                        var t = this._funcs[n].indexOf(e);
                        -1 != t && this._funcs[n].splice(t, 1);
                    }
                }, o.prototype.removeFuncAll = function (t) {
                    this._funcs[t] = [];
                }, o.prototype.removeAll = function () {
                    this._funcs = {};
                }, o.prototype.dispatchEvent = function (o, n) {
                    null != this._funcs[o] && this._funcs[o].forEach(function (t) {
                        t(n);
                    });
                }, o.Instance = new e(), o = e = __decorate([n], o);
            }());
            t.default = a, cc._RF.pop();
        }, {}],
        exp_line: [function (s, e, t) {
            "use strict";

            cc._RF.push(e, "4f7ce1s+X9C1ZlNxFzcEjle", "exp_line"), Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var o = cc._decorator,
                n = o.ccclass,
                i = o.property,
                r = s("../../../scripts/utils/event_listener"),
                a = s("../../../scripts/utils/EventConst"),
                l = function (o) {
                function e() {
                    var e = null !== o && o.apply(this, arguments) || this;
                    return e.bgSprite = null, e.expSprite = null, e.bgWidth = 320, e;
                }
                return __extends(e, o), e.prototype.onLoad = function () {
                    this.bgWidth = this.node.width, this.expSprite.node.width = 0, this.eventBind();
                }, e.prototype.start = function () {}, e.prototype.eventBind = function () {
                    r.default.Instance.addFunc(a.default.RF_SPRITE_EXP_LINE, this.rfExpSprite.bind(this));
                }, e.prototype.rfExpSprite = function (t) {
                    this.expSprite.node.width = t * this.bgWidth;
                }, __decorate([i(cc.Sprite)], e.prototype, "bgSprite", void 0), __decorate([i(cc.Sprite)], e.prototype, "expSprite", void 0), e = __decorate([n], e);
            }(cc.Component);
            t.default = l, cc._RF.pop();
        }, {
            "../../../scripts/utils/EventConst": "EventConst",
            "../../../scripts/utils/event_listener": "event_listener"
        }],
        gain_item: [function (d, e, t) {
            "use strict";

            cc._RF.push(e, "409c7l17QhAa5/tu0FMHeFa", "gain_item"), Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var o = d("../../../../scripts/config/Const"),
                n = d("../../../../scripts/utils/HttpRequestHelpers"),
                i = d("../../../../scripts/config/Global"),
                r = d("../../../../scripts/utils/event_listener"),
                a = d("../../../../scripts/utils/EventConst"),
                l = cc._decorator,
                c = l.ccclass,
                s = l.property,
                u = function (l) {
                function e() {
                    var e = null !== l && l.apply(this, arguments) || this;
                    return e.labelName = null, e.curSprite = null, e.btnNode = null, e.countDownLabel = null, e.upColor = new cc.Color(98, 60, 42), e.pColor = new cc.Color(100, 200, 200), e.state = 0, e.leftSec = 0, e.coutDownSwitch = !1, e;
                }
                return __extends(e, l), e.prototype.start = function () {}, e.prototype.initGainItem = function (t) {
                    "speed" === t ? this.initSpeed() : "money" === t ? this.initMoney() : void 0;
                }, e.prototype.initSpeed = function () {
                    this.type = "speed", this.labelName.string = "二倍速";
                    var l = this;
                    cc.loader.loadRes("game/gain/speedx2", cc.SpriteFrame, function (e, t) {
                        e ? cc.error(e.message || e) : (l.curSprite.spriteFrame = t, l.curSprite.node.width = 60, l.curSprite.node.height = 60);
                    }), this.setSpeedState(), r.default.Instance.addFunc(a.default.GAIN_SPEED_CB, this.speedCb.bind(this)), this.btnNode.on(cc.Node.EventType.TOUCH_END, function () {
                        1 == l.state && n.default.gainSpeedShare();
                    });
                }, e.prototype.setSpeedState = function () {
                    if (0 == i.default.Instance.gainSpeedX2) this.state = 1;else {
                        var t = (new Date().getTime() - i.default.Instance.gainSpeedX2) / 1e3;
                        t > o.default.GAIN_SPEED_X2 - 1 ? this.state = 1 : (this.leftSec = parseInt(o.default.GAIN_SPEED_X2 - t + ""), this.coutDownSwitch = !0, this.state = 0);
                    }
                    1 == this.state ? (this.btnNode.getComponent(cc.Button).interactable = !0, this.countDownLabel.string = "倒计时", this.node.color = this.upColor) : (this.btnNode.getComponent(cc.Button).interactable = !1, this.node.color = this.pColor);
                }, e.prototype.speedCb = function () {
                    i.default.Instance.gainSpeedX2 = new Date().getTime(), this.setSpeedState();
                    var t = o.default.GAIN_SPEED_X2 - (new Date().getTime() - i.default.Instance.gainSpeedX2) / 1e3;
                    this.leftSec = parseInt(t + ""), this.coutDownSwitch = !0;
                }, e.prototype.initMoney = function () {
                    this.type = "money", this.labelName.string = "二倍收益";
                    var l = this;
                    cc.loader.loadRes("game/gain/monex2", cc.SpriteFrame, function (e, t) {
                        e ? cc.error(e.message || e) : (l.curSprite.spriteFrame = t, l.curSprite.node.width = 60, l.curSprite.node.height = 60);
                    }), this.setMoneyState(), r.default.Instance.addFunc(a.default.GAIN_MONEY_CB, this.moneyCb.bind(this)), this.btnNode.on(cc.Node.EventType.TOUCH_END, function () {
                        1 == l.state && n.default.gainMoneyShare();
                    });
                }, e.prototype.setMoneyState = function () {
                    if (0 == i.default.Instance.gainMoneyX2) this.state = 1;else {
                        var t = (new Date().getTime() - i.default.Instance.gainMoneyX2) / 1e3;
                        t > o.default.GAIN_MONEY_X2 - 1 ? this.state = 1 : (this.leftSec = parseInt(o.default.GAIN_MONEY_X2 - t + ""), this.coutDownSwitch = !0, this.state = 0);
                    }
                    1 == this.state ? (this.btnNode.getComponent(cc.Button).interactable = !0, this.countDownLabel.string = "倒计时", this.node.color = this.upColor) : (this.btnNode.getComponent(cc.Button).interactable = !1, this.node.color = this.pColor);
                }, e.prototype.moneyCb = function () {
                    i.default.Instance.gainMoneyX2 = new Date().getTime(), this.setMoneyState();
                    var t = o.default.GAIN_MONEY_X2 - (new Date().getTime() - i.default.Instance.gainMoneyX2) / 1e3;
                    this.leftSec = parseInt(t + ""), this.coutDownSwitch = !0;
                }, e.prototype.update = function () {
                    this.coutDownSwitch && (this.unscheduleAllCallbacks, this.coutDownSwitch = !1, this.unschedule(this.countDonwCb), this.schedule(this.countDonwCb, 1, this.leftSec, 0));
                }, e.prototype.countDonwCb = function () {
                    if (this.leftSec -= 1, this.countDownLabel.string = this.getShowTime(this.leftSec), 0 == this.leftSec) {
                        switch (this.type) {
                            case "speed":
                                this.setSpeedState();
                                break;

                            case "money":
                                this.setMoneyState();
                        }
                        this.unschedule(this.countDonwCb);
                    }
                }, e.prototype.getShowTime = function (n) {
                    var e = parseInt((n / 3600).toString()),
                        t = parseInt((n - 3600 * e) / 60 + "");
                    return e + ":" + t + ":" + parseInt(n - 3600 * e - 60 * t + "");
                }, e.prototype.onEnable = function () {
                    switch (this.type) {
                        case "speed":
                            this.setSpeedState();
                            break;

                        case "money":
                            this.setMoneyState();
                    }
                }, __decorate([s(cc.Label)], e.prototype, "labelName", void 0), __decorate([s(cc.Sprite)], e.prototype, "curSprite", void 0), __decorate([s(cc.Node)], e.prototype, "btnNode", void 0), __decorate([s(cc.Label)], e.prototype, "countDownLabel", void 0), __decorate([s(cc.Color)], e.prototype, "upColor", void 0), __decorate([s(cc.Color)], e.prototype, "pColor", void 0), e = __decorate([c], e);
            }(cc.Component);
            t.default = u, cc._RF.pop();
        }, {
            "../../../../scripts/config/Const": "Const",
            "../../../../scripts/config/Global": "Global",
            "../../../../scripts/utils/EventConst": "EventConst",
            "../../../../scripts/utils/HttpRequestHelpers": "HttpRequestHelpers",
            "../../../../scripts/utils/event_listener": "event_listener"
        }],
        hintBall: [function (p, e, t) {
            "use strict";

            cc._RF.push(e, "6286bP1QCRKxZw6vzSdS0Ki", "hintBall"), Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var d = p("../../../scripts/utils/CommonHelpers"),
                n = p("../../../scripts/config/Const"),
                o = p("../../../scripts/config/Global"),
                r = cc._decorator,
                a = r.ccclass,
                l = r.property,
                i = function (r) {
                function e() {
                    var e = null !== r && r.apply(this, arguments) || this;
                    return e.closeNode = null, e.itemNameLabel = null, e.attackLabel = null, e.ballSprite = null, e._num = "", e;
                }
                return __extends(e, r), e.prototype.onLoad = function () {}, e.prototype.start = function () {}, e.prototype.initBallReward = function (l) {
                    var a = this,
                        e = n.default.f2["_" + l],
                        t = d.default.getShowScoreByScore(e);
                    this.attackLabel.string = t, cc.loader.loadRes("ball/_" + l, cc.SpriteFrame, function (t, e) {
                        t ? cc.error(t.message || t) : a.ballSprite.spriteFrame = e;
                    });
                }, Object.defineProperty(e.prototype, "num", {
                    get: function get() {
                        return this._num;
                    },
                    set: function set(t) {
                        this._num = t, "" == t || this.initBallReward(t);
                    },
                    enumerable: !0,
                    configurable: !0
                }), e.prototype.share = function () {
                    o.$.isWechat() && wx.shareAppMessage({
                        title: n.default.SHARE_1,
                        imageUrl: "https://detective.p8games.com/shareImg?id=11"
                    });
                }, __decorate([l(cc.Node)], e.prototype, "closeNode", void 0), __decorate([l(cc.Label)], e.prototype, "itemNameLabel", void 0), __decorate([l(cc.Label)], e.prototype, "attackLabel", void 0), __decorate([l(cc.Sprite)], e.prototype, "ballSprite", void 0), e = __decorate([a], e);
            }(cc.Component);
            t.default = i, cc._RF.pop();
        }, {
            "../../../scripts/config/Const": "Const",
            "../../../scripts/config/Global": "Global",
            "../../../scripts/utils/CommonHelpers": "CommonHelpers"
        }],
        hintPannel: [function (l, e, t) {
            "use strict";

            cc._RF.push(e, "b0079zcbQdCgJogTL+uZ/I4", "hintPannel"), Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var o = cc._decorator,
                n = o.ccclass,
                i = o.property,
                r = function (o) {
                function e() {
                    var e = null !== o && o.apply(this, arguments) || this;
                    return e.titleLabel = null, e.contentLabel = null, e._title = "", e._content = "", e;
                }
                return __extends(e, o), Object.defineProperty(e.prototype, "title", {
                    get: function get() {
                        return this._title;
                    },
                    set: function set(t) {
                        this._title = t, this.titleLabel.string = t;
                    },
                    enumerable: !0,
                    configurable: !0
                }), Object.defineProperty(e.prototype, "content", {
                    get: function get() {
                        return this._content;
                    },
                    set: function set(t) {
                        this._content = t, this.contentLabel.string = t;
                    },
                    enumerable: !0,
                    configurable: !0
                }), __decorate([i(cc.Label)], e.prototype, "titleLabel", void 0), __decorate([i(cc.Label)], e.prototype, "contentLabel", void 0), e = __decorate([n], e);
            }(cc.Component);
            t.default = r, cc._RF.pop();
        }, {}],
        merageBall: [function (s, e, t) {
            "use strict";

            cc._RF.push(e, "44254THIB1MJYpE+iogHJmg", "merageBall"), Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var o = s("../../../scripts/utils/EventConst"),
                n = s("../../../scripts/utils/event_listener"),
                i = cc._decorator,
                r = i.ccclass,
                a = i.property,
                l = function (l) {
                function e() {
                    var e = null !== l && l.apply(this, arguments) || this;
                    return e.leftBallNode = null, e.rightBallNode = null, e.leftSp = null, e.rightSp = null, e;
                }
                return __extends(e, l), e.prototype.onLoad = function () {}, e.prototype.start = function () {
                    this.doAction();
                }, e.prototype.initCur = function (o) {
                    var n = this;
                    this.node.active = !0, cc.loader.loadRes("ball/_" + o, cc.SpriteFrame, function (t, e) {
                        t ? cc.error(t.message || t) : (n.leftSp.spriteFrame = e, n.rightSp.spriteFrame = e);
                    });
                }, e.prototype.doAction = function () {
                    var l = this,
                        e = cc.callFunc(function () {
                        l.node.active = !1, l.scheduleOnce(function () {
                            var e = l.node.parent.convertToNodeSpace(l.node.position);
                            n.default.Instance.dispatchEvent(o.default.PLAY_BOOM_PLIST, {
                                pos: e,
                                type: "hecheng"
                            }), l.nodePool.delMerge(l.node);
                        }, .3);
                    }, l, null),
                        t = cc.speed(cc.sequence(cc.moveTo(.2, cc.p(0, 0)), cc.spawn(cc.moveTo(.5, cc.p(-150, 0)), cc.rotateTo(.5, -720)), cc.moveTo(.2, cc.p(-150, 0)), cc.moveTo(.3, cc.p(0, 0)), e), 1.5);
                    this.leftBallNode.runAction(t);
                    var a = cc.speed(cc.sequence(cc.moveTo(.2, cc.p(0, 0)), cc.spawn(cc.moveTo(.5, cc.p(150, 0)), cc.rotateTo(.5, 720)), cc.moveTo(.2, cc.p(150, 0)), cc.moveTo(.3, cc.p(0, 0)), null), 1.5);
                    this.rightBallNode.runAction(a);
                }, __decorate([a(cc.Node)], e.prototype, "leftBallNode", void 0), __decorate([a(cc.Node)], e.prototype, "rightBallNode", void 0), __decorate([a(cc.Sprite)], e.prototype, "leftSp", void 0), __decorate([a(cc.Sprite)], e.prototype, "rightSp", void 0), e = __decorate([r], e);
            }(cc.Component);
            t.default = l, cc._RF.pop();
        }, {
            "../../../scripts/utils/EventConst": "EventConst",
            "../../../scripts/utils/event_listener": "event_listener"
        }],
        myScore: [function (l, e, t) {
            "use strict";

            cc._RF.push(e, "551c96kFilIrbHnOImb/BZ8", "myScore"), Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var o = cc._decorator,
                n = o.ccclass,
                i = o.property,
                r = function (o) {
                function e() {
                    var e = null !== o && o.apply(this, arguments) || this;
                    return e.myScore = null, e.myRankLabel = null, e.myPicSprite = null, e.myNameLabel = null, e.myScoreLabel = null, e.oddSprite = null, e.evenSprite = null, e;
                }
                return __extends(e, o), e.prototype.start = function () {}, e.prototype.onInitMyScore = function (l, s, t, o, n) {
                    var i = this;
                    if (this.myScore.spriteFrame = n ? this.evenSprite : 0 == +l % 2 ? this.evenSprite : this.oddSprite, this.myRankLabel.string = l, null != s && "" != s) {
                        var r = s;
                        console.log("url:" + r), cc.loader.load({
                            url: r,
                            type: "png"
                        }, function (n, e) {
                            console.log("on load res," + n);
                            var t = new cc.SpriteFrame();
                            t.setTexture(e), i.myPicSprite.spriteFrame = t;
                        });
                    }
                    this.myNameLabel.string = t, this.myScoreLabel.string = o;
                }, e.prototype.onDisable = function () {}, e.prototype.onEnable = function () {
                    console.log("myScore:onEnable");
                }, e.prototype.onDestroy = function () {
                    console.log("myScore:destroy");
                }, __decorate([i(cc.Sprite)], e.prototype, "myScore", void 0), __decorate([i(cc.Label)], e.prototype, "myRankLabel", void 0), __decorate([i(cc.Sprite)], e.prototype, "myPicSprite", void 0), __decorate([i(cc.Label)], e.prototype, "myNameLabel", void 0), __decorate([i(cc.Label)], e.prototype, "myScoreLabel", void 0), __decorate([i(cc.SpriteFrame)], e.prototype, "oddSprite", void 0), __decorate([i(cc.SpriteFrame)], e.prototype, "evenSprite", void 0), e = __decorate([n], e);
            }(cc.Component);
            t.default = r, cc._RF.pop();
        }, {}],
        plist: [function (l, e, t) {
            "use strict";

            cc._RF.push(e, "8e35cK2vRJAUrKjv5Aa5YE3", "plist"), Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var o = cc._decorator,
                n = o.ccclass,
                i = o.property,
                r = function (o) {
                function e() {
                    var e = null !== o && o.apply(this, arguments) || this;
                    return e.baozhaoPlist = null, e.hechengPlist = null, e;
                }
                return __extends(e, o), e.prototype.start = function () {}, e.prototype.initCur = function (t) {}, e.prototype.playOnece = function (o) {
                    var e = null;
                    void 0 == o || "boom" == o ? e = this.baozhaoPlist : "hecheng" == o && (e = this.hechengPlist), 0 < e.particleCount ? (e.stopSystem(), e.resetSystem()) : e.resetSystem();
                }, __decorate([i(cc.ParticleSystem)], e.prototype, "baozhaoPlist", void 0), __decorate([i(cc.ParticleSystem)], e.prototype, "hechengPlist", void 0), e = __decorate([n], e);
            }(cc.Component);
            t.default = r, cc._RF.pop();
        }, {}],
        prefab_ball_item: [function (b, e, t) {
            "use strict";

            cc._RF.push(e, "eaa460I8e5JrKGGhdpb29YE", "prefab_ball_item"), Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var g = b("../../../../scripts/config/Const"),
                n = b("../../../../scripts/utils/CommonHelpers"),
                i = b("../../../../scripts/config/Global"),
                r = b("../../../../scripts/utils/event_listener"),
                a = b("../../../../scripts/utils/EventConst"),
                o = b("../../../../scripts/utils/HttpRequestHelpers"),
                l = b("../../../../scripts/game/Game"),
                s = cc._decorator,
                c = s.ccclass,
                p = s.property,
                d = function (s) {
                function e() {
                    var e = null !== s && s.apply(this, arguments) || this;
                    return e.labelName = null, e.attackLabel = null, e.moneyLabel = null, e.ballSprite = null, e.btnNode = null, e.btnLabel = null, e.lockNode = null, e.upColor = new cc.Color(98, 60, 42), e.pColor = new cc.Color(100, 200, 200), e.num = null, e.btnStatus = 0, e._lock = !1, e;
                }
                return __extends(e, s), Object.defineProperty(e.prototype, "lock", {
                    get: function get() {
                        return this._lock;
                    },
                    set: function set(t) {
                        this._lock = t, this.lockNode.active = !!t;
                    },
                    enumerable: !0,
                    configurable: !0
                }), e.prototype.onLoad = function () {
                    var t = this;
                    this.btnNode.on(cc.Node.EventType.TOUCH_END, function () {
                        switch (t.btnStatus) {
                            case 0:
                            case 1:
                                t.buyBall();
                        }
                        t.changeState();
                    }), r.default.Instance.addFunc(a.default.PREFAB_BALL_ITEM_INIT_AGAIN, this.initAgain.bind(this));
                }, e.prototype.start = function () {}, e.prototype.initCur = function (l) {
                    this.num = l;
                    var p = this;
                    n.default.isBallOnceBought(l) ? (r.default.Instance.addFunc(a.default.RF_PREFAB_BALL_ITEM, this.rfBallItem.bind(this)), r.default.Instance.addFunc(a.default.BUY_BALL_CB, this.buyBallCB.bind(this))) : this.lock = !0;
                    var e = n.default.getBallAttack(l),
                        t = n.default.getShowScoreByScore(e);
                    this.attackLabel.string = t, this.labelName.string = g.default.BALL_NAME["_" + l];
                    var o = n.default.getBallPrice(l, i.default.Instance.game.buyBall["b" + l]).toString(),
                        s = n.default.getShowScoreByScore(o);
                    this.moneyLabel.string = s, cc.loader.loadRes("ball/_" + l, cc.SpriteFrame, function (t, e) {
                        t ? cc.error(t.message || t) : p.ballSprite.spriteFrame = e;
                    }), this.changeState();
                }, e.prototype.initAgain = function (t) {
                    null == t ? n.default.isBallOnceBought(this.num) ? (r.default.Instance.addFunc(a.default.RF_PREFAB_BALL_ITEM, this.rfBallItem.bind(this)), r.default.Instance.addFunc(a.default.BUY_BALL_CB, this.buyBallCB.bind(this)), 1 == this.lock && (this.lock = !1)) : this.lock = !0 : t == this.num && (n.default.isBallOnceBought(t) ? (r.default.Instance.addFunc(a.default.RF_PREFAB_BALL_ITEM, this.rfBallItem.bind(this)), r.default.Instance.addFunc(a.default.BUY_BALL_CB, this.buyBallCB.bind(this)), 1 == this.lock && (this.lock = !1)) : this.lock = !0);
                }, e.prototype.changeState = function () {
                    var t = this.num;
                    switch (n.default.canBuyBall(t) ? n.default.isBallExist(t) && n.default.canBuyBall(t) ? this.btnStatus = 1 : !n.default.isBallExist(t) && n.default.canBuyBall(t) && (this.btnStatus = 0) : this.btnStatus = 2, this.btnStatus) {
                        case 0:
                            this.btnLabel.string = "购 买", this.btnNode.color = new cc.Color(165, 221, 133, 255);
                            break;

                        case 1:
                            this.btnLabel.string = "合 成", this.btnNode.color = new cc.Color(241, 213, 100, 255);
                            break;

                        case 2:
                            this.btnLabel.string = "购 买", this.btnNode.color = new cc.Color(112, 116, 110, 255);
                    }
                    this.node.color = n.default.isBallExist(t) ? this.pColor : this.upColor;
                }, e.prototype.buyBall = function () {
                    (cc.log("buyBall"), i.default.Instance.game.canBuyBallOnlyWithBallNum(this.num)) ? n.default.canBuyBall(this.num) && o.default.buyBall(this.num) : (console.log("除了球数其他都满足"), cc.Canvas.instance.getComponent(l.default).showHintPannel("提示", "球的数量已达上限"));
                }, e.prototype.rfBallItem = function (l) {
                    if (!(null != l)) e = n.default.getBallPrice(this.num, i.default.Instance.game.buyBall["b" + this.num]).toString(), t = n.default.getShowScoreByScore(e), this.moneyLabel.string = t, this.changeState();else if (l == this.num) {
                        var e = n.default.getBallPrice(this.num, i.default.Instance.game.buyBall["b" + this.num]).toString(),
                            t = n.default.getShowScoreByScore(e);
                        this.moneyLabel.string = t, this.changeState();
                    }
                }, e.prototype.buyBallCB = function (t) {
                    t == this.num && (i.default.Instance.game.pushBBall(this.num), r.default.Instance.dispatchEvent(a.default.ADD_CREATE_BALL, this.num), r.default.Instance.dispatchEvent(a.default.RF_CUR_GAME_MONEY, null), r.default.Instance.dispatchEvent(a.default.RF_PREFAB_BALL_ITEM, this.num));
                }, __decorate([p(cc.Label)], e.prototype, "labelName", void 0), __decorate([p(cc.Label)], e.prototype, "attackLabel", void 0), __decorate([p(cc.Label)], e.prototype, "moneyLabel", void 0), __decorate([p(cc.Sprite)], e.prototype, "ballSprite", void 0), __decorate([p(cc.Node)], e.prototype, "btnNode", void 0), __decorate([p(cc.Label)], e.prototype, "btnLabel", void 0), __decorate([p(cc.Node)], e.prototype, "lockNode", void 0), __decorate([p(cc.Color)], e.prototype, "upColor", void 0), __decorate([p(cc.Color)], e.prototype, "pColor", void 0), e = __decorate([c], e);
            }(cc.Component);
            t.default = d, cc._RF.pop();
        }, {
            "../../../../scripts/config/Const": "Const",
            "../../../../scripts/config/Global": "Global",
            "../../../../scripts/game/Game": "Game",
            "../../../../scripts/utils/CommonHelpers": "CommonHelpers",
            "../../../../scripts/utils/EventConst": "EventConst",
            "../../../../scripts/utils/HttpRequestHelpers": "HttpRequestHelpers",
            "../../../../scripts/utils/event_listener": "event_listener"
        }],
        prefab_buy_super_ball: [function (p, e, t) {
            "use strict";

            cc._RF.push(e, "432dbDLOslGMrKLvgp5PPLy", "prefab_buy_super_ball"), Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var d = p("../../../scripts/config/Const"),
                n = p("../../../scripts/utils/CommonHelpers"),
                o = p("../../../scripts/utils/HttpRequestHelpers"),
                r = cc._decorator,
                a = r.ccclass,
                l = r.property,
                i = function (r) {
                function e() {
                    var e = null !== r && r.apply(this, arguments) || this;
                    return e.closeNode = null, e.buyNode = null, e.titleLabel = null, e.nameLabel = null, e.attackLabel = null, e.priceLabel = null, e.ballSprite = null, e;
                }
                return __extends(e, r), e.prototype.initCur = function (l) {
                    var a = this,
                        e = d.default.SB_NAME["_" + l];
                    this.num = l, this.titleLabel.string = e.name, this.nameLabel.string = e.name, this.attackLabel.string = n.default.getShowScoreByScore(n.default.getSbAttack(l + "")), this.priceLabel.string = n.default.getShowScoreByScore(n.default.getSBPrice(l + "")), cc.loader.loadRes("sb/_" + l, cc.SpriteFrame, function (t, e) {
                        t ? cc.error(t.message || t) : a.ballSprite.spriteFrame = e;
                    });
                }, e.prototype.onLoad = function () {
                    var t = this;
                    this.closeNode.on(cc.Node.EventType.TOUCH_END, function () {
                        t.nodePool.delBuySBall(t.node);
                    }), this.buyNode.on(cc.Node.EventType.TOUCH_END, function () {
                        cc.log("prefab_buy_super_ball:buyNode"), t.buySb(), t.nodePool.delBuySBall(t.node);
                    });
                }, e.prototype.buySb = function () {
                    cc.log("buysb"), o.default.buySB(this.num);
                }, e.prototype.start = function () {}, __decorate([l(cc.Node)], e.prototype, "closeNode", void 0), __decorate([l(cc.Node)], e.prototype, "buyNode", void 0), __decorate([l(cc.Label)], e.prototype, "titleLabel", void 0), __decorate([l(cc.Label)], e.prototype, "nameLabel", void 0), __decorate([l(cc.Label)], e.prototype, "attackLabel", void 0), __decorate([l(cc.Label)], e.prototype, "priceLabel", void 0), __decorate([l(cc.Sprite)], e.prototype, "ballSprite", void 0), e = __decorate([a], e);
            }(cc.Component);
            t.default = i, cc._RF.pop();
        }, {
            "../../../scripts/config/Const": "Const",
            "../../../scripts/utils/CommonHelpers": "CommonHelpers",
            "../../../scripts/utils/HttpRequestHelpers": "HttpRequestHelpers"
        }],
        prefab_gift_box: [function (p, e, t) {
            "use strict";

            cc._RF.push(e, "4155dwHaTVAJqJrgw1rLOaD", "prefab_gift_box"), Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var o = cc._decorator,
                n = o.ccclass,
                i = o.property,
                r = p("../../../scripts/utils/CommonHelpers"),
                d = p("../../../scripts/utils/event_listener"),
                u = p("../../../scripts/utils/EventConst"),
                c = function (o) {
                function e() {
                    var e = null !== o && o.apply(this, arguments) || this;
                    return e.boxSprite = null, e.speed = 0, e.duration = 120, e;
                }
                return __extends(e, o), e.prototype.initGitfBox = function () {
                    var t = this;
                    this.speed = r.CommonHelpers.getBallSpeed("0") / 2, this.setSpeed(), this.changeSpriteFrame(0), this.node.on(cc.Node.EventType.TOUCH_END, function () {
                        console.log("Gitbox:clicked!"), d.default.Instance.dispatchEvent(u.default.CLICK_GIFT_BOX_CB, 0), t.nodePoll.delGitfBox(t.node);
                    }), this.scheduleOnce(function () {
                        t.nodePoll.delGitfBox(t.node);
                    }, this.duration);
                }, e.prototype.onLoad = function () {}, e.prototype.changeSpriteFrame = function (n) {
                    var l = this,
                        e = "";
                    0 === n ? e = "pig" : 1 === n ? e = "egg" : void 0;
                    cc.loader.loadRes("game/" + e, cc.SpriteFrame, function (t, e) {
                        t ? cc.error(t.message || t) : l.boxSprite.spriteFrame = e;
                    });
                }, e.prototype.setSpeed = function () {
                    var r = this.node.getComponent(cc.RigidBody),
                        e = this.getAngle(),
                        t = 10 * a(.017453293 * e),
                        o = 10 * l(.017453293 * e);
                    r.linearVelocity = cc.v2(t * this.speed, o * this.speed);
                }, e.prototype.getAngle = function () {
                    return m(360 * Math.random() + 1);
                }, __decorate([i(cc.Sprite)], e.prototype, "boxSprite", void 0), __decorate([i], e.prototype, "duration", void 0), e = __decorate([n], e);
            }(cc.Component);
            t.default = c, cc._RF.pop();
        }, {
            "../../../scripts/utils/CommonHelpers": "CommonHelpers",
            "../../../scripts/utils/EventConst": "EventConst",
            "../../../scripts/utils/event_listener": "event_listener"
        }],
        prefab_money_collection: [function (s, e, t) {
            "use strict";

            cc._RF.push(e, "f67eecwi1BAO61JS1nKDKkL", "prefab_money_collection"), Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var o = cc._decorator,
                n = o.ccclass,
                i = o.property,
                r = s("../../../scripts/utils/event_listener"),
                a = s("../../../scripts/utils/EventConst"),
                l = function (o) {
                function e() {
                    var e = null !== o && o.apply(this, arguments) || this;
                    return e.labelMoney = null, e.text = "hello", e._btnInteractable = !0, e.seq = cc.repeatForever(cc.sequence(cc.scaleTo(.8, .9), cc.scaleTo(.8, 1))), e;
                }
                return __extends(e, o), e.prototype.onLoad = function () {
                    var t = this;
                    this.node.on(cc.Node.EventType.TOUCH_END, function () {
                        t.btnCollectionClicked();
                    });
                }, e.prototype.start = function () {}, e.prototype.btnCollectionClicked = function () {
                    var o = this,
                        e = o.node.getComponent(cc.Button);
                    e.interactable && (r.default.Instance.dispatchEvent(a.default.RS_VAL_COLLECTION_MONEY, "0"), e.interactable = !1, this.btnInteractable = !1, this.scheduleOnce(function () {
                        o.node.getComponent(cc.Button).interactable = !0, o.btnInteractable = !0;
                    }, 5));
                }, e.prototype.rfCollectionMoney = function (t) {
                    this.labelMoney.string = t;
                }, Object.defineProperty(e.prototype, "btnInteractable", {
                    get: function get() {
                        return this._btnInteractable;
                    },
                    set: function set(t) {
                        this._btnInteractable = t, t ? this.node.runAction(this.seq) : this.node.stopAllActions();
                    },
                    enumerable: !0,
                    configurable: !0
                }), __decorate([i(cc.Label)], e.prototype, "labelMoney", void 0), __decorate([i], e.prototype, "text", void 0), e = __decorate([n], e);
            }(cc.Component);
            t.default = l, cc._RF.pop();
        }, {
            "../../../scripts/utils/EventConst": "EventConst",
            "../../../scripts/utils/event_listener": "event_listener"
        }],
        prefab_offline_reward: [function (p, e, t) {
            "use strict";

            cc._RF.push(e, "7adb0YrntZJ25gkaJFOq/r/", "prefab_offline_reward"), Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var o = cc._decorator,
                n = o.ccclass,
                i = o.property,
                r = p("../../../scripts/utils/CommonHelpers"),
                a = p("../../../scripts/utils/HttpRequestHelpers"),
                l = p("../hintPannel/Pannel"),
                d = p("../../../scripts/utils/LocalStorageUtils"),
                s = function (o) {
                function e() {
                    var e = null !== o && o.apply(this, arguments) || this;
                    return e.moneylabel = null, e.x2Node = null, e.recieveNode = null, e._curMoney = "", e;
                }
                return __extends(e, o), e.prototype.onLoad = function () {
                    this.node.name = "prefab_offline_reward";
                    var t = this;
                    this.x2Node.on(cc.Node.EventType.TOUCH_END, function () {}), this.recieveNode.on(cc.Node.EventType.TOUCH_END, function () {
                        a.default.addMoney(t.curMoney), d.default.setOffLine(), t.curMoney = "0", t.node.getComponent(l.default).hide();
                    });
                }, e.prototype.initOfflineReward = function (t) {
                    this.curMoney = t;
                }, Object.defineProperty(e.prototype, "curMoney", {
                    get: function get() {
                        return this._curMoney;
                    },
                    set: function set(o) {
                        this._curMoney = o;
                        var e = r.default.getShowScoreByScore(o);
                        this.moneylabel.string = e;
                    },
                    enumerable: !0,
                    configurable: !0
                }), __decorate([i(cc.Label)], e.prototype, "moneylabel", void 0), __decorate([i(cc.Node)], e.prototype, "x2Node", void 0), __decorate([i(cc.Node)], e.prototype, "recieveNode", void 0), e = __decorate([n], e);
            }(cc.Component);
            t.default = s, cc._RF.pop();
        }, {
            "../../../scripts/utils/CommonHelpers": "CommonHelpers",
            "../../../scripts/utils/HttpRequestHelpers": "HttpRequestHelpers",
            "../../../scripts/utils/LocalStorageUtils": "LocalStorageUtils",
            "../hintPannel/Pannel": "Pannel"
        }],
        prefab_sb_item: [function (b, e, t) {
            "use strict";

            cc._RF.push(e, "5952dXkInFJkK6OXKoa6wCY", "prefab_sb_item"), Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var f = b("../../../../scripts/config/Const"),
                n = b("../../../../scripts/utils/CommonHelpers"),
                o = b("../../../../scripts/config/Global"),
                r = b("big-integer"),
                a = b("../../../../scripts/utils/event_listener"),
                l = b("../../../../scripts/utils/EventConst"),
                i = cc._decorator,
                s = i.ccclass,
                c = i.property,
                p = function (i) {
                function e() {
                    var e = null !== i && i.apply(this, arguments) || this;
                    return e.nameLabel = null, e.effectLabel = null, e.itemSprite = null, e.attackNode = null, e.attackLabel = null, e.priceLabel = null, e.btnNode = null, e.lockSp = null, e.btnLabel = null, e.upColor = new cc.Color(98, 60, 42), e.pColor = new cc.Color(100, 200, 200), e.num = null, e.btnStatus = 1, e;
                }
                return __extends(e, i), e.prototype.initSbItem = function (i) {
                    var s = this;
                    s.num = i;
                    var e = f.default.SB_NAME["_" + i];
                    this.nameLabel.string = e.name, this.effectLabel.string = e.desc, cc.loader.loadRes("sb/_" + i, cc.SpriteFrame, function (t, e) {
                        t ? cc.error(t.message || t) : s.itemSprite.spriteFrame = e;
                    });
                    var t = n.default.getSBPrice(this.num);
                    this.price = t, this.setStatus(), this.btnNode.on(cc.Node.EventType.TOUCH_END, function () {
                        0 == s.btnStatus && a.default.Instance.dispatchEvent(l.default.SHOW_BUY_SB_COMFIRM, s.num);
                    });
                }, e.prototype.setStatus = function () {
                    var l = f.default.SB_NAME["_" + this.num];
                    if (n.default.isSBallExist(this.num)) this.btnStatus = 2;else if (o.default.Instance.game.curLevel >= l.buyLevel) {
                        var e = o.default.Instance.game.money;
                        this.btnStatus = r(this.price).lesser(e) ? 0 : 1;
                    } else this.btnStatus = 3;
                    switch (this.btnStatus) {
                        case 0:
                            this.attackNode.active = !0, this.attackLabel.string = n.default.getShowScoreByScore(n.default.getSbAttack(this.num)), this.btnLabel.string = "购买", this.btnNode.color = new cc.Color(118, 225, 215, 255), this.lockSp.node.active = !1, this.node.color = this.upColor;
                            break;

                        case 1:
                            this.attackNode.active = !0, this.attackLabel.string = n.default.getShowScoreByScore(n.default.getSbAttack(this.num)), this.btnLabel.string = "" + n.default.getShowScoreByScore(this.price), this.btnNode.color = new cc.Color(112, 116, 110, 255), this.lockSp.node.active = !1, this.node.color = this.upColor;
                            break;

                        case 2:
                            this.attackNode.active = !0, this.attackLabel.string = n.default.getShowScoreByScore(n.default.getSbAttack(this.num)), this.btnLabel.string = "已购买", this.btnNode.color = new cc.Color(112, 116, 110, 255), this.lockSp.node.active = !1, this.node.color = this.pColor;
                            break;

                        case 3:
                            this.attackNode.active = !0, this.attackLabel.string = n.default.getShowScoreByScore(n.default.getSbAttack(this.num)), this.btnLabel.string = "lv" + l.buyLevel, this.btnNode.color = new cc.Color(112, 116, 110, 255), this.lockSp.node.active = !0, this.node.color = this.upColor;
                    }
                }, e.prototype.buySBCb = function (t) {
                    t == this.num && (a.default.Instance.dispatchEvent(l.default.RF_CUR_GAME_MONEY, null), a.default.Instance.dispatchEvent(l.default.RF_PREFAB_SB_ITEM, null), a.default.Instance.dispatchEvent(l.default.RF_SUPER_BALL, t));
                }, e.prototype.rfSBItem = function () {
                    this.setStatus();
                }, e.prototype.onLoad = function () {
                    a.default.Instance.addFunc(l.default.RF_PREFAB_SB_ITEM, this.rfSBItem.bind(this)), a.default.Instance.addFunc(l.default.BUY_SUPER_BALL_CB, this.buySBCb.bind(this));
                }, __decorate([c(cc.Label)], e.prototype, "nameLabel", void 0), __decorate([c(cc.Label)], e.prototype, "effectLabel", void 0), __decorate([c(cc.Sprite)], e.prototype, "itemSprite", void 0), __decorate([c(cc.Node)], e.prototype, "attackNode", void 0), __decorate([c(cc.Label)], e.prototype, "attackLabel", void 0), __decorate([c(cc.Label)], e.prototype, "priceLabel", void 0), __decorate([c(cc.Node)], e.prototype, "btnNode", void 0), __decorate([c(cc.Sprite)], e.prototype, "lockSp", void 0), __decorate([c(cc.Label)], e.prototype, "btnLabel", void 0), __decorate([c(cc.Color)], e.prototype, "upColor", void 0), __decorate([c(cc.Color)], e.prototype, "pColor", void 0), e = __decorate([s], e);
            }(cc.Component);
            t.default = p, cc._RF.pop();
        }, {
            "../../../../scripts/config/Const": "Const",
            "../../../../scripts/config/Global": "Global",
            "../../../../scripts/utils/CommonHelpers": "CommonHelpers",
            "../../../../scripts/utils/EventConst": "EventConst",
            "../../../../scripts/utils/event_listener": "event_listener",
            "big-integer": 1
        }],
        prefab_scrollView: [function (l, e, t) {
            "use strict";

            cc._RF.push(e, "33aafUt4+RJSb5MhY1/mbg7", "prefab_scrollView"), Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var o = cc._decorator,
                n = o.ccclass,
                i = o.property,
                r = function (o) {
                function e() {
                    var e = null !== o && o.apply(this, arguments) || this;
                    return e.contentBody = null, e;
                }
                return __extends(e, o), e.prototype.start = function () {}, e.prototype.svAddItem = function (t) {
                    this.contentBody.addChild(t);
                }, __decorate([i(cc.Node)], e.prototype, "contentBody", void 0), e = __decorate([n], e);
            }(cc.Component);
            t.default = r, cc._RF.pop();
        }, {}],
        prefab_super_ball_item: [function (l, e, t) {
            "use strict";

            cc._RF.push(e, "9ac4cIPfrBJ+pcnnr+/Y3er", "prefab_super_ball_item"), Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var o = cc._decorator,
                n = o.ccclass,
                i = o.property,
                r = function (o) {
                function e() {
                    var e = null !== o && o.apply(this, arguments) || this;
                    return e.attackLabel = null, e.LevelLabel = null, e.ballSprite = null, e.btnNode = null, e.btnLabel = null, e.lockSprite = null, e.num = null, e.btnStatus = 0, e;
                }
                return __extends(e, o), e.prototype.onLoad = function () {
                    var t = this;
                    this.btnNode.on(cc.Node.EventType.TOUCH_END, function () {
                        switch (t.btnStatus) {
                            case 0:
                                t.relive();
                                break;

                            case 1:
                                t.upLevel();
                        }
                        t.changeState();
                    });
                }, e.prototype.changeState = function () {
                    switch (this.btnLabel.getComponent(cc.Widget).horizontalCenter = 0, this.lockSprite.node.active = !1, this.btnStatus) {
                        case 0:
                            this.btnLabel.string = "转 生", this.btnNode.color = new cc.Color(241, 213, 100, 255);
                            break;

                        case 1:
                            this.btnLabel.string = "升 级", this.btnNode.color = new cc.Color(165, 221, 133, 255);
                            break;

                        case 2:
                            this.btnLabel.string = "升 级", this.btnNode.color = new cc.Color(112, 116, 110, 255);
                            break;

                        case 3:
                            this.btnLabel.string = "转 生", this.btnNode.color = new cc.Color(112, 116, 110, 255), this.btnLabel.getComponent(cc.Widget).horizontalCenter = 12, this.lockSprite.node.active = !0;
                    }
                }, e.prototype.start = function () {}, e.prototype.relive = function () {}, e.prototype.upLevel = function () {}, __decorate([i(cc.Label)], e.prototype, "attackLabel", void 0), __decorate([i(cc.Label)], e.prototype, "LevelLabel", void 0), __decorate([i(cc.Sprite)], e.prototype, "ballSprite", void 0), __decorate([i(cc.Node)], e.prototype, "btnNode", void 0), __decorate([i(cc.Label)], e.prototype, "btnLabel", void 0), __decorate([i(cc.Sprite)], e.prototype, "lockSprite", void 0), e = __decorate([n], e);
            }(cc.Component);
            t.default = r, cc._RF.pop();
        }, {}],
        prefab_tabs: [function (p, e, t) {
            "use strict";

            cc._RF.push(e, "d2c81Ft/mhCirrjUpFXCWn9", "prefab_tabs"), Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var o = cc._decorator,
                n = o.ccclass,
                i = o.property,
                r = p("../../../scripts/config/Global"),
                a = p("../../../scripts/config/Const"),
                l = p("../../../scripts/game/Game"),
                d = function (o) {
                function e() {
                    var e = null !== o && o.apply(this, arguments) || this;
                    return e.tabControlNode = null, e.tabContentNode = null, e.scrollViewPrefab = null, e.ballItemPrefab = null, e.sbItemPrefab = null, e.gainItemPrefab = null, e.configItemPrefab = null, e.tabsItemPrefab = null, e.contentItemPrefab = null, e.tabsItemWidth = 120, e.tabsTextColor = new cc.Color(255, 255, 255, 255), e.normalColor = new cc.Color(98, 60, 42, 255), e.pickedColor = new cc.Color(129, 82, 60, 255), e.tabs = ["球", "超级球", "config"], e.tabsPrefabs = [], e.tabsContentPrefabs = [], e.switch = !0, e;
                }
                return __extends(e, o), e.prototype.onLoad = function () {
                    for (var l, t = 0; t < this.tabs.length; t++) {
                        l = cc.instantiate(this.tabsItemPrefab), this.tabControlNode.addChild(l), this.setTabsItem(l, t);
                        var e = cc.instantiate(this.contentItemPrefab);
                        e.y = -1e3, this.tabContentNode.addChild(e), this.tabsContentPrefabs.push(e);
                    }
                    this.tabControlNode.color = this.normalColor, this.tabContentNode.color = this.pickedColor;
                    var o = this.initBallItem();
                    this.tabsContentPrefabs[0].addChild(o), o.y = -500;
                    var n = this.initSuperBallItem();
                    this.tabsContentPrefabs[1].addChild(n), n.y = -500;
                    var a = this.initConfig();
                    for (this.tabsContentPrefabs[2].addChild(a), a.y = -500, t = 0; t < this.tabsPrefabs.length; t++) {
                        this.tabsPrefabs[t].getComponent("tab_control_item").unPicked(), this.tabContentNode.children[t].active = !1;
                    }this.tabsPrefabs[0].getComponent("tab_control_item").picked(), this.tabContentNode.children[0].active = !0, cc.log(this.tabContentNode);
                }, e.prototype.start = function () {}, e.prototype.update = function () {}, e.prototype.setTabsItem = function (a, e) {
                    var t = this,
                        o = a.getComponent("tab_control_item");
                    o.setLabelText(t.tabs[e], t.tabsTextColor), o.num = e, o.tabNode = this, o.pickedColor = this.pickedColor, o.unPickedColor = this.normalColor, o.unPicked(), a.width = t.tabsItemWidth;
                    var n = e * t.tabsItemWidth + t.tabsItemWidth / 2;
                    a.setPosition(n, 0), a.color = t.normalColor, t.tabsPrefabs.push(a), a.on(cc.Node.EventType.TOUCH_END, function () {
                        console.log("clicked");
                        var e = a.getComponent("tab_control_item").num;
                        console.log(e), t.setAllTabItemUnPicked(), t.pickedTabByIndex(e);
                        var o = cc.Canvas.instance.getComponent(l.default);
                        o.node.getChildByName("bottomControl").getChildByName("billboard").active = 2 == e;
                    });
                }, e.prototype.setAllTabItemUnPicked = function () {
                    for (var t = 0; t < this.tabsPrefabs.length; t++) {
                        this.tabsPrefabs[t].getComponent("tab_control_item").unPicked(), this.tabContentNode.children[t].active = !1;
                    }
                }, e.prototype.pickedTabByIndex = function (t) {
                    this.tabsPrefabs[t].getComponent("tab_control_item").picked(), this.tabContentNode.children[t].active = !0;
                }, e.prototype.setContentItem = function (t) {
                    this.tabsContentPrefabs.push(t);
                }, e.prototype.initBallItem = function () {
                    var l = cc.instantiate(this.scrollViewPrefab);
                    l.y = 0;
                    var e = Object.keys(r.default.Instance.game.buyBall);
                    e = e.slice(0, 40);
                    for (var t, n = 0; n < e.length; n++) {
                        t = cc.instantiate(this.ballItemPrefab), t.getComponent("prefab_ball_item").initCur(e[n].split("b")[1]), l.getComponent("prefab_scrollView").svAddItem(t);
                    }return l.getComponent(cc.ScrollView).scrollToLeft(), l;
                }, e.prototype.initSuperBallItem = function () {
                    var l = cc.instantiate(this.scrollViewPrefab);
                    l.y = 0;
                    for (var e, n = Object.keys(a.default.SB_NAME), t = 0; t < n.length; t++) {
                        e = cc.instantiate(this.sbItemPrefab), e.getComponent("prefab_sb_item").initSbItem(n[t].split("_")[1]), l.getComponent("prefab_scrollView").svAddItem(e);
                    }return l.getComponent(cc.ScrollView).scrollToLeft(), l;
                }, e.prototype.initGainItem = function () {
                    var l = cc.instantiate(this.scrollViewPrefab);
                    l.y = 0;
                    for (var e, n = ["speed", "money"], t = 0; t < n.length; t++) {
                        e = cc.instantiate(this.gainItemPrefab), e.getComponent("gain_item").initGainItem(n[t]), l.getComponent("prefab_scrollView").svAddItem(e);
                    }return l.getComponent(cc.ScrollView).scrollToLeft(), l;
                }, e.prototype.initConfig = function () {
                    var l = cc.instantiate(this.scrollViewPrefab);
                    l.y = 0;
                    for (var e, n = ["moreGame", "share"], t = 0; t < n.length; t++) {
                        e = cc.instantiate(this.configItemPrefab), e.getComponent("config_item").initConfigItem(n[t]), l.getComponent("prefab_scrollView").svAddItem(e);
                    }return l.getComponent(cc.ScrollView).scrollToLeft(), l;
                }, __decorate([i(cc.Node)], e.prototype, "tabControlNode", void 0), __decorate([i(cc.Node)], e.prototype, "tabContentNode", void 0), __decorate([i(cc.Prefab)], e.prototype, "scrollViewPrefab", void 0), __decorate([i(cc.Prefab)], e.prototype, "ballItemPrefab", void 0), __decorate([i(cc.Prefab)], e.prototype, "sbItemPrefab", void 0), __decorate([i(cc.Prefab)], e.prototype, "gainItemPrefab", void 0), __decorate([i(cc.Prefab)], e.prototype, "configItemPrefab", void 0), __decorate([i(cc.Prefab)], e.prototype, "tabsItemPrefab", void 0), __decorate([i(cc.Prefab)], e.prototype, "contentItemPrefab", void 0), e = __decorate([n], e);
            }(cc.Component);
            t.default = d, cc._RF.pop();
        }, {
            "../../../scripts/config/Const": "Const",
            "../../../scripts/config/Global": "Global",
            "../../../scripts/game/Game": "Game"
        }],
        rank: [function (s, e, t) {
            "use strict";

            cc._RF.push(e, "c1dbbrbp4tEApnjotAoP8NF", "rank"), Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var p = s("../../../scripts/utils/CommonHelpers"),
                o = cc._decorator,
                n = o.ccclass,
                r = o.property,
                a = function (o) {
                function e() {
                    var e = null !== o && o.apply(this, arguments) || this;
                    return e.rank = null, e.cotent = null, e.myRank = null, e.myScorePrefabs = null, e.rankScrollView = null, e.btnBack = null, e.myRankLabel = null, e.initSwitch = !1, e;
                }
                return __extends(e, o), e.prototype.onLoad = function () {
                    var t = this;
                    this.btnBack.on(cc.Node.EventType.TOUCH_END, function () {
                        t.node.active = !1;
                    });
                }, e.prototype.start = function () {}, e.prototype.doInitRank = function () {
                    var n = this;
                    if (!this.initSwitch) {
                        this.initSwitch = !0;
                        var e = this;
                        cc.sys.platform === cc.sys.WECHAT_GAME && void 0 != window.account && (cc.log(window.my_session), cc.log(window.account.session), wx.request({
                            url: "https://detective.p8games.com/infinateBall/getTop",
                            data: {
                                session: window.account.session
                            },
                            success: function success(t) {
                                console.log("on getTop"), console.log(t);
                                var o = t.data;
                                e.myRankLabel.string = null == o.self.rank ? "" : o.self.rank, e.myRank.getComponent("myScore").onInitMyScore(o.self.rank, window.account.data.logo, window.account.data.name, p.default.getRankLevelBy(o.self.rLevel, o.self.level), !0);
                                for (var i = 0; i < o.list.length; i++) {
                                    var r = o.list[i],
                                        a = e.nodePool.getMyScore();
                                    a.getComponent("myScore").onInitMyScore(i + 1, r.logo, r.name, p.default.getRankLevelBy(r.rLevel, r.level)), e.cotent.addChild(a);
                                }
                                n.rankScrollView.scrollToTop();
                            }
                        }));
                    }
                }, __decorate([r(cc.Node)], e.prototype, "rank", void 0), __decorate([r(cc.Node)], e.prototype, "cotent", void 0), __decorate([r(cc.Node)], e.prototype, "myRank", void 0), __decorate([r(cc.Prefab)], e.prototype, "myScorePrefabs", void 0), __decorate([r(cc.ScrollView)], e.prototype, "rankScrollView", void 0), __decorate([r(cc.Node)], e.prototype, "btnBack", void 0), __decorate([r(cc.Label)], e.prototype, "myRankLabel", void 0), e = __decorate([n], e);
            }(cc.Component);
            t.default = a, cc._RF.pop();
        }, {
            "../../../scripts/utils/CommonHelpers": "CommonHelpers"
        }],
        shock: [function (l, e, t) {
            "use strict";

            cc._RF.push(e, "db791oBYpZMiJWoJTUKSLdW", "shock"), Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var o = cc._decorator,
                n = o.ccclass,
                a = (o.property, function (o) {
                function e() {
                    var e = null !== o && o.apply(this, arguments) || this;
                    return e.bool = !0, e;
                }
                return __extends(e, o), e.prototype.onLoad = function () {
                    this.pos = this.node.position, console.log(this.pos);
                    for (var l = [], e = 0; 10 > e; e++) {
                        var t = this.pos.x + 40 * Math.random() - 20,
                            o = this.pos.y + 40 * Math.random() - 20;
                        l.push(cc.moveTo(.05, t, o));
                    }
                    console.log(l);
                    var n = cc.repeatForever(cc.sequence(l[0], l[1], l[2], l[3], l[4], l[5], l[6], l[7], l[8], l[9], cc.moveTo(.05, this.pos.x, this.pos.y)));
                    this.node.runAction(n);
                }, e = __decorate([n], e);
            }(cc.Component));
            t.default = a, cc._RF.pop();
        }, {}],
        tab_control_item: [function (l, e, t) {
            "use strict";

            cc._RF.push(e, "f7a1ef1CI1GnI/5wLPjo9UM", "tab_control_item"), Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var o = cc._decorator,
                n = o.ccclass,
                i = o.property,
                r = function (o) {
                function e() {
                    var e = null !== o && o.apply(this, arguments) || this;
                    return e.labelText = null, e.curSprite = null, e.num = -1, e;
                }
                return __extends(e, o), e.prototype.onLoad = function () {}, e.prototype.start = function () {}, e.prototype.unPicked = function () {
                    this.node.color = this.unPickedColor;
                }, e.prototype.picked = function () {
                    this.node.color = this.pickedColor;
                }, e.prototype.setLabelText = function (n, e) {
                    if (this.labelText.string = n, this.labelText.node.color = e, "config" == n) {
                        var l = this;
                        this.labelText.node.active = !1, this.curSprite.node.active = !0, cc.loader.loadRes("game/logo_config", cc.SpriteFrame, function (o, e) {
                            o ? cc.error(o.message || o) : l.curSprite.spriteFrame = e;
                        });
                    }
                }, __decorate([i(cc.Label)], e.prototype, "labelText", void 0), __decorate([i(cc.Sprite)], e.prototype, "curSprite", void 0), e = __decorate([n], e);
            }(cc.Component);
            t.default = r, cc._RF.pop();
        }, {}],
        wxBillboard: [function (s, e, t) {
            "use strict";

            cc._RF.push(e, "c938a08SV9JKqGWKy/oBjVZ", "wxBillboard"), Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var o = s("../../../scripts/config/Global"),
                n = cc._decorator,
                i = n.ccclass,
                r = n.property,
                a = function (n) {
                function e() {
                    var e = null !== n && n.apply(this, arguments) || this;
                    return e.label_gamename = null, e.sprite_gameimg = null, e.label_propagranda = null, e.games = [], e.index = -1, e.url = "https://detective.p8games.com/getGames", e.mGameId = 11, e.show = !1, e.b_video_hide = !1, e;
                }
                return __extends(e, n), e.prototype.createVideo = function () {
                    cc.sys.platform === cc.sys.WECHAT_GAME && (this._wxVideo = wx.createVideo({
                        muted: !0,
                        loop: !0,
                        autoplay: !0,
                        controls: !1,
                        objectFit: "fill",
                        poster: 1,
                        x: 0,
                        y: 0,
                        width: 0,
                        height: 0
                    }));
                }, e.prototype.onLoad = function () {
                    if (this.b_video_hide = !1, cc.sys.WECHAT_GAME != cc.sys.platform) return this.hideAll();
                    var n = this;
                    o.default.adData || wx.request({
                        url: this.url,
                        data: {
                            id: this.mGameId,
                            version: "3.0"
                        },
                        success: function success(e) {
                            o.default.adData = e.data, n.games = o.default.adData, n.showNextGame(), n.show = !0;
                        }
                    }), this.reposition(), this.node.on("click", function () {
                        var t = this.games[this.index];
                        t.appid && t.path ? (console.log("navigateToMiniProgram", t.appid, t.path), wx.navigateToMiniProgram({
                            appId: t.appid,
                            path: t.path,
                            extraData: ""
                        })) : wx.previewImage({
                            urls: [this.games[this.index].img]
                        }), wx.request({
                            url: "https://detective.p8games.com/gameClick",
                            data: {
                                id: this.mGameId,
                                tag: this.games[this.index].id
                            },
                            success: function success(t) {
                                console.log("on game click", t);
                            }
                        });
                    }, this), !this.show && o.default.adData && (n.games = o.default.adData, n.showNextGame(), n.show = !0);
                }, e.prototype.onEnable = function () {
                    this.showVideo();
                }, e.prototype.onDisable = function () {
                    this.hideVideo();
                }, e.prototype.onDestroy = function () {
                    this._wxVideo && this._wxVideo.destroy();
                }, e.prototype.showNextGame = function () {
                    var n = this;
                    n.index = -1 === n.index ? 0 : (n.index + 1) % n.games.length;
                    var e = n.games[n.index];
                    if (console.log(e), !e.enable) return n.showNextGame();
                    if (2 == e.showType) {
                        if (n.b_video_hide) return;
                        n.sprite_gameimg.node.opacity = 0, n.showVideo(), n._wxVideo.src = e.showUrl, n._wxVideo.play();
                    } else n.sprite_gameimg.node.opacity = 255, n.hideVideo(), cc.loader.load(e.showUrl, function (e, t) {
                        n.sprite_gameimg.spriteFrame = new cc.SpriteFrame(t);
                    });
                    n.label_gamename.string = e.name, n.label_propagranda.string = e.detail;
                    var t = e.id;
                    wx.request({
                        url: "https://detective.p8games.com/gameShow",
                        data: {
                            id: this.mGameId,
                            tag: t
                        },
                        success: function success(t) {
                            console.log("on game show", t);
                        }
                    }), n.scheduleOnce(function () {
                        n.showNextGame();
                    }, e.secs);
                }, e.prototype.start = function () {}, e.prototype.reposition = function () {
                    var p = this.sprite_gameimg.node.getContentSize(),
                        e = this.node.convertToWorldSpaceAR(this.sprite_gameimg.node.getPosition()),
                        t = cc.Canvas.instance,
                        o = cc.view.getDesignResolutionSize(),
                        n = cc.view.getFrameSize();
                    if (t.fitHeight) var i = n.height / o.height;else i = n.width / o.width;
                    p.height *= i, p.width *= i, e.x *= i, e.y *= i;
                    var r = e.x - p.width / 2,
                        a = n.height - (e.y + p.height / 2),
                        l = p.width,
                        d = p.height;
                    this.wxRect = cc.rect(r, a, l, d);
                }, e.prototype.hideAll = function () {
                    this.active = !1, this.hideVideo(), this.node.opacity = 0, this.node.getComponent(cc.Button).interactable = !1;
                }, e.prototype.showAll = function () {
                    this._wxVideo && (this.showVideo(), this.node.opacity = 255, this.node.getComponent(cc.Button).interactable = !0);
                }, e.prototype.hideVideo = function () {
                    this._wxVideo && (this._wxVideo.width && (this._wxVideo.width = 0), this._wxVideo.height && (this._wxVideo.height = 0)), this.b_video_hide = !0;
                }, e.prototype.showVideo = function () {
                    this.b_video_hide = !1;
                    var t = this.games[this.index];
                    t && 2 == t.showType && (this._wxVideo || this.createVideo(), this._wxVideo && (this._wxVideo.x = this.wxRect.x, this._wxVideo.y = this.wxRect.y, this._wxVideo.width = this.wxRect.width, this._wxVideo.height = this.wxRect.height));
                }, __decorate([r(cc.Label)], e.prototype, "label_gamename", void 0), __decorate([r(cc.Sprite)], e.prototype, "sprite_gameimg", void 0), __decorate([r(cc.Label)], e.prototype, "label_propagranda", void 0), e = __decorate([i], e);
            }(cc.Component);
            t.default = a, cc._RF.pop();
        }, {
            "../../../scripts/config/Global": "Global"
        }]
    }, {}, ["wxBillboard", "ball", "enemBall", "ball_reward", "box_reward", "prefab_money_collection", "exp_line", "prefab_gift_box", "hintBall", "Pannel", "hintPannel", "prefab_ball_item", "config_item", "gain_item", "prefab_sb_item", "btnRefreshLuckBox", "merageBall", "shock", "plist", "prefab_buy_super_ball", "prefab_offline_reward", "prefab_scrollView", "myScore", "rank", "prefab_super_ball_item", "prefab_tabs", "tab_control_item", "WXButton", "BallEnum", "Const", "Global", "demo", "Game", "Home", "FetchService", "CommonHelpers", "EventConst", "HttpHelper", "HttpRequestHelpers", "LocalStorageUtils", "NodePollHelper", "PriceCache", "event_listener", "BuyBall", "BuySB", "WXCommonData"]);
})(); 
})